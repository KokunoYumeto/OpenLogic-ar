# القرارات العربية الحالية — الجزء ٦ من ١١

[الرجوع إلى فهرس الأجزاء](README.md)

السياقات والتعليلات أدناه من السجل القائم؛ لم تُراجع جميعها مراجعة معجمية جديدة في هذا الإخراج. يعني تحذير الموضع غير المحسوم أن الملف معروف لكن السطر الحالي لم يثبت، ويعني رابط بدء الوحدة أن صفحة اللفظ ليست معلومة بالدقة.

## منتهية التفرع

الأصل الإنجليزي: `finitely branching`. معرّف القرار: `retro-0005-0050:emphasis:f61b7c3fde161bcc`.

**المعنى المقصود:** شجرة لكل عقدة فيها عدد منتهٍ من اللواحق، من غير اشتراط حد موحد لذلك العدد.

**سبب الاختيار:** يكمم المصدر محليًا على كل x قبل أن يسمي الشجرة «منتهية التفرع». فالتعريف دقيق، وإن كان الوسم الموجز قد يوهم أن الشجرة نفسها منتهية على نحو إجمالي.

**سؤال مفتوح:** هل تفيد «منتهية التفرع» بوضوح أن التفرع منتهٍ عند كل عقدة؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0018 — الأشجار، وقوع ١:**
  - **الأصل:** [السطر ٨٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/trees.tex#L87). الشاهد المسجل: «\emph{finitely branching}.».
  - **العربية المعيارية:** [السطر ٨٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/trees.tex#L84)؛ الطبعة الدولية: [ص ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=50) (ترقيم المتن: ٤٩) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=50) (ترقيم المتن: ٤٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{منتهية التفرع}.».
  - **العربية التراثية:** [السطر ٧٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/trees.tex#L79)؛ الطبعة التراثية: [ص ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=48) (ترقيم المتن: ٤٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «لواحق عددها منته، قلنا إن $T$ \emph{منتهية التفرع}.».

## صيغ

الأصل الإنجليزي: `formulas`. معرّف القرار: `retro-0005-0050:shared-token:7c7b8ea87bbd1177`.

**المعنى المقصود:** الصيغ المنطقية حين تُحلل بوصفها أشجارًا تركيبية.

**سبب الاختيار:** السياق منطقي وتركيبي صريح، ولذلك يعني الجمع المشترك «صيغ» formulas لا معادلات اعتباطية. ويثبت معجم دمشق formula بـ«صيغة، قاعدة» مباشرةً.

**سؤال مفتوح:** سؤال اختياري: هل تكفي «صيغ» أم تضاف «منطقية»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0018 — الأشجار، وقوع ١:**
  - **الأصل:** [السطر ١٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/trees.tex#L14). الشاهد المسجل: «parts of logic: for example, !!{formula}s can be understood in terms».
  - **العربية المعيارية:** [السطر ١٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/trees.tex#L14)؛ الطبعة الدولية: [ص ٤٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=49) (ترقيم المتن: ٤٨) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=49) (ترقيم المتن: ٤٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فيمكن، مثلًا، فهم !!{formula}s من حيث تحليلها إلى شجرة تركيبية، كما تتخذ».
  - **العربية التراثية:** [السطر ١٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/trees.tex#L14)؛ الطبعة التراثية: [ص ٤٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=47) (ترقيم المتن: ٤٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «!!{formula}s بتحليلها إلى شجر تركيبية، وتتخذ !!{derivation}s في».

## من ℤ إلى ℚ

الأصل الإنجليزي: `From $\Int$ to $\Rat$`. معرّف القرار: `retro-0005-0050:section:640371d87cefc049`.

**المعنى المقصود:** خطوة البناء من الأعداد الصحيحة Z إلى الأعداد النسبية Q.

**سبب الاختيار:** يحفظ العنوان الموجز الاتجاه والرمزين، ويصرح مطلع القسم ببناء النسبية من الصحيحة. ويسمي مرجع اتحاد المجامع النظامين Z وQ.

**سؤال مفتوح:** سؤال اختياري: أنحتفظ بالرمزين أم نبسط الاسمين؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0043 — من ℤ إلى ℚ، وقوع ١:**
  - **الأصل:** [السطر ١٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/arithmetization/rationals.tex#L10). الشاهد المسجل: «\olsection{From $\Int$ to $\Rat$}».
  - **العربية المعيارية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/arithmetization/rationals.tex#L10)؛ الطبعة الدولية: [ص ٨٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=89) (ترقيم المتن: ٨٨) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=89) (ترقيم المتن: ٨٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{من $\Int$ إلى $\Rat$}».
  - **العربية التراثية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/arithmetization/rationals.tex#L10)؛ الطبعة التراثية: [ص ٨٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=85) (ترقيم المتن: ٨٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{من $\Int$ إلى $\Rat$}».

## من ℕ إلى ℤ

الأصل الإنجليزي: `From $\Nat$ to $\Int$`. معرّف القرار: `retro-0005-0050:section:752bc2574e88601b`.

**المعنى المقصود:** خطوة البناء من الأعداد الطبيعية N إلى الأعداد الصحيحة Z.

**سبب الاختيار:** يحفظ العنوان الاتجاه، ويشفّر القسم فروق الأعداد الصحيحة بأزواج من الطبيعية. ويسمي مرجع اتحاد المجامع N وZ، فيما يبقى اصطلاح إدخال الصفر في N محكومًا بالمصدر نفسه.

**سؤال مفتوح:** سؤال اختياري: هل تُبسط أسماء المجموعات لأغراض التصفح؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0042 — من ℕ إلى ℤ، وقوع ١:**
  - **الأصل:** [السطر ١١](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/arithmetization/integers.tex#L11). الشاهد المسجل: «\olsection{From $\Nat$ to $\Int$}».
  - **العربية المعيارية:** [السطر ١١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/arithmetization/integers.tex#L11)؛ الطبعة الدولية: [ص ٨٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=87) (ترقيم المتن: ٨٦) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=87) (ترقيم المتن: ٨٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{من $\Nat$ إلى $\Int$}».
  - **العربية التراثية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/arithmetization/integers.tex#L10)؛ الطبعة التراثية: [ص ٨٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=83) (ترقيم المتن: ٨٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{من $\Nat$ إلى $\Int$}».

## من ℚ إلى ℝ

الأصل الإنجليزي: `From $\Rat$ to $\Real$`. معرّف القرار: `retro-0005-0050:section:7ecb5ee67742c50c`.

**المعنى المقصود:** خطوة بناء الأعداد الحقيقية R من الأعداد النسبية Q بقطوع ديدكند.

**سبب الاختيار:** يحفظ العنوان الاتجاه، ويصرح المطلع ببناء الحقيقية من النسبية. ويسمي مرجع اتحاد المجامع Q وR.

**سؤال مفتوح:** سؤال اختياري: الرموز أم الأسماء المبسوطة؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0045 — من ℚ إلى ℝ، وقوع ١:**
  - **الأصل:** [السطر ١٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/arithmetization/cuts.tex#L10). الشاهد المسجل: «\olsection{From $\Rat$ to $\Real$}».
  - **العربية المعيارية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/arithmetization/cuts.tex#L10)؛ الطبعة الدولية: [ص ٩١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=91) (ترقيم المتن: ٩٠) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٩١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=91) (ترقيم المتن: ٩٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{من $\Rat$ إلى $\Real$}».
  - **العربية التراثية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/arithmetization/cuts.tex#L10)؛ الطبعة التراثية: [ص ٨٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=87) (ترقيم المتن: ٨٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{من $\Rat$ إلى $\Real$}».

## دالة

الأصل الإنجليزي: `function`. معرّف القرار: `locale-ar-chosen-d62673bd67c7ae57`.

**المعنى المقصود:** الدالة الرياضية بوصفها تعيينًا أحاديَّ القيمة: لكل مدخل في المجال قيمة واحدة بعينها في المجال المقابل؛ وتشمل المواضع دوالَّ صدق، وتقييمات، ودوالَّ حسابية وجزئية واختيارية ما دام هذا المعنى محفوظًا.

**سبب الاختيار:** يُبقى الرأس «دالة» في المواضع العشرين المعيَّنة. فقد قورنت جميع الشواهد الإنجليزية والعربية الحديثة والكلاسيكية، وكلها تستعمل اللفظ لموضوع رياضي أحادي القيمة أو لتركيب موصوف صراحةً بأنه function. ويثبت معجم مجمع اللغة العربية بدمشق في الصفحة المادية 276 (المطبوعة 264) الرأس function بصيغة «دالة (تابع)»، ويعرّفه بإسناد عنصر واحد فقط من المجموعة الثانية إلى كل عنصر من الأولى. لذلك يسند المعجم اللفظ المختار ويُبقي «تابع» بديلًا إقليميًا حقيقيًا، ولا يسند تعميم «اقتران» على كل هذه السياقات. وفي OLP-0260 يرد اللفظ في القضية f:ℕ^n→ℕ، فلا يغيّر المعنى الحاسوبي شرط أحادية القيمة. هذا تقويم استعادي جديد، لا ادعاء بأنه كان تعليل المترجم وقت الصياغة ولا بأنه يحسم التفضيل الإقليمي.

**سؤال مفتوح:** في المواضع العشرين المحددة، ومنها OLP-0260، هل «دالة» هي الرأس العربي العابر للأقاليم الأنسب لـ function، أم ينبغي اعتماد «تابع» في بعض الأقاليم أو الطبعات؟ وهل توجد حالة من هذه الحالات يصح فيها «اقتران» من غير أن يوهم بعلاقة عامة أو بعملية تركيب؟ يرجى إبقاء شرط القيمة الواحدة لكل مدخل، والتمييز السياقي بين الدالة الكلية والجزئية ودالة الصدق ودالة الاختيار.

**كل وقوع مسجل لهذا القرار:**

- **OLP-0481 — في التواريخ الممكنة، وقوع ١:**
  - **الأصل:** [السطر ٣٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/applied-modal-logic/temporal-logic/possible-histories.tex#L33). الشاهد المسجل: «\item $V$ is a function assigning to each !!{propositional».
  - **العربية المعيارية:** [السطر ٢٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/applied-modal-logic/temporal-logic/possible-histories.tex#L29)؛ الطبعة الدولية: [ص ٨٠٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=808) (ترقيم المتن: ٨٠٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٠٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=809) (ترقيم المتن: ٨٠٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تسند إلى كل~!!{propositional».
  - **العربية التراثية:** [السطر ٢٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/applied-modal-logic/temporal-logic/possible-histories.tex#L28)؛ الطبعة التراثية: [ص ٧٩٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=794) (ترقيم المتن: ٧٩٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تسند إلى كل~!!{propositional».
- **OLP-0500 — Relational models للمنطق الحدسي، وقوع ٢:**
  - **الأصل:** [السطر ٢٦](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/intuitionistic-logic/semantics/relational-models.tex#L26). الشاهد المسجل: «\item $V$ is a function assigning to each !!{propositional».
  - **العربية المعيارية:** [السطر ٢٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/intuitionistic-logic/semantics/relational-models.tex#L25)؛ الطبعة الدولية: [ص ٨٣٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=833) (ترقيم المتن: ٨٣٢) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٣٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=834) (ترقيم المتن: ٨٣٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تسند إلى كل~!!{propositional».
  - **العربية التراثية:** [السطر ٢٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/intuitionistic-logic/semantics/relational-models.tex#L24)؛ الطبعة التراثية: [ص ٨١٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=819) (ترقيم المتن: ٨١٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تسند إلى كل~!!{propositional».
- **OLP-0485 — النماذج العلائقية، وقوع ٣:**
  - **الأصل:** [السطر ٣٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/applied-modal-logic/epistemic-logic/relational-models.tex#L34). الشاهد المسجل: «\item $V$ is a function assigning to each !!{propositional».
  - **العربية المعيارية:** [السطر ٣٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/applied-modal-logic/epistemic-logic/relational-models.tex#L30)؛ الطبعة الدولية: [ص ٨١٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=812) (ترقيم المتن: ٨١١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨١٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=813) (ترقيم المتن: ٨١٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تسند إلى كل~!!{propositional».
  - **العربية التراثية:** [السطر ٢٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/applied-modal-logic/epistemic-logic/relational-models.tex#L28)؛ الطبعة التراثية: [ص ٧٩٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=798) (ترقيم المتن: ٧٩٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تسند إلى كل~!!{propositional».
- **OLP-0478 — دلالة المنطق الزمني، وقوع ٤:**
  - **الأصل:** [السطر ٧٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/applied-modal-logic/temporal-logic/temporal-logic-semantics.tex#L73). الشاهد المسجل: «\item $V$ is a function assigning to each !!{propositional».
  - **العربية المعيارية:** [السطر ٧٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/applied-modal-logic/temporal-logic/temporal-logic-semantics.tex#L74)؛ الطبعة الدولية: [ص ٨٠٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=805) (ترقيم المتن: ٨٠٤)، [ص ٨٠٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=806) (ترقيم المتن: ٨٠٥) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٠٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=806) (ترقيم المتن: ٨٠٥)، [ص ٨٠٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=807) (ترقيم المتن: ٨٠٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تسند إلى كل~!!{propositional».
  - **العربية التراثية:** [السطر ٧٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/applied-modal-logic/temporal-logic/temporal-logic-semantics.tex#L73)؛ الطبعة التراثية: [ص ٧٩١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=791) (ترقيم المتن: ٧٩٠)، [ص ٧٩٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=792) (ترقيم المتن: ٧٩١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تسند إلى كل~!!{propositional».
- **OLP-0412 — النماذج العلائقية، وقوع ٥:**
  - **الأصل:** [السطر ٢٥](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/normal-modal-logic/syntax-and-semantics/relational-models.tex#L25). الشاهد المسجل: «\item $V$ is a function assigning to each !!{propositional».
  - **العربية المعيارية:** [السطر ٢٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/normal-modal-logic/syntax-and-semantics/relational-models.tex#L24)؛ الطبعة الدولية: [ص ٧١١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=711) (ترقيم المتن: ٧١٠) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٧١٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=712) (ترقيم المتن: ٧١١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تعين لكل !!{propositional variable}~$p$ مجموعة».
  - **العربية التراثية:** [السطر ٢٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/normal-modal-logic/syntax-and-semantics/relational-models.tex#L24)؛ الطبعة التراثية: [ص ٦٩٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=697) (ترقيم المتن: ٦٩٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item $V$ دالة تعين لكل !!{propositional variable}~$p$ مجموعة».
- **OLP-0331 — مقدمة، وقوع ٦:**
  - **الأصل:** [السطر ٢٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/second-order-logic/metatheory/introduction.tex#L20). الشاهد المسجل: «enumerable}. There is a computable function~$f\colon \Nat \to».
  - **العربية المعيارية:** [السطر ٢٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/second-order-logic/metatheory/introduction.tex#L20)؛ الطبعة الدولية: [ص ٦١٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=610) (ترقيم المتن: ٦٠٩) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦١١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=611) (ترقيم المتن: ٦١٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «enumerable}. فثمة دالة قابلة للحساب~$f\colon \Nat \to».
  - **العربية التراثية:** [السطر ١٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/second-order-logic/metatheory/introduction.tex#L19)؛ الطبعة التراثية: [ص ٥٩٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=595) (ترقيم المتن: ٥٩٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «enumerable}. فهناك دالة قابلة للحساب~$f\colon \Nat \to».
- **OLP-0536 — ملحق في قانون فرغه الأساسي الخامس، وقوع ٧:**
  - **الأصل:** [السطر ٢٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/set-theory/story/grundgesetze.tex#L20). الشاهد المسجل: «``value-range'' of a function. Extensions of concepts are a special».
  - **العربية المعيارية:** [السطر ١٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/set-theory/story/grundgesetze.tex#L16)؛ الطبعة الدولية: [ص ٨٧٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=875) (ترقيم المتن: ٨٧٤) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٨٧٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=876) (ترقيم المتن: ٨٧٥) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «الصورية على مفهوم أعم هو «مدى قيم» دالة. وامتدادات المفاهيم حالة خاصة».
  - **العربية التراثية:** [السطر ١٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/set-theory/story/grundgesetze.tex#L16)؛ الطبعة التراثية: [ص ٨٦٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=860) (ترقيم المتن: ٨٥٩) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «الصورية على مفهوم أعم هو «مدى قيم» دالة. وامتدادات المفاهيم حالة خاصة».
- **OLP-0455 — الترشيحات منتهية، وقوع ٨:**
  - **الأصل:** [السطر ٣٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/normal-modal-logic/filtrations/finite.tex#L37). الشاهد المسجل: «there is !!a{injective} function from $W^*$ to $\Pow{\Gamma}$, and».
  - **العربية المعيارية:** [السطر ٣٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/normal-modal-logic/filtrations/finite.tex#L36)؛ الطبعة الدولية: [ص ٧٧٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=773) (ترقيم المتن: ٧٧٢) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٧٧٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=774) (ترقيم المتن: ٧٧٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «دالة !!a{injective} من~$W^*$ إلى~$\Pow{\Gamma}$، ولذلك».
  - **العربية التراثية:** [السطر ٣٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/normal-modal-logic/filtrations/finite.tex#L36)؛ الطبعة التراثية: [ص ٧٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=759) (ترقيم المتن: ٧٥٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فالمقابلة المذكورة دالة !!a{injective} من~$W^*$ إلى~$\Pow{\Gamma}$،».
- **OLP-0192 — introduction، وقوع ٩:**
  - **الأصل:** [السطر ١٦](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/model-theory/models-of-arithmetic/introduction.tex#L16). الشاهد المسجل: «function, $+$ is interpreted as addition and $\times$ as multiplication».
  - **العربية المعيارية:** [السطر ١٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/model-theory/models-of-arithmetic/introduction.tex#L14)؛ الطبعة الدولية: [ص ٤٠٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=404) (ترقيم المتن: ٤٠٣) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٠٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=404) (ترقيم المتن: ٤٠٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «و$<$ على النحو المتوقع. أي إن $\Obj{0}$ هو~$0$، و$\prime$ دالة الخلف،».
  - **العربية التراثية:** [السطر ١٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/model-theory/models-of-arithmetic/introduction.tex#L15)؛ الطبعة التراثية: [ص ٣٩٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=394) (ترقيم المتن: ٣٩٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «$\Obj{0}$ هو~$0$، وتأويل $\prime$ دالة الخلف، وتأويل $+$».
- **OLP-0587 — تعريف العمليات الأساسية، وقوع ١٠:**
  - **الأصل:** [السطر ٢٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/set-theory/card-arithmetic/opps.tex#L22). الشاهد المسجل: «where $\funfromto{X}{Y} = \Setabs{f}{f \text{ is a function } X \to Y}$.».
  - **العربية المعيارية:** [السطر ٢٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/set-theory/card-arithmetic/opps.tex#L23)؛ الطبعة الدولية: [ص ٩٣٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=932) (ترقيم المتن: ٩٣١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٩٣٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=933) (ترقيم المتن: ٩٣٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «$\funfromto{X}{Y} = \Setabs{f}{f \text{ دالة } X \to Y}$.».
  - **العربية التراثية:** [السطر ٢٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/set-theory/card-arithmetic/opps.tex#L23)؛ الطبعة التراثية: [ص ٩١٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=914) (ترقيم المتن: ٩١٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «$\funfromto{X}{Y} = \Setabs{f}{f \text{ دالة } X \to Y}$.».
- **OLP-0388 — المصفوفات، وقوع ١١:**
  - **الأصل:** [السطر ٢٥](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/many-valued-logic/syntax-and-semantics/matrices.tex#L25). الشاهد المسجل: «function~$\tf{\star} : V^n \to V$. If $n = 0$, then $\tf{\star}$ is».
  - **العربية المعيارية:** [السطر ٢٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/many-valued-logic/syntax-and-semantics/matrices.tex#L24)؛ الطبعة الدولية: [ص ٦٧٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=678) (ترقيم المتن: ٦٧٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٧٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=679) (ترقيم المتن: ٦٧٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item لكل رابط~$\star$ ذي~$n$ من المواضع في~$\Lang L$ دالة صدق».
  - **العربية التراثية:** [السطر ٢٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/many-valued-logic/syntax-and-semantics/matrices.tex#L24)؛ الطبعة التراثية: [ص ٦٦٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=662) (ترقيم المتن: ٦٦١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\item لكل رابط~$\star$ ذي~$n$ من المواضع في~$\Lang L$ دالة صدق».
- **OLP-0244 — خواص قابلية الاختزال، وقوع ١٢:**
  - **الأصل:** [السطر ٤٦](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/computability/computability-theory/prop-reduce.tex#L46). الشاهد المسجل: «claim, just check that if $B$ is the domain of a partial function~$g$,».
  - **العربية المعيارية:** [السطر ٤٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/computability/computability-theory/prop-reduce.tex#L45)؛ الطبعة الدولية: [ص ٤٧٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=470) (ترقيم المتن: ٤٦٩) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٧١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=471) (ترقيم المتن: ٤٧٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «الأول، يكفي التحقق من أنه إذا كانت $B$ مجال دالة جزئية~$g$، فإن $A$».
  - **العربية التراثية:** [السطر ٤٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/computability/computability-theory/prop-reduce.tex#L45)؛ الطبعة التراثية: [ص ٤٦٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=462) (ترقيم المتن: ٤٦١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «الأول، فلنجعل $B$ مجال دالة جزئية قابلة للحساب~$g$؛ فتكون $A$».
- **OLP-0699 — في تفسير القواعد، وقوع ١٣:**
  - **الأصل:** [السطر ٣٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/proof-theory/sequent-calculus/interpretation-rules.tex#L33). الشاهد المسجل: «fact that every truth-function in classical logic can be described by».
  - **العربية المعيارية:** [السطر ٣٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/proof-theory/sequent-calculus/interpretation-rules.tex#L30)؛ الطبعة الدولية: [ص ١١٢٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=1129) (ترقيم المتن: ١٠٩) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ١١٣٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=1130) (ترقيم المتن: ١٠٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «المتتاليات. وينتج ذلك من إمكان وصف كل دالة صدق في المنطق الكلاسيكي».
  - **العربية التراثية:** [السطر ٣٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/proof-theory/sequent-calculus/interpretation-rules.tex#L30)؛ الطبعة التراثية: [ص ١١١٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=1110) (ترقيم المتن: ١٠٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «المتتاليات. وينتج ذلك من إمكان وصف كل دالة صدق في المنطق الكلاسيكي».
- **OLP-0385 — مقدمة، وقوع ١٤:**
  - **الأصل:** [السطر ٢٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/many-valued-logic/syntax-and-semantics/introduction.tex#L27). الشاهد المسجل: «many-valued logic, !!a{valuation}~$\pAssign{v}$ is a function».
  - **العربية المعيارية:** [السطر ٢٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/many-valued-logic/syntax-and-semantics/introduction.tex#L26)؛ الطبعة الدولية: [ص ٦٧٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=676) (ترقيم المتن: ٦٧٥) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٧٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=677) (ترقيم المتن: ٦٧٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «!!a{valuation}~$\pAssign{v}$ في المنطق المتعدد القيم دالة تسند إلى كل».
  - **العربية التراثية:** [السطر ٢٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/many-valued-logic/syntax-and-semantics/introduction.tex#L26)؛ الطبعة التراثية: [ص ٦٦٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=660) (ترقيم المتن: ٦٥٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «دالة تسند إلى كل~!!{propositional variable}~$p$ عنصرًا من مجموعة».
- **OLP-0618 — الاستقراء البنيوي، وقوع ١٥:**
  - **الأصل:** [السطر ٢٩](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/methods/induction/structural-induction.tex#L29). الشاهد المسجل: «operation is the successor function~$x + 1$.».
  - **العربية المعيارية:** [السطر ٢٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/methods/induction/structural-induction.tex#L27)؛ الطبعة الدولية: [ص ٩٨٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=982) (ترقيم المتن: ٩٨١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٩٨٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=983) (ترقيم المتن: ٩٨٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «بتعريف استقرائي: فالشيء الأولي هو~$0$، والعملية هي دالة الخلف~$x + 1$.».
  - **العربية التراثية:** [السطر ٢٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/methods/induction/structural-induction.tex#L26)؛ الطبعة التراثية: [ص ٩٦١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=961) (ترقيم المتن: ٩٦٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فالابتداء بـ~$0$، والعملية دالة الخلف~$x + 1$.».
- **OLP-0390 — مفاهيم دلالية، وقوع ١٦:**
  - **الأصل:** [السطر ٦٨](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/many-valued-logic/syntax-and-semantics/semantic-notions.tex#L68). الشاهد المسجل: «do depends on the truth function~$\tf{\lif}$.».
  - **العربية المعيارية:** [السطر ٦٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/many-valued-logic/syntax-and-semantics/semantic-notions.tex#L67)؛ الطبعة الدولية: [ص ٦٨٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=680) (ترقيم المتن: ٦٧٩) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٨١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=681) (ترقيم المتن: ٦٨٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «في المنطقات المتعددة القيم؛ إذ يعتمد صدقها على دالة الصدق~$\tf{\lif}$.».
  - **العربية التراثية:** [السطر ٦٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/many-valued-logic/syntax-and-semantics/semantic-notions.tex#L67)؛ الطبعة التراثية: [ص ٦٦٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=664) (ترقيم المتن: ٦٦٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «في كل منطق متعدد القيم؛ إذ يتوقف صدقها على دالة الصدق~$\tf{\lif}$.».
- **OLP-0260 — الآلات المنضبطة، وقوع ١٧:**
  - **الأصل:** [السطر ٨٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/turing-machines/machines-computations/disciplined-machines.tex#L82). الشاهد المسجل: «In particular, any function $f\colon\Nat^n \to \Nat$ computable by a».
  - **العربية المعيارية:** [السطر ٧٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/turing-machines/machines-computations/disciplined-machines.tex#L76)؛ الطبعة الدولية: [ص ٤٩٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=494) (ترقيم المتن: ٤٩٣) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٩٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=495) (ترقيم المتن: ٤٩٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «تتوقف~$M$. وعلى وجه الخصوص، كل دالة $f\colon\Nat^n\to\Nat$ تحسبها».
  - **العربية التراثية:** [السطر ٥٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/turing-machines/machines-computations/disciplined-machines.tex#L57)؛ الطبعة التراثية: [ص ٤٨٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=486) (ترقيم المتن: ٤٨٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «لكل آلة تورنغ~$M$ آلة منضبطة~$M'$، تقف بخرج~$O$ متى وقفت $M$ بخرج~$O$، ولا تقف متى لم تقف~$M$. ومن ثم فإن كل دالة $f\colon\Nat^n\to\Nat$ تحسبها آلة تورنغ تحسبها آلة منضبطة أيضًا.».
- **OLP-0332 — حساب الرتبة الثانية، وقوع ١٨:**
  - **الأصل:** [السطر ١١٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/second-order-logic/metatheory/second-order-arithmetic.tex#L117). الشاهد المسجل: «function $u$ such that $u(0)=k$, $u(n')=u(n)'$ for all $n$, and $m = u(l)$.».
  - **العربية المعيارية:** [السطر ١١٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/second-order-logic/metatheory/second-order-arithmetic.tex#L117)؛ الطبعة الدولية: [ص ٦١٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=612) (ترقيم المتن: ٦١١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦١٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=613) (ترقيم المتن: ٦١٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «دالة~$u$ بحيث~$u(0)=k$ و$u(n')=u(n)'$ لكل~$n$، و$m = u(l)$.».
  - **العربية التراثية:** [السطر ١١٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/second-order-logic/metatheory/second-order-arithmetic.tex#L119)؛ الطبعة التراثية: [ص ٥٩٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=597) (ترقيم المتن: ٥٩٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وأما الجمع، فإن~$k+l=m$ إذا وفقط إذا وجدت دالة~$u$».
- **OLP-0598 — اعتبارات داخلية بشأن الاختيار، وقوع ١٩:**
  - **الأصل:** [السطر ٤٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/set-theory/choice/justifications.tex#L44). الشاهد المسجل: «a choice function for $A$. So, to justify Choice, we can simply try to».
  - **العربية المعيارية:** [السطر ٣٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/set-theory/choice/justifications.tex#L36)؛ الطبعة الدولية: [ص ٩٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=948) (ترقيم المتن: ٩٤٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٩٤٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=949) (ترقيم المتن: ٩٤٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «النقطة الجوهرية هي أن مجموعة اختيار لـ$A$ ليست إلا مدى دالة اختيار».
  - **العربية التراثية:** [السطر ٣٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/set-theory/choice/justifications.tex#L37)؛ الطبعة التراثية: [ص ٩٣٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=930) (ترقيم المتن: ٩٢٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ومدار الأمر أن مجموعة الاختيار لـ~$A$ ليست إلا مدى دالة اختيار».
- **OLP-0556 — الأعداد الترتيبية بوصفها أنماط ترتيب، وقوع ٢٠:**
  - **الأصل:** [السطر ٢٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/set-theory/ordinals/ordtype.tex#L27). الشاهد المسجل: «by Replacement, the following set exists, and is a function:».
  - **العربية المعيارية:** [السطر ٢٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/set-theory/ordinals/ordtype.tex#L28)؛ الطبعة الدولية: [ص ٨٩٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=895) (ترقيم المتن: ٨٩٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٩٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=896) (ترقيم المتن: ٨٩٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وهي دالة:».
  - **العربية التراثية:** [السطر ٢٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/set-theory/ordinals/ordtype.tex#L25)؛ الطبعة التراثية: [ص ٨٧٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=878) (ترقيم المتن: ٨٧٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وهو وحيد لما تقدم. ومن ثم يضمن الاستبدال وجود المجموعة الآتية، وهي دالة:».

## الدوال بوصفها علاقات

الأصل الإنجليزي: `Functions as Relations`. معرّف القرار: `retro-0005-0050:section:47bb7d5c2b95258c`.

**المعنى المقصود:** معاملة الدالة بوصفها علاقة الأزواج ⟨x,y⟩ التي تحقق f(x)=y.

**سبب الاختيار:** تحفظ «الدوال بوصفها علاقات» معنى as؛ إذ يقول القسم إن الدالة تعين تلك العلاقة ويجوز تعريفها بها. وهي لا تضعف العنوان إلى مجرد عطف بين الدوال والعلاقات.

**سؤال مفتوح:** سؤال أسلوبي اختياري: «بوصفها» أم «باعتبارها»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0023 — الدوال بوصفها علاقات، وقوع ١:**
  - **الأصل:** [السطر ١٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/functions-relations.tex#L12). الشاهد المسجل: «\olsection{Functions as Relations}».
  - **العربية المعيارية:** [السطر ١٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/functions-relations.tex#L12)؛ الطبعة الدولية: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=56) (ترقيم المتن: ٥٥) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=56) (ترقيم المتن: ٥٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{الدوال بوصفها علاقات}».
  - **العربية التراثية:** [السطر ١٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/functions-relations.tex#L12)؛ الطبعة التراثية: [ص ٥٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=53) (ترقيم المتن: ٥٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{الدوال بوصفها علاقات}».

## قراءات إضافية

الأصل الإنجليزي: `further reading`. معرّف القرار: `locale-ar-chosen-a47a6e2bcb010209`.

**المعنى المقصود:** عبارة تحريرية تعني قائمة مواد ينظر فيها القارئ بعد النص؛ قورنت الصياغتان العربية الحديثة والكلاسيكية.

**سبب الاختيار:** لا يغيَّر المصدر. العربية الحديثة تقول «قراءات إضافية»، والكلاسيكية تعيد المعنى بـ«قراءات للاستزادة». كلاهما يؤدي list of further reading، لكن الثاني أوفق بالسجل الكلاسيكي وأصرح بالغرض، بينما الأول أقرب إلى عنوان ببليوغرافي حديث. البحث المحدود في معجم الرياضيات لم يجد العبارة الإنجليزية أو الصيغتين، وهو أمر متوقع لمادة تحريرية لا رأس رياضي.

**سؤال مفتوح:** في عبارة a list of further reading، هل تُفضَّل «قائمة بقراءات إضافية» في العربية الحديثة و«قراءات للاستزادة» في الكلاسيكية كما هو الآن، أم ينبغي توحيدهما على «مراجع للاستزادة» أو «قراءات مقترحة»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0001 — في التعريف بمشروع المنطق المفتوح، وقوع ١:**
  - **الأصل:** [السطر ١١](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/open-logic-about.tex#L11). الشاهد المسجل: «Coverage of some topics currently included may not yet be complete, and many sections still require substantial revision. We plan to expand the text to cover more topics in the future. We also plan to add features to the text, such as a glossary, a list of…».
  - **العربية المعيارية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/open-logic-about.tex#L10)؛ الطبعة الدولية: [ص ٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=2) (ترقيم المتن: ١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=2) (ترقيم المتن: ١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «قد لا تكون تغطية بعض الموضوعات المدرجة حاليًا مكتملة بعد، ولا تزال أقسام كثيرة بحاجة إلى مراجعة مستفيضة. ونخطط لتوسيع النص مستقبلًا ليشمل موضوعات أخرى. كما نخطط لإضافة عناصر إلى النص، منها مسرد للمصطلحات، وقائمة بقراءات إضافية، وملاحظات تاريخية، وصور، وشروح…».

## ساذجة حقًا

الأصل الإنجليزي: `genuinely na\"ive`. معرّف القرار: `retro-0005-0050:emphasis:82aab39aec996c01`.

**المعنى المقصود:** وصف مؤكد لنظرية المجموعات في الفصل بأنها ساذجة حقًا.

**سبب الاختيار:** تحفظ «ساذجة حقًا» الصفة الفنية والظرف المؤكد معًا، ويقابلها الكلام التالي بالبناء البديهي الصارم.

**سؤال مفتوح:** سؤال أسلوبي اختياري: «حقًا» أم «بالفعل»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0010 — مفارقة راسل، وقوع ١:**
  - **الأصل:** [السطر ٨٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/sets/russells-paradox.tex#L80). الشاهد المسجل: «\emph{genuinely na\"ive}. It tells you only that sets obey».
  - **العربية المعيارية:** [السطر ٧٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/sets/russells-paradox.tex#L77)؛ الطبعة الدولية: [ص ٣٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=39) (ترقيم المتن: ٣٨) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٣٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=39) (ترقيم المتن: ٣٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{ساذجة حقًا}. % حفظ أمر تشكيل غير منفذ من المصدر: \"».
  - **العربية التراثية:** [السطر ٧١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/sets/russells-paradox.tex#L71)؛ الطبعة التراثية: [ص ٣٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=38) (ترقيم المتن: ٣٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{ساذجة حقًا}. % حفظ أمر تشكيل غير منفذ من المصدر: \"».

## الرسم البياني

الأصل الإنجليزي: `graph`. معرّف القرار: `retro-0005-0050:emphasis:a0f7cfeca66f46ba`.

**المعنى المقصود:** بيان توافقي ذو رؤوس/عقد وحواف، لا رسم دالة إحداثي.

**سبب الاختيار:** المقصود ليس منحنى دالة. و«الرسم البياني» مفهومة، لكن معجم دمشق يجعل المدخل المطابق «بيان»، ويسمي graph theory «نظرية البيان»، ويفرد graphical representation بـ«تمثيل بياني».

**سؤال مفتوح:** هل ينبغي نقل عائلة graph إلى «بيان»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0017 — الرسوم البيانية، وقوع ١:**
  - **الأصل:** [السطر ١٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/graphs.tex#L12). الشاهد المسجل: «A \emph{graph} is a diagram in which points---called ``nodes'' or».
  - **العربية المعيارية:** [السطر ١٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/graphs.tex#L12)؛ الطبعة الدولية: [ص ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=48) (ترقيم المتن: ٤٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=48) (ترقيم المتن: ٤٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{الرسم البياني} مخطط ترتبط فيه نقاط---تسمى «عقدًا» أو «رؤوسًا»».
  - **العربية التراثية:** [السطر ١٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/graphs.tex#L12)؛ الطبعة التراثية: [ص ٤٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=46) (ترقيم المتن: ٤٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{الرسم البياني} مخطط من نقاط تصل بينها حواف؛ وتسمى النقاط».

## الرسم البياني لدالة

الأصل الإنجليزي: `Graph of a function`. معرّف القرار: `retro-0005-0050:named-defn:ed41058893b07663`.

**المعنى المقصود:** بيان الدالة f:A→B بوصفه العلاقة R_f من الأزواج المرتبة التي تحقق f(x)=y.

**سبب الاختيار:** يطابق التعريف عبارة معجم دمشق «بيان دالة f» تمامًا. أما «الرسم البياني» الحالية فواضحة، لكنها قد توهم منحنى إحداثيًا؛ ويميز المرجع التمثيل البياني صراحةً.

**سؤال مفتوح:** أنستعمل «بيان دالة» بدل «الرسم البياني لدالة»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0023 — الدوال بوصفها علاقات، وقوع ١:**
  - **الأصل:** [السطر ٢٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/functions-relations.tex#L24). الشاهد المسجل: «\begin{defn}[Graph of a function] Let $f\colon A \to B$ be a function.».
  - **العربية المعيارية:** [السطر ٢٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/functions-relations.tex#L24)؛ الطبعة الدولية: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=56) (ترقيم المتن: ٥٥) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=56) (ترقيم المتن: ٥٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{defn}[الرسم البياني لدالة] لتكن $f\colon A \to B$ دالة.».
  - **العربية التراثية:** [السطر ٢٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/functions-relations.tex#L22)؛ الطبعة التراثية: [ص ٥٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=54) (ترقيم المتن: ٥٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{defn}[الرسم البياني لدالة]».

## الرسم البياني لدالة جزئية

الأصل الإنجليزي: `Graph of a partial function`. معرّف القرار: `retro-0005-0050:named-defn:7ed8c843e8260baf`.

**المعنى المقصود:** بيان الدالة الجزئية f:A⇀B بوصفه علاقة الأزواج المرتبة التي تحقق f(x)=y.

**سبب الاختيار:** هذا نظير الدالة الجزئية للسجل السابق. وينطبق تركيب «بيان دالة» المرجعي بإضافة «جزئية»، بينما تظل الصيغة الحالية معرضة لقراءة الرسم الإحداثي.

**سؤال مفتوح:** هل ينسق هذا السجل مع السابق بصيغة «بيان دالة جزئية»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0026 — الدوال الجزئية، وقوع ١:**
  - **الأصل:** [السطر ٥٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/partial-functions.tex#L50). الشاهد المسجل: «\begin{defn}[Graph of a partial function]».
  - **العربية المعيارية:** [السطر ٤٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/partial-functions.tex#L49)؛ الطبعة الدولية: [ص ٦١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=61) (ترقيم المتن: ٦٠) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=61) (ترقيم المتن: ٦٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{defn}[الرسم البياني لدالة جزئية]».
  - **العربية التراثية:** [السطر ٤٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/partial-functions.tex#L47)؛ الطبعة التراثية: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{defn}[الرسم البياني لدالة جزئية]».

## الرسوم البيانية

الأصل الإنجليزي: `Graphs`. معرّف القرار: `retro-0005-0050:section:d67c3ac71144bab2`.

**المعنى المقصود:** عنوان القسم الخاص بالبيانات التوافقية.

**سبب الاختيار:** «الرسوم البيانية» مقروءة، لكن معجم دمشق يستعمل «بيان» و«نظرية البيان». غير أن جمع «بيان» على «بيانات» يلتبس بـdata، فلا يصلح إصلاح العنوان آليًا.

**سؤال مفتوح:** أيهما أصلح للعنوان: «الرسوم البيانية» أم «البيانات» أم «نظرية البيان»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0017 — الرسوم البيانية، وقوع ١:**
  - **الأصل:** [السطر ١٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/graphs.tex#L10). الشاهد المسجل: «\olsection{Graphs}».
  - **العربية المعيارية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/graphs.tex#L10)؛ الطبعة الدولية: [ص ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=48) (ترقيم المتن: ٤٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=48) (ترقيم المتن: ٤٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{الرسوم البيانية}».
  - **العربية التراثية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/graphs.tex#L10)؛ الطبعة التراثية: [ص ٤٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=46) (ترقيم المتن: ٤٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{الرسوم البيانية}».

## أكبر من

الأصل الإنجليزي: `greater than`. معرّف القرار: `retro-0005-0050:emphasis:9b85b8b524222bc2`.

**المعنى المقصود:** علاقة أكبر من الصارمة G: يتحقق Gnm إذا وفقط إذا كان n>m.

**سبب الاختيار:** تحدد الصيغة المعنى، ويطبع معجم دمشق «أكبر من» في قائمة المتباينات ويستعمل «علاقة أكبر من» مثالًا صريحًا للعلاقات.

**سؤال مفتوح:** سؤال اختياري في علامات الترقيم فقط.

**كل وقوع مسجل لهذا القرار:**

- **OLP-0012 — العلاقات بوصفها مجموعات، وقوع ١:**
  - **الأصل:** [السطر ٩٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/relations-as-sets.tex#L97). الشاهد المسجل: «is the \emph{greater than} relation, i.e., $Gnm$ iff $n>m$. The union».
  - **العربية المعيارية:** [السطر ٩٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/relations-as-sets.tex#L94)؛ الطبعة الدولية: [ص ٤٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=42) (ترقيم المتن: ٤١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=42) (ترقيم المتن: ٤١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «هي علاقة \emph{أكبر من}، أي إن $Gnm$ إذا وفقط إذا كان $n>m$. واتحاد».
  - **العربية التراثية:** [السطر ٨٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/relations-as-sets.tex#L87)؛ الطبعة التراثية: [ص ٤١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=41) (ترقيم المتن: ٤٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وهي علاقة \emph{أكبر من}؛ فـ$Gnm$ يكافئ $n>m$. وإذا ضممنا».

## علاقة أكبر من أو يساوي.

الأصل الإنجليزي: `greater than or equal to relation.`. معرّف القرار: `retro-0005-0050:emphasis:d3c7c35999499217`.

**المعنى المقصود:** الترتيب غير الصارم H=G∪I: أي n≥m.

**سبب الاختيار:** تحدد المعادلة والجملة المجاورة عن ≤ المعنى. ويعطي معجم دمشق «a أكبر من b أو يساويه». أما الوسم الحالي «علاقة أكبر من أو يساوي.» ففيه فعل مجرد من مفعوله ونقطة المصدر داخل التوكيد؛ ويكون الاقتباس أو الاسمية أوضح.

**سؤال مفتوح:** أنقتبس «أكبر من أو يساوي» أم نستعمل اسمًا اسميًا للعلاقة؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0012 — العلاقات بوصفها مجموعات، وقوع ١:**
  - **الأصل:** [السطر ١٠٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/relations-as-sets.tex#L100). الشاهد المسجل: «I$ is the \emph{greater than or equal to relation.} These relations».
  - **العربية المعيارية:** [السطر ٩٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/relations-as-sets.tex#L97)؛ الطبعة الدولية: [ص ٤٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=42) (ترقيم المتن: ٤١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=42) (ترقيم المتن: ٤١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «$H=G \cup I$ هي \emph{علاقة أكبر من أو يساوي.} والعلاقات $L$ و$G$ و$K$».
  - **العربية التراثية:** [السطر ٩٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/relations-as-sets.tex#L90)؛ الطبعة التراثية: [ص ٤١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=41) (ترقيم المتن: ٤٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{علاقة أكبر من أو يساوي.} فهذه العلاقات $L$ و$G$ و$K$ و$H$».

## فندق هيلبرت

الأصل الإنجليزي: `Hilbert's Hotel`. معرّف القرار: `retro-0005-0050:section:f77f7158698596d2`.

**المعنى المقصود:** مسألة فندق هيلبرت اللانهائي التي تستوعب نزيلًا جديدًا بالإزاحة n→n+1.

**سبب الاختيار:** «فندق هيلبرت» عنوان حرفي مطابق للمصدر. ويثبت معجم دمشق المسألة نفسها باسمَي «محيرة هيلبرت» و«محيرة الفندق اللانهائي»، فيوثق المرجع مع اختلاف العنوان.

**سؤال مفتوح:** أنبقي العنوان الحرفي أم نشير إلى تسمية المحيرة/المفارقة المرجعية؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0050 — فندق هيلبرت، وقوع ١:**
  - **الأصل:** [السطر ١٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/infinite/hilberts-hotel.tex#L10). الشاهد المسجل: «\olsection{Hilbert's Hotel}».
  - **العربية المعيارية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/infinite/hilberts-hotel.tex#L10)؛ الطبعة الدولية: [ص ١٠٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=103) (ترقيم المتن: ١٠٢) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ١٠٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=103) (ترقيم المتن: ١٠٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{فندق هيلبرت}».
  - **العربية التراثية:** [السطر ١٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/infinite/hilberts-hotel.tex#L10)؛ الطبعة التراثية: [ص ٩٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=99) (ترقيم المتن: ٩٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{فندق هيلبرت}».

## فندق هيلبرت؛ لانهائية بحسب ديديكند؛ مجموعة جزئية حقيقية

الأصل الإنجليزي: `Hilbert's Hotel; Dedekind infinite; proper subset`. معرّف القرار: `locale-ar-chosen-dad1d56d44c1421c`.

**المعنى المقصود:** عنوان مثال هيلبرت وتعريف ديديكند للانهاية بوجود حقن في جزء حقيقي، مع حفظ الحرف o ونطاق الدالة.

**سبب الاختيار:** قُرئت الوحدة كاملة في اللغات الثلاث وربطت لأول مرة بمواضع دقيقة. يحفظ «فندق هيلبرت» الاسم والمثال، و«لانهائية بحسب ديديكند» نسبة التعريف، وتبقي الصيغتان العربيتان الحرف o عنصرًا لا صفرًا. لكن المعجم يسمي infinite hotel paradox «محيرة الفندق اللانهائي»، ويسمي proper subset «مجموعة جزئية فعلية»، بينما النص الحديث يقول «مجموعة جزئية حقيقية» والكلاسيكي «جزء حقيقي». هذه فروق تستحق السؤال ولا تثبت خطأ النص آليًا.

**سؤال مفتوح:** في OLP-0050، هل تُبقى «فندق هيلبرت؛ لانهائية بحسب ديديكند؛ مجموعة جزئية حقيقية/جزء حقيقي»، أم ينبغي اعتماد «محيرة الفندق اللانهائي» للعنوان و«مجموعة جزئية فعلية» لـ proper subset اتباعًا للمعجم؟ وهل «بحسب ديديكند» أدق من «ديديكندية» في هذا التعريف؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0050 — فندق هيلبرت، وقوع ١:**

## الحصان

الأصل الإنجليزي: `horse`. معرّف القرار: `retro-0005-0050:emphasis:9db5528ad994aa22`.

**المعنى المقصود:** الاسم “horse” داخل الاسم الفلسفي الثابت «مفارقة مفهوم الحصان عند فريغه»؛ فالحديث عن اللفظ نفسه.

**سبب الاختيار:** لا يعالج النص حيوانًا معالجةً رياضية، بل يستحضر مفارقة فريغه في «مفهوم الحصان». ويحفظ الشاهدان «مفارقة مفهوم الحصان عند فريغه». و«الحصان» حرفية وواضحة، لكن علامتي الاقتباس قد تبرزان ذكر اللفظ بدل استعماله.

**سؤال مفتوح:** أنبقي «الحصان» مؤكدةً أم نقتبس «الحصان/حصان» لإظهار ذكر اللفظ؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0013 — تأملات فلسفية، وقوع ١:**
  - **الأصل:** [السطر ٦٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/reflections.tex#L67). الشاهد المسجل: «together a simple version of Frege's concept \emph{horse} paradox, and».
  - **العربية المعيارية:** [السطر ٦١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/reflections.tex#L61)؛ الطبعة الدولية: [ص ٤٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=43) (ترقيم المتن: ٤٢) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=43) (ترقيم المتن: ٤٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «حالة خاصة. (وهذا يجمع صيغة بسيطة من مفارقة مفهوم \emph{الحصان} عند فريغه».
  - **العربية التراثية:** [السطر ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/reflections.tex#L55)؛ الطبعة التراثية: [ص ٤٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=42) (ترقيم المتن: ٤١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ويجتمع في هذا الوجه تبسيط لمفارقة مفهوم \emph{الحصان} عند فريغه».

## مماهاة

الأصل الإنجليزي: `identify`. معرّف القرار: `retro-0005-0050:emphasis:14f9801d22e652b6`.

**المعنى المقصود:** اتخاذ الدالة نفسها، على سبيل الاصطلاح التمثيلي، هي علاقتها/رسمها أي مجموعة الأزواج المرتبة؛ وليس ادعاء هوية ميتافيزيقية.

**سبب الاختيار:** الجملة الإنجليزية تقول identify the function f with this relation، ويصرح النص العربي الكلاسيكي عقبها بأن المقصود العلاقة أي مجموعة الأزواج. «مماهاة» تلتقط فعل التسوية الاصطلاحية وتلائم التحذير اللاحق من فهمه ميتافيزيقيًا، لكنها أثقل من بدائل الشرح ولا يشهد لها مدخل DAM مطابق.

**سؤال مفتوح:** هل تفضل «مماهاة» أم صياغة شارحة مثل «معاملة الدالة بوصفها علاقتها» لتفادي إيحاء الهوية الميتافيزيقية؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0023 — الدوال بوصفها علاقات، وقوع ١:**
  - **الأصل:** [السطر ١٩](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/functions-relations.tex#L19). الشاهد المسجل: «mathematics for instance---\emph{identify} the function~$f$ with this».
  - **العربية المعيارية:** [السطر ١٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/functions-relations.tex#L19)؛ الطبعة الدولية: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=56) (ترقيم المتن: ٥٥) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=56) (ترقيم المتن: ٥٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «الرياضيات---إلى \emph{مماهاة} الدالة~$f$ بهذه».
  - **العربية التراثية:** [السطر ١٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/functions-relations.tex#L18)؛ الطبعة التراثية: [ص ٥٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=54) (ترقيم المتن: ٥٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{مماهاة}~$f$ بهذه العلاقة، أي بمجموعة الأزواج.».

## مماهاة الدالة برسمها البياني؛ معاملة الدوال بوصفها مجموعات

الأصل الإنجليزي: `identify a function with its graph; treat functions as sets`. معرّف القرار: `locale-ar-chosen-bd169dfee8227f52`.

**المعنى المقصود:** اتخاذ الرسم البياني للدالة تمثيلًا مجموعاتيًا نافعًا دون ادعاء هوية ميتافيزيقية غير مقيدة.

**سبب الاختيار:** تُبقى «مماهاة/معاملة» مؤقتًا لأن المواضع الإنجليزية والعربية الحديثة والكلاسيكية تحافظ على القيد الفلسفي: يجوز تمثيل الدالة برسمها ومعاملتها مجموعة، وليس ذلك دعوى في ماهيتها. ويعرّف المعجم function نفسه بصفته مجموعة أزواج مرتبة، كما يعرّف set of ordered pairs؛ فهذا يسند البناء الرياضي، لا اختيار فعلي «مماهاة» و«معاملة» حرفيًا.

**سؤال مفتوح:** هل يؤدي «مماهاة الدالة برسمها البياني» و«معاملة الدوال بوصفها مجموعات» القيد المقصود بوضوح، أم تُفضَّل «اعتبار الدالة رسمها البياني/تمثيلها به» لتجنب إيحاء الهوية الميتافيزيقية؟ وهل يكفي التنبيه الحالي لإبقاء المماهاة؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0023 — الدوال بوصفها علاقات، وقوع ١:**
  - **الأصل:** [السطر ١٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/functions-relations.tex#L14). الشاهد المسجل: «\begin{explain} A function which maps !!{element}s of~$A$ to !!{element}s of~$B$ obviously defines a relation between $A$ and~$B$, namely the relation which holds between $x$ and $y$ iff $f(x) = y$. In fact, we might even---if we are interested in reducing…».
  - **الأصل:** [السطر ٦٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/functions-relations.tex#L60). الشاهد المسجل: «\begin{explain} Every function $f\colon A \to B$ has a graph, i.e., a relation on $A \times B$ defined by $f(x) = y$. On the other hand, every relation~$R \subseteq A \times B$ with the properties given in \olref{prop:graph-function} is the graph of a funct…».
  - **العربية المعيارية:** [السطر ١٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/functions-relations.tex#L14)؛ الطبعة الدولية: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=56) (ترقيم المتن: ٥٥) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=56) (ترقيم المتن: ٥٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{explain} إن الدالة التي ترسل !!{element}s المجموعة~$A$ إلى !!{element}s المجموعة~$B$ تحدد بوضوح علاقة بين $A$ و~$B$، هي العلاقة التي تقوم بين $x$ و$y$ إذا وفقط إذا كان $f(x) = y$. بل قد يصل بنا الأمر--- إذا كنا مهتمين، مثلًا، بردّ اللبنات الأساسية ال…».
  - **العربية المعيارية:** [السطر ٦٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/functions-relations.tex#L60)؛ الطبعة الدولية: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=56) (ترقيم المتن: ٥٥)، [ص ٥٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=57) (ترقيم المتن: ٥٦) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=56) (ترقيم المتن: ٥٥)، [ص ٥٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=57) (ترقيم المتن: ٥٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{explain} لكل دالة $f\colon A \to B$ رسم بياني، أي علاقة بين $A$ و~$B$ محتواة في~$A \times B$ يعرّفها الشرط $f(x) = y$. ومن جهة أخرى، فإن كل علاقة~$R \subseteq A \times B$ تتصف بالخاصيتين الواردتين في \olref{prop:graph-function} هي الرسم البياني لدالة…».

## علاقة الهوية على

الأصل الإنجليزي: `identity relation on`. معرّف القرار: `retro-0005-0050:emphasis:8a4bb9c85cd6c30e`.

**المعنى المقصود:** العلاقة القطرية على مجموعة الأعداد الطبيعية: جميع الأزواج المرتبة ⟨n,n⟩ ولا غيرها.

**سبب الاختيار:** التعريف المجاور يثبت الامتداد مباشرة، فتؤدي «علاقة الهوية على» معنى identity relation on من غير خلط بعلاقة تكافؤ عامة. يشهد DAM لـ identity function وidentity mapping بصيغ «مطابقة/مطابق»، ويورد equals relation بصيغة «علاقة مساواة»، لكنه لا يثبت العبارة الحالية حرفيًا؛ لذلك تبقى المفاضلة الاصطلاحية مفتوحة.

**سؤال مفتوح:** أيستقر اسم العلاقة القطرية على «علاقة الهوية» أم «علاقة المطابقة» مع مراعاة اتساق أسرة identity؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0012 — العلاقات بوصفها مجموعات، وقوع ١:**
  - **الأصل:** [السطر ٨٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/relations-as-sets.tex#L83). الشاهد المسجل: «is the \emph{identity relation on}~$\Nat$. (Since the identity».
  - **العربية المعيارية:** [السطر ٨١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/relations-as-sets.tex#L81)؛ الطبعة الدولية: [ص ٤٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=42) (ترقيم المتن: ٤١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=42) (ترقيم المتن: ٤١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «هي \emph{علاقة الهوية على}~$\Nat$. (ولشيوع علاقة الهوية، نعرّف».
  - **العربية التراثية:** [السطر ٧٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/relations-as-sets.tex#L74)؛ الطبعة التراثية: [ص ٤١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=41) (ترقيم المتن: ٤٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «هي \emph{علاقة الهوية على}~$\Nat$. ولشيوع هذه العلاقة نجعل».

## علاقة الهوية؛ مطابق لـ

الأصل الإنجليزي: `identity relation; is identical with`. معرّف القرار: `locale-ar-chosen-a20adea131af6ddb`.

**المعنى المقصود:** العلاقة القطرية التي تربط كل عنصر بنفسه وحده، مع تمييزها عن علاقة تكافؤ عامة وعن مساواة الصيغ خارج المجال.

**سبب الاختيار:** تُبقى «علاقة الهوية؛ مطابق لـ» مؤقتًا لأن الوقائع الأربعة تضبط العلاقة القطرية نفسها. لا يجد البحث المحدود identity relation أو «علاقة الهوية» في المعجم، لكنه يورد identity بصيغة «مطابقة (متطابقة)»، وidentity function «دالة مطابقة»، وidentity mapping «تطبيق مطابق». فهذا يسند جذر «مطابق» مباشرة ويجعل «علاقة المطابقة» بديلًا مؤسسي الصلة، دون أن يثبت أنه أفضل من «علاقة الهوية» في المنطق.

**سؤال مفتوح:** هل يُعتمد «علاقة الهوية» للرأس identity relation و«مطابق لـ» للفعل is identical with، أم تُفضَّل «علاقة المطابقة» اتساقًا مع identity function/mapping في المعجم؟ وكيف يُحفظ الفرق عن «علاقة المساواة» وعن علاقة تكافؤ عامة؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0012 — العلاقات بوصفها مجموعات، وقوع ١:**
  - **الأصل:** [السطر ١٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/relations-as-sets.tex#L17). الشاهد المسجل: «relation} on it. There is also the relation \emph{is identical with}».
  - **العربية المعيارية:** [السطر ١٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/relations-as-sets.tex#L17)؛ الطبعة الدولية: [ص ٤١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=41) (ترقيم المتن: ٤٠) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=41) (ترقيم المتن: ٤٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{«مطابق لـ»}، التي تقوم بين كل كائن ونفسه ولا تقوم بينه وبين أي شيء».
  - **العربية التراثية:** [السطر ١٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/relations-as-sets.tex#L16)؛ الطبعة التراثية: [ص ٤٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=40) (ترقيم المتن: ٣٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{«مطابق لـ»} بين كل شيء ونفسه دون غيره. وسنعرض علاقات كثيرة».
- **OLP-0015 — علاقات التكافؤ، وقوع ٢:**
  - **الأصل:** [السطر ١٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/equivalence-relations.tex#L13). الشاهد المسجل: «The identity relation on a set is reflexive, symmetric, and».
  - **العربية المعيارية:** [السطر ١٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/equivalence-relations.tex#L13)؛ الطبعة الدولية: [ص ٤٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=45) (ترقيم المتن: ٤٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=45) (ترقيم المتن: ٤٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «تكون علاقة الهوية على أي مجموعة علاقةً انعكاسية ومتناظرة ومتعدية. والعلاقات~$R$ التي».
  - **العربية التراثية:** [السطر ١٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/equivalence-relations.tex#L13)؛ الطبعة التراثية: [ص ٤٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=43) (ترقيم المتن: ٤٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «تجتمع في علاقة الهوية على المجموعة ثلاث خصائص: الانعكاسية والتناظر».
- **OLP-0328 — القوة التعبيرية، وقوع ٣:**
  - **الأصل:** [السطر ٤٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/second-order-logic/syntax-and-semantics/expressive-power.tex#L40). الشاهد المسجل: «In first-order logic we can define the identity relation~$\Id{\Domain{M}}$ (i.e., $\Setabs{\tuple{a,a}}{a \in».
  - **العربية المعيارية:** [السطر ٣٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/second-order-logic/syntax-and-semantics/expressive-power.tex#L38)؛ الطبعة الدولية: [ص ٦٠٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=606) (ترقيم المتن: ٦٠٥) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٠٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=607) (ترقيم المتن: ٦٠٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «يمكننا في منطق الرتبة الأولى تعريف علاقة الهوية».
  - **العربية التراثية:** [السطر ٣٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/second-order-logic/syntax-and-semantics/expressive-power.tex#L37)؛ الطبعة التراثية: [ص ٥٩٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=592) (ترقيم المتن: ٥٩١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «علاقة الهوية~$\Id{\Domain{M}}$، أي».
- **OLP-0014 — خصائص خاصة للعلاقات، وقوع ٤:**
  - **الأصل:** [السطر ٥٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/special-properties.tex#L53). الشاهد المسجل: «symmetric and anti-symmetric at the same time (e.g., the identity relation is).».
  - **العربية المعيارية:** [السطر ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/special-properties.tex#L50)؛ الطبعة الدولية: [ص ٤٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=44) (ترقيم المتن: ٤٣) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=44) (ترقيم المتن: ٤٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «(ومثال ذلك علاقة الهوية).».
  - **العربية التراثية:** [السطر ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/special-properties.tex#L48)؛ الطبعة التراثية: [ص ٤٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=43) (ترقيم المتن: ٤٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «في علاقة واحدة، كما في علاقة الهوية.».

## إذا

الأصل الإنجليزي: `If`. معرّف القرار: `retro-0005-0050:emphasis:588d7d19821e86a1`.

**المعنى المقصود:** شرط وجود لا إثبات وجود: إذا وُجدت مجموعة تضم بالضبط الأشياء التي تحقق الصفة φ، فإن بديهية الامتداد تجعلها فريدة؛ ولا تقرر أداة If أن مثل هذه المجموعة موجودة.

**سبب الاختيار:** تتطابق MSA والكلاسيكية على «إذا»، ويقابلها If في مقدمة الشرط الإنجليزي. الشرط يقيد نتيجة الامتداد: وجود المجموعة المفترضة يستلزم فرادتها، من غير تقرير وجودها. ولا يظهر التناقض إلا لاحقًا عند افتراض أن كل خاصية تعيّن مجموعة. وDAM يشهد للأسرة في if-then operation «عملية إذا-فإن».

**سؤال مفتوح:** لا سؤال؛ لم تُوسم هذه الحالة لمراجعة خبيرة إضافية.

**كل وقوع مسجل لهذا القرار:**

- **OLP-0010 — مفارقة راسل، وقوع ١:**
  - **الأصل:** [السطر ١٦](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/sets/russells-paradox.tex#L16). الشاهد المسجل: «\emph{If} there is a set whose members are all and only the $\phi$'s,».
  - **العربية المعيارية:** [السطر ١٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/sets/russells-paradox.tex#L15)؛ الطبعة الدولية: [ص ٣٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=38) (ترقيم المتن: ٣٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٣٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=38) (ترقيم المتن: ٣٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «الامتدادية \emph{حقًا} هو الفكرة الآتية. \emph{إذا} وُجدت مجموعة».
  - **العربية التراثية:** [السطر ١٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/sets/russells-paradox.tex#L15)؛ الطبعة التراثية: [ص ٣٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=37) (ترقيم المتن: ٣٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{إذا} وجدت مجموعة تضم كل ما يتصف بـ~$\phi$ ولا تضم غيره،».

## غير المتسق

الأصل الإنجليزي: `inconsistent`. معرّف القرار: `retro-0005-0050:emphasis:50dd8dd52070ace2`.

**المعنى المقصود:** وصف دعوى وجود المجموعة R بأنها غير قابلة للاتساق مع مبادئ النظرية لأنها تولد تناقض راسل.

**سبب الاختيار:** الموصوف claim مفرد مذكر، فالصيغة «غير المتسق» موافقة نحويًا، والمعنى هو عدم الاتساق لا مجرد الخطأ. يورد OCR DAM عائلات inconsistent equations/inequalities بصيغة «لامتسقة»، وهي سند دلالي مجاور لا تصديق بصري للصيغة الحالية.

**سؤال مفتوح:** لا سؤال؛ لم تُوسم هذه الحالة لمراجعة خبيرة إضافية.

**كل وقوع مسجل لهذا القرار:**

- **OLP-0010 — مفارقة راسل، وقوع ١:**
  - **الأصل:** [السطر ٧٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/sets/russells-paradox.tex#L74). الشاهد المسجل: «Russell's Paradox, i.e., which avoids making the \emph{inconsistent}».
  - **العربية المعيارية:** [السطر ٧٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/sets/russells-paradox.tex#L72)؛ الطبعة الدولية: [ص ٣٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=39) (ترقيم المتن: ٣٨) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٣٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=39) (ترقيم المتن: ٣٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «الادعاء \emph{غير المتسق} بأن المجموعة».
  - **العربية التراثية:** [السطر ٦٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/sets/russells-paradox.tex#L67)؛ الطبعة التراثية: [ص ٣٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=38) (ترقيم المتن: ٣٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{غير المتسق} إن $R = \Setabs{x}{x \notin x}$ موجودة؟».

## متزايدة

الأصل الإنجليزي: `increasing`. معرّف القرار: `retro-0005-0050:emphasis:713cea76388a18fa`.

**المعنى المقصود:** رتابة g غير الناقصة: يسمح تعريفها البنائي بأن تبقى ثابتة في خطوة أو ترتفع، ويستعمل البرهان هذه الرتابة لا التزايد الصارم.

**سبب الاختيار:** السياق البنائي يبين أن g(n+1) يساوي g(n) في بعض الحالات؛ لذلك تُقرأ «متزايدة» هنا بالمعنى الواسع nondecreasing. DAM يثبت increasing function «دالة متزايدة» في OCR ويعرض decreasing function بصريًا، لكن خطر حمل اللفظة على التزايد الصارم باقٍ.

**سؤال مفتوح:** هل ينبغي استبدال «متزايدة» بـ«غير متناقصة» لأن g قد تثبت في بعض الخطوات؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0048 — ملحق: بناء الحقيقية بمتتاليات كوشي، وقوع ١:**
  - **الأصل:** [السطر ٢٢٦](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/arithmetization/cauchy.tex#L226). الشاهد المسجل: «We next show that $\equivrep{f}{} = \equivrep{g}{}$ is the \emph{least} upper bound on $S$. So let $j$ be any Cauchy sequence and suppose $\equivrep{j}{} < \equivrep{g}{}$. Reasoning as above (using the fact that $g$ is \emph{increasing}), there is $n \in \…».
  - **العربية المعيارية:** [السطر ٢٢٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/arithmetization/cauchy.tex#L228)؛ الطبعة الدولية: [ص ١٠١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=101) (ترقيم المتن: ١٠٠) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ١٠١](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=101) (ترقيم المتن: ١٠٠) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{متزايدة})، يوجد $n \in \Nat$ بحيث $\equivrep{j}{} <».
  - **العربية التراثية:** [السطر ١٣٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/arithmetization/cauchy.tex#L135)؛ الطبعة التراثية: [ص ٩٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=97) (ترقيم المتن: ٩٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\equivrep{g}{}$. فبمثل الاستدلال السابق، مع استعمال كون $g$ \emph{متزايدة}، يوجد $n \in \Nat$ يحقق $\equivrep{j}{} <».

## مجموعة فهرسة

الأصل الإنجليزي: `index`. معرّف القرار: `retro-0005-0050:emphasis:e1dd52ae0092c538`.

**المعنى المقصود:** المجموعة I التي تتخذ عناصرها أدلة i لفهرسة العائلة A_i والاتحاد/التقاطع المفهرس.

**سبب الاختيار:** إضافة «مجموعة» تمنع قراءة index على أنه دليل منفرد، و«فهرسة» تصف وظيفتها في العائلة. إلا أن DAM يورد في OCR مدخل index set بصيغة «مجموعة أدلة»، وهو منافس رسمي مباشر لم يجر التحقق البصري من صفحته في هذه الدفعة.

**سؤال مفتوح:** هل نعتمد «مجموعة أدلة» وفق DAM، أم نحافظ على «مجموعة فهرسة» لتجنب التباس دليل البرهان؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0008 — الاتحادات والتقاطعات، وقوع ١:**
  - **الأصل:** [السطر ١٤٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/sets/unions-and-intersections.tex#L144). الشاهد المسجل: «When we have an \emph{index} of sets, i.e., some set $I$ such that we».
  - **العربية المعيارية:** [السطر ١٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/sets/unions-and-intersections.tex#L148)؛ الطبعة الدولية: [ص ٣٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=36) (ترقيم المتن: ٣٥) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٣٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=36) (ترقيم المتن: ٣٥) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وعندما تكون لدينا \emph{مجموعة فهرسة} للمجموعات، أي مجموعة ما $I$».
  - **العربية التراثية:** [السطر ١٤١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/sets/unions-and-intersections.tex#L141)؛ الطبعة التراثية: [ص ٣٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=35) (ترقيم المتن: ٣٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وإن أعطيت \emph{مجموعة فهرسة} $I$، وجعلت مجموعة $A_i$ لكل $i \in I$،».

## تستحث

الأصل الإنجليزي: `induces`. معرّف القرار: `retro-0005-0050:emphasis:de26d34181fb1bf8`.

**المعنى المقصود:** إنشاء الدالة الشاملة f′:A→ran(f) من f مع إبقاء القيم وتغيير المجال المقابل إلى المدى.

**سبب الاختيار:** «تستحث» تنقل علاقة اشتقاق بنيوي: لا يثبت النص بالاستقراء شيئًا، بل ينشئ دالة مرتبطة طبيعيًا بالأصل. DAM يرصد induced subgraph بصيغة «بيان جزئي محدّث»، لكنه من مجال آخر ولا يشهد للفعل هنا.

**سؤال مفتوح:** هل «تستحث» سليمة في هذا السجل، أم الأنسب «تعطي دالة شاملة»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0022 — أنواع الدوال، وقوع ١:**
  - **الأصل:** [السطر ٤٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L44). الشاهد المسجل: «Note that any function \emph{induces} !!a{surjection}. After all,».
  - **العربية المعيارية:** [السطر ٤٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L44)؛ الطبعة الدولية: [ص ٥٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=54) (ترقيم المتن: ٥٣) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=54) (ترقيم المتن: ٥٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «لاحظ أن كل دالة \emph{تستحث} !!a{surjection}. فبالنظر إلى».
  - **العربية التراثية:** [السطر ٣٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L38)؛ الطبعة التراثية: [ص ٥٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=52) (ترقيم المتن: ٥١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وكل دالة \emph{تستحث} !!a{surjection}. خذ $f \colon A \to B$،».

## غير منتهية

الأصل الإنجليزي: `infinite`. معرّف القرار: `retro-0005-0050:emphasis:e6b75bbaa980df33`.

**المعنى المقصود:** شجرة يكون حاملها A مجموعة غير منتهية؛ هذا هو طرف التعريف if and only if.

**سبب الاختيار:** الصيغة «غير منتهية» تطابق تعريف الحامل، ويثبت DAM بصريًا infinite set «مجموعة غير منتهية (مجموعة لانهائية)». الاختيار أحد البديلين الرسميين ويحافظ على أسرة النص.

**سؤال مفتوح:** لا سؤال؛ لم تُوسم هذه الحالة لمراجعة خبيرة إضافية.

**كل وقوع مسجل لهذا القرار:**

- **OLP-0018 — الأشجار، وقوع ١:**
  - **الأصل:** [السطر ٨٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/trees.tex#L84). الشاهد المسجل: «A tree $T = \tuple{A, \le}$ is said to be \emph{infinite} if $A$ is an».
  - **العربية المعيارية:** [السطر ٨١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/trees.tex#L81)؛ الطبعة الدولية: [ص ٤٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=49) (ترقيم المتن: ٤٨)، [ص ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=50) (ترقيم المتن: ٤٩) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=49) (ترقيم المتن: ٤٨)، [ص ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=50) (ترقيم المتن: ٤٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «يقال إن الشجرة $T = \tuple{A, \le}$ \emph{غير منتهية} إذا كانت $A$».
  - **العربية التراثية:** [السطر ٧٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/trees.tex#L77)؛ الطبعة التراثية: [ص ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=48) (ترقيم المتن: ٤٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «الشجرة $T = \tuple{A, \le}$ \emph{غير منتهية} إن كانت $A$ غير».

## الشجرة الثنائية غير المنتهية

الأصل الإنجليزي: `infinite binary tree`. معرّف القرار: `retro-0005-0050:emphasis:59696457958b75d4`.

**المعنى المقصود:** شجرة جميع المتتاليات الثنائية المنتهية المرتبة بالامتداد؛ حاملها غير منتهٍ ولكل عقدة امتدادان x0 وx1.

**سبب الاختيار:** «الشجرة» مشهود لها في DAM، و«غير المنتهية» مشهود لها في infinite set، و«الثنائية» يثبتها تعريف المتتاليات من 0 و1 والتفرع إلى خلفين. لا يوجد شاهد محلي مقروء للعبارة المركبة كلها، لكن كل قيد محكوم بالنص.

**سؤال مفتوح:** هل تكفي «الشجرة الثنائية غير المنتهية»، أم يلزم «الكاملة» لتمييز full infinite binary tree دون زيادة غير مأذونة؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0018 — الأشجار، وقوع ١:**
  - **الأصل:** [السطر ١٠٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/trees.tex#L102). الشاهد المسجل: «\emph{infinite binary tree} of finite sequences of $0$s and~$1$s,».
  - **العربية المعيارية:** [السطر ٩٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/trees.tex#L97)؛ الطبعة الدولية: [ص ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=50) (ترقيم المتن: ٤٩) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=50) (ترقيم المتن: ٤٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «من الأمثلة التقليدية على الأشجار المنتهية التفرع \emph{الشجرة الثنائية غير المنتهية} للمتتاليات المنتهية من الرمزين $0$ و~$1$، ويرمز إليها».
  - **العربية التراثية:** [السطر ٩٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/trees.tex#L92)؛ الطبعة التراثية: [ص ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=48) (ترقيم المتن: ٤٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «المثال المشهور لمنتهي التفرع هو \emph{الشجرة الثنائية غير المنتهية}:».

## متتالية لا نهائية

الأصل الإنجليزي: `infinite sequence`. معرّف القرار: `locale-ar-chosen-708d58ab54f2c9b6`.

**المعنى المقصود:** المتتالية ذات عدد غير منته من الحدود، وفي الموضع المحدد قائمة أحادية الاتجاه من عناصر A تمثل عنصرًا من A^omega.

**سبب الاختيار:** يُبقى «متتالية لا نهائية» مؤقتًا لأنها تؤدي الرأس والمعنى في النص، ويحفظ السياق قيد الامتداد في اتجاه واحد. ويثبت معجم دمشق «متتالية غير منتهية» ويورد «متتالية لانهائية» بين قوسين، ولذلك يكون الخلاف بين «غير منتهية» و«لا نهائية» أسلوبيًا/إقليميًا يحتاج سؤالًا صريحًا، لا خللًا دلاليًا مثبتًا.

**سؤال مفتوح:** في تعريف A^ω بوصفها مجموعة القوائم غير المنتهية أحادية الاتجاه من عناصر A، هل يُفضَّل الرأس «متتالية لا نهائية»، أم «متتالية غير منتهية» المثبتة أولًا في معجم دمشق، أم كتابة «متتالية لانهائية» موصولة؟ وهل ينبغي إدخال قيد «أحادية الاتجاه» في الرأس نفسه أم يكفي شرحه في المتن؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0007 — بعض المجموعات المهمة، وقوع ١:**
  - **الأصل:** [السطر ٦٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/sets/important-sets.tex#L62). الشاهد المسجل: «\begin{ex}[Infinite sequences] For any set $A$ we may also consider the set~$A^\omega$ of infinite sequences of !!{element}s of~$A$. An infinite sequence $a_1a_2a_3a_4\dots$ consists of a one-way infinite list of objects, each one of which is !!a{element} o…».
  - **العربية المعيارية:** [السطر ٦٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/sets/important-sets.tex#L62)؛ الطبعة الدولية: [ص ٣٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=33) (ترقيم المتن: ٣٢) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٣٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=33) (ترقيم المتن: ٣٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{ex}[المتتاليات اللانهائية] ولكل مجموعة $A$ يمكننا أيضًا النظر في المجموعة~$A^\omega$ المؤلفة من متتاليات لا نهائية من !!{element}s المجموعة~$A$. وتتكون المتتالية اللانهائية $a_1a_2a_3a_4\dots$ من قائمة لا نهائية أحادية الاتجاه من كائنات، كل واحد منها…».

## المتتاليات اللانهائية

الأصل الإنجليزي: `Infinite sequences`. معرّف القرار: `retro-0005-0050:named-ex:e5fa1866e434153f`.

**المعنى المقصود:** عنوان مثال لمجموعة جميع المتتاليات اللانهائية على أبجدية/مجموعة معطاة، لا مجرد متتالية واحدة.

**سبب الاختيار:** الجمع والتعريف يناسبان عنوان القسم، ويثبت DAM بصريًا infinite sequence «متتالية غير منتهية (متتالية لانهائية)». الصيغة الحالية تجمع البديل الرسمي الثاني جمع مؤنث سالمًا.

**سؤال مفتوح:** لا سؤال؛ لم تُوسم هذه الحالة لمراجعة خبيرة إضافية.

**كل وقوع مسجل لهذا القرار:**

- **OLP-0007 — بعض المجموعات المهمة، وقوع ١:**
  - **الأصل:** [السطر ٦٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/sets/important-sets.tex#L62). الشاهد المسجل: «\begin{ex}[Infinite sequences]».
  - **العربية المعيارية:** [السطر ٦٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/sets/important-sets.tex#L62)؛ الطبعة الدولية: [ص ٣٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=33) (ترقيم المتن: ٣٢) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٣٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=33) (ترقيم المتن: ٣٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{ex}[المتتاليات اللانهائية]».
  - **العربية التراثية:** [السطر ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/sets/important-sets.tex#L56)؛ الطبعة التراثية: [ص ٣٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=33) (ترقيم المتن: ٣٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{ex}[المتتاليات اللانهائية]».

## مجموعة لا نهائية

الأصل الإنجليزي: `infinite set`. معرّف القرار: `locale-ar-chosen-7fe81cd264325d29`.

**المعنى المقصود:** المجموعة التي ليست منتهية؛ والموضع المحدد يقارن إنشاءات تجعل مجموعة غير منتهية على معنى ددكند.

**سبب الاختيار:** يحفظ «مجموعة لا نهائية» نفي التناهي، ويطابق معنى المواضع الثلاثة. ويثبت المعجم «مجموعة غير منتهية» أصلًا و«مجموعة لانهائية» مرادفًا، فلا توجد قرينة على خطأ دلالي، لكن يوجد اختيار اصطلاحي يستحق مراجعة إقليمية.

**سؤال مفتوح:** في هذا الموضع من نظرية المجموعات، هل يُفضَّل «مجموعة لا نهائية» أم «مجموعة غير منتهية» المثبتة أولًا في معجم دمشق، وهل يحتاج قول «على معنى ددكند» إلى إبقائه قيدًا سياقيًا لا جزءًا من المصطلح؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0545 — في اختيار الأعداد الطبيعية، وقوع ١:**
  - **الأصل:** [السطر ٣١](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/set-theory/z/nat.tex#L31). الشاهد المسجل: «infinite set, and so a Dedekind algebra. On Zermelo's approach, the».
  - **العربية المعيارية:** [السطر ٢٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/set-theory/z/nat.tex#L29)؛ الطبعة الدولية: [ص ٨٨٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=884) (ترقيم المتن: ٨٨٣) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٨٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=885) (ترقيم المتن: ٨٨٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «لحصلنا بالقدر نفسه على مجموعة لا نهائية على معنى ددكند، ومن ثم على جبر».
  - **العربية التراثية:** [السطر ٢٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/set-theory/z/nat.tex#L28)؛ الطبعة التراثية: [ص ٨٦٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=867) (ترقيم المتن: ٨٦٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وجود مجموعة لا نهائية بمعنى ددكند، ثم جبر ددكندي. ويبقى العنصر المميز».

## المجموعات اللانهائية؛ نظرية المجموعات المفتوحة؛ تيم باتن

الأصل الإنجليزي: `Infinite Sets; Open Set Theory; Tim Button`. معرّف القرار: `locale-ar-chosen-b48566481e87e929`.

**المعنى المقصود:** عنوان فصل Infinite Sets، وعنوان كتاب Open Set Theory، ونسبة المادة إلى المؤلف Tim Button.

**سبب الاختيار:** تحافظ الصياغة على عنوان الفصل وعلى اسم المؤلف وعلى كون Open Set Theory عنوان كتاب، ولا تحوله إلى ادعاء بأن هناك فرعًا رسميًا اسمه نظرية المجموعات المفتوحة. يشهد المعجم لمكوّني infinite set وopen set، لكنه لا يشهد للعنوان المركب أو لتعريب اسم المؤلف؛ والبحث المحلي المحدود لم يجد العنوان أو الاسم.

**سؤال مفتوح:** هل تُعرض العبارة بوصفها عنوانًا منقولًا «نظرية المجموعات المفتوحة» مع إبقاء اسم المؤلف «تيم باتن»، أم ينبغي إثبات عنوان إنجليزي مقابل أو تعريب ببليوغرافي آخر لتجنب فهمها اسمًا لفرع رياضي؟ وهل يُفضَّل في عنوان الفصل «المجموعات غير المنتهية» على «المجموعات اللانهائية»؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0049 — المجموعات اللانهائية، وقوع ١:**

## متباينة

الأصل الإنجليزي: `injective`. معرّف القرار: `retro-0005-0050:shared-token:a0175284e46bf417`.

**المعنى المقصود:** خاصية الدالة الواحدية: تساوي المخرجين يستلزم تساوي المدخلين، أو لكل عنصر في المجال المقابل سابق واحد على الأكثر.

**سبب الاختيار:** تتحقق الدلالة في جميع مواضع الرمز المشترك، ويثبت DAM بصريًا injection «تطبيق متباين» مع تعريف السابق الواحد على الأكثر وتسميات injective/one-to-one mapping. «متباينة» توافق «دالة» تأنيثًا وتحفظ أسرة المتباينة/الدالة المتباينة في سجل الرموز.

**سؤال مفتوح:** هل نحافظ على أسرة «متباينة/دالة متباينة» في جميع المواضع أم نعرض «واحد لواحد» للقارئ أول مرة فقط؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0029 — التعدادات ومجموعات Enumerable، وقوع ١:**
  - **الأصل:** [السطر ٢٢٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/enumerability.tex#L223). الشاهد المسجل: «Not having repetitions means that $f$ must be !!{injective}. Since it».
  - **العربية المعيارية:** [السطر ٢٢٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/enumerability.tex#L225)؛ الطبعة الدولية: [ص ٦٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=65) (ترقيم المتن: ٦٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=65) (ترقيم المتن: ٦٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «$f$ يجب أن تكون !!{injective}. ولأنها !!{surjective} أيضًا، فنحن».
  - **العربية التراثية:** [السطر ٢٠١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/enumerability.tex#L201)؛ الطبعة التراثية: [ص ٦٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=62) (ترقيم المتن: ٦١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وعدم التكرار يقتضي أن تكون $f$ !!{injective}؛ وهي !!{surjective}».
- **OLP-0029 — التعدادات ومجموعات Enumerable، وقوع ٢:**
  - **الأصل:** [السطر ٢٤٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/enumerability.tex#L247). الشاهد المسجل: «!!{injective}, since if there were $j < i$ such that $g(j) = g(i)$,».
  - **العربية المعيارية:** [السطر ٢٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/enumerability.tex#L248)؛ الطبعة الدولية: [ص ٦٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=65) (ترقيم المتن: ٦٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=65) (ترقيم المتن: ٦٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «النهاية قيمةً لـ$g(i)$ عند عدد ما~$i$. وهي أيضًا !!{injective}،».
  - **العربية التراثية:** [السطر ٢٢٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/enumerability.tex#L223)؛ الطبعة التراثية: [ص ٦٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=62) (ترقيم المتن: ٦١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «قيمة لـ$g(i)$ عند بعض~$i$. وهي !!{injective} أيضًا؛ فلو كان».
- **OLP-0029 — التعدادات ومجموعات Enumerable، وقوع ٣:**
  - **الأصل:** [السطر ١٠١](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/enumerability.tex#L101). الشاهد المسجل: «!!{injective}, the list may be redundant, but that is acceptable (as».
  - **العربية المعيارية:** [السطر ٩٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/enumerability.tex#L96)؛ الطبعة الدولية: [ص ٦٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=64) (ترقيم المتن: ٦٣) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=64) (ترقيم المتن: ٦٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «!!{injective}، فقد تتضمن القائمة تكرارًا، غير أن ذلك مقبول (كما».
  - **العربية التراثية:** [السطر ٨٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/enumerability.tex#L83)؛ الطبعة التراثية: [ص ٦٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=60) (ترقيم المتن: ٥٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «عند موضع منته. وقد لا تكون الدالة !!{injective} فيقع التكرار،».
- **OLP-0025 — تركيب الدوال، وقوع ٤:**
  - **الأصل:** [السطر ٥٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/composition.tex#L54). الشاهد المسجل: «!!{injective}, then $\comp{f}{g}\colon A \to C$ is !!{injective}.».
  - **العربية المعيارية:** [السطر ٥٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/composition.tex#L53)؛ الطبعة الدولية: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=59) (ترقيم المتن: ٥٨) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=59) (ترقيم المتن: ٥٨) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «كلتاهما !!{injective}، فإن الدالة $\comp{f}{g}\colon A \to C$».
  - **العربية التراثية:** [السطر ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/composition.tex#L48)؛ الطبعة التراثية: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=56) (ترقيم المتن: ٥٥) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «إذا كانت $f \colon A \to B$ و$g \colon B \to C$ كلتاهما !!{injective}،».
- **OLP-0025 — تركيب الدوال، وقوع ٥:**
  - **العربية المعيارية:** [السطر ٥٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/composition.tex#L54)؛ الطبعة الدولية: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=59) (ترقيم المتن: ٥٨) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=59) (ترقيم المتن: ٥٨) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «!!{injective}.».
  - **العربية التراثية:** [السطر ٤٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/composition.tex#L49)؛ الطبعة التراثية: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=56) (ترقيم المتن: ٥٥) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «فبرهن على أن $\comp{f}{g}\colon A \to C$ هي !!{injective}.».
- **OLP-0022 — أنواع الدوال، وقوع ٦:**
  - **الأصل:** [السطر ١١٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L114). الشاهد المسجل: «!!{surjective} and !!{injective}. We call such a function».
  - **العربية المعيارية:** [السطر ١١٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L114)؛ الطبعة الدولية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «!!{surjective} و!!{injective} معًا. ونسمي مثل هذه الدالة».
  - **العربية التراثية:** [السطر ١٠٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L100)؛ الطبعة التراثية: [ص ٥٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=53) (ترقيم المتن: ٥٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «الدالة $f \colon A \to B$ \emph{!!{bijective}} إذا وفقط إذا كانت !!{surjective} و!!{injective} معًا. وحينئذ تسمى !!a{bijection}».
- **OLP-0022 — أنواع الدوال، وقوع ٧:**
  - **الأصل:** [السطر ٥٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L54). الشاهد المسجل: «outputs. Such functions are called !!{injective}, and can be pictured».
  - **العربية المعيارية:** [السطر ٥٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L54)؛ الطبعة الدولية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «وتسمى هذه الدوال !!{injective}، ويمكن تمثيلها».
  - **العربية التراثية:** [السطر ٤٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L46)؛ الطبعة التراثية: [ص ٥٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=52) (ترقيم المتن: ٥١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «لا تجمع مدخلين مختلفين على مخرج واحد؛ فتسمى !!{injective}،».
- **OLP-0022 — أنواع الدوال، وقوع ٨:**
  - **الأصل:** [السطر ٦٥](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L65). الشاهد المسجل: «A function $f \colon A \rightarrow B$ is \emph{!!{injective}} iff for».
  - **العربية المعيارية:** [السطر ٦٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L65)؛ الطبعة الدولية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «تكون الدالة $f \colon A \rightarrow B$ \emph{!!{injective}} إذا وفقط إذا كان لكل».
  - **العربية التراثية:** [السطر ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L56)؛ الطبعة التراثية: [ص ٥٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=52) (ترقيم المتن: ٥١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «الدالة $f \colon A \rightarrow B$ \emph{!!{injective}} إذا وفقط إذا».
- **OLP-0022 — أنواع الدوال، وقوع ٩:**
  - **الأصل:** [السطر ٧٨](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L78). الشاهد المسجل: «neither !!{injective}, nor !!{surjective}.».
  - **العربية المعيارية:** [السطر ٧٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L78)؛ الطبعة الدولية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ليست !!{injective} ولا !!{surjective}.».
  - **العربية التراثية:** [السطر ٦٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L68)؛ الطبعة التراثية: [ص ٥٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=53) (ترقيم المتن: ٥٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «لا هي !!{injective} ولا هي !!{surjective}.».
- **OLP-0022 — أنواع الدوال، وقوع ١٠:**
  - **الأصل:** [السطر ٨١](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L81). الشاهد المسجل: «both !!{injective} and !!{surjective}.».
  - **العربية المعيارية:** [السطر ٨١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L81)؛ الطبعة الدولية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «هي !!{injective} و!!{surjective} معًا.».
  - **العربية التراثية:** [السطر ٧١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L71)؛ الطبعة التراثية: [ص ٥٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=53) (ترقيم المتن: ٥٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فهي !!{injective} و!!{surjective} معًا.».
- **OLP-0022 — أنواع الدوال، وقوع ١١:**
  - **الأصل:** [السطر ٨٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L84). الشاهد المسجل: «is !!{injective} but not !!{surjective}.».
  - **العربية المعيارية:** [السطر ٨٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L84)؛ الطبعة الدولية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «هي !!{injective}، لكنها ليست !!{surjective}.».
  - **العربية التراثية:** [السطر ٧٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L74)؛ الطبعة التراثية: [ص ٥٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=53) (ترقيم المتن: ٥٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فهي !!{injective} دون !!{surjective}.».
- **OLP-0022 — أنواع الدوال، وقوع ١٢:**
  - **الأصل:** [السطر ٩٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L94). الشاهد المسجل: «is !!{surjective}, but not !!{injective}.».
  - **العربية المعيارية:** [السطر ٩٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L94)؛ الطبعة الدولية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «هي !!{surjective}، لكنها ليست !!{injective}.».
  - **العربية التراثية:** [السطر ٨٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L84)؛ الطبعة التراثية: [ص ٥٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=53) (ترقيم المتن: ٥٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فهي !!{surjective} غير !!{injective}.».
- **OLP-0022 — أنواع الدوال، وقوع ١٣:**
  - **الأصل:** [السطر ٩٩](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L99). الشاهد المسجل: «!!{injective} and !!{surjective}. We call such functions».
  - **العربية المعيارية:** [السطر ٩٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L99)؛ الطبعة الدولية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «!!{injective} و!!{surjective} معًا. ونسمي هذه الدوال».
  - **العربية التراثية:** [السطر ٨٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/function-kinds.tex#L88)؛ الطبعة التراثية: [ص ٥٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=53) (ترقيم المتن: ٥٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ويكثر احتياجنا إلى الدوال التي تكون !!{injective} و!!{surjective} معًا؛».
- **OLP-0040 — الاختزال، وقوع ١٤:**
  - **الأصل:** [السطر ٤٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/reduction-alt.tex#L43). الشاهد المسجل: «Show that if there is an !!{injective} function $g\colon B \to A$, and».
  - **العربية المعيارية:** [السطر ٤٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/reduction-alt.tex#L46)؛ الطبعة الدولية: [ص ٨٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=82) (ترقيم المتن: ٨١) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٨٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=82) (ترقيم المتن: ٨١) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «أثبت أنه إذا وجدت دالة~!!{injective} $g\colon B \to A$، وكانت».
  - **العربية التراثية:** [السطر ٢٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/reduction-alt.tex#L29)؛ الطبعة التراثية: [ص ٧٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=78) (ترقيم المتن: ٧٧) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «إذا وجدت دالة~!!{injective} $g\colon B \to A$، وكانت $B$~!!{nonenumerable}، فبين أن $A$ كذلك. وذلك بأن تستعمل~$g$ لتحويل تعداد~$A$ المفروض إلى تعداد~$B$.».
- **OLP-0034 — الاختزال، وقوع ١٥:**
  - **الأصل:** [السطر ٤٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/reduction.tex#L42). الشاهد المسجل: «Show that if there is an !!{injective} function $g\colon B \to A$, and».
  - **العربية المعيارية:** [السطر ٤٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/reduction.tex#L40)؛ الطبعة الدولية: [ص ٧٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=73) (ترقيم المتن: ٧٢) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٧٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=73) (ترقيم المتن: ٧٢) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «أثبت أنه إذا وجدت دالة~!!{injective} $g\colon B \to A$، وكانت».
  - **العربية التراثية:** [السطر ٢٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/reduction.tex#L22)؛ الطبعة التراثية: [ص ٦٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=69) (ترقيم المتن: ٦٨) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «لتكن دالة~!!{injective} $g\colon B \to A$ موجودة، ولتكن $B$~!!{nonenumerable}. بين أن $A$ كذلك، بأن تبين كيف تحول~$g$ تعداد~$A$، لو وجد، إلى تعداد~$B$.».
- **OLP-0024 — معكوسات الدوال، وقوع ١٦:**
  - **الأصل:** [السطر ١٤٨](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/inverses.tex#L148). الشاهد المسجل: «Clearly, if $f$~is !!{injective}, then $f'$~is !!{bijective}, so that».
  - **العربية المعيارية:** [السطر ١٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/inverses.tex#L156)؛ الطبعة الدولية: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=59) (ترقيم المتن: ٥٨) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=59) (ترقيم المتن: ٥٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ومن الواضح أنه إذا كانت $f$ !!{injective}، فإن $f'$ !!{bijective}، ومن ثم».
  - **العربية التراثية:** [السطر ٦٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/inverses.tex#L63)؛ الطبعة التراثية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فالدالة الخالية $\emptyset\to\{0\}$ متباينة ولا معكوس أيسر لها،».
- **OLP-0024 — معكوسات الدوال، وقوع ١٧:**
  - **الأصل:** [السطر ٥١](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/inverses.tex#L51). الشاهد المسجل: «other words, for $g$ to be defined, $f$~must be both !!{injective} and».
  - **العربية المعيارية:** [السطر ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/inverses.tex#L50)؛ الطبعة الدولية: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «تُعرّف $g$، يجب أن تكون $f$ !!{injective} و!!{surjective} معًا.».
  - **العربية التراثية:** [السطر ٦٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/inverses.tex#L63)؛ الطبعة التراثية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فالدالة الخالية $\emptyset\to\{0\}$ متباينة ولا معكوس أيسر لها،».
- **OLP-0024 — معكوسات الدوال، وقوع ١٨:**
  - **الأصل:** [السطر ٦٣](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/inverses.tex#L63). الشاهد المسجل: «If $f\colon A \to B$ is !!{injective}, then there is a \emph{left».
  - **العربية المعيارية:** [السطر ٦١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/inverses.tex#L61)؛ الطبعة الدولية: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «إذا كانت $f\colon A \to B$ !!{injective} وكان $A \neq \emptyset$، فثمة \emph{معكوس».
  - **العربية التراثية:** [السطر ٦٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/inverses.tex#L63)؛ الطبعة التراثية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فالدالة الخالية $\emptyset\to\{0\}$ متباينة ولا معكوس أيسر لها،».
- **OLP-0024 — معكوسات الدوال، وقوع ١٩:**
  - **الأصل:** [السطر ٦٩](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/inverses.tex#L69). الشاهد المسجل: «Suppose that $f\colon A \to B$ is !!{injective}. Consider a $y \in B$.».
  - **العربية المعيارية:** [السطر ٧٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/inverses.tex#L76)؛ الطبعة الدولية: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «افترض أن $f\colon A \to B$ !!{injective} وأن $A \neq \emptyset$. ولنتأمل $y \in B$.».
  - **العربية التراثية:** [السطر ٦٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/inverses.tex#L63)؛ الطبعة التراثية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فالدالة الخالية $\emptyset\to\{0\}$ متباينة ولا معكوس أيسر لها،».
- **OLP-0024 — معكوسات الدوال، وقوع ٢٠:**
  - **الأصل:** [السطر ٧١](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/inverses.tex#L71). الشاهد المسجل: «$f$ is !!{injective}, there is only one such~$x \in A$. Then we can».
  - **العربية المعيارية:** [السطر ٧٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/inverses.tex#L78)؛ الطبعة الدولية: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «$f$ !!{injective}، فلا يوجد إلا~$x \in A$ واحد من هذا القبيل. ويمكننا».
  - **العربية التراثية:** [السطر ٦٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/inverses.tex#L63)؛ الطبعة التراثية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فالدالة الخالية $\emptyset\to\{0\}$ متباينة ولا معكوس أيسر لها،».
- **OLP-0024 — معكوسات الدوال، وقوع ٢١:**
  - **الأصل:** [السطر ٨٨](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/inverses.tex#L88). الشاهد المسجل: «!!{injective}.».
  - **العربية المعيارية:** [السطر ٩٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/inverses.tex#L95)؛ الطبعة الدولية: [ص ٥٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=57) (ترقيم المتن: ٥٦) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٥٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=57) (ترقيم المتن: ٥٦) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «!!{injective}.».
  - **العربية التراثية:** [السطر ٦٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/inverses.tex#L63)؛ الطبعة التراثية: [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فالدالة الخالية $\emptyset\to\{0\}$ متباينة ولا معكوس أيسر لها،».
- **OLP-0036 — اختلاف أحجام المجموعات ومبرهنة كانتور، وقوع ٢٢:**
  - **الأصل:** [السطر ١٤٥](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/comparing-size.tex#L145). الشاهد المسجل: «!!{injective}. Consider $D = \Setabs{g(B)}{B \subseteq A \text{ and».
  - **العربية المعيارية:** [السطر ١٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/comparing-size.tex#L148)؛ الطبعة الدولية: [ص ٧٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=76) (ترقيم المتن: ٧٥) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٧٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=76) (ترقيم المتن: ٧٥) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «!!{injective}. وتأمل $D = \Setabs{g(B)}{B \subseteq A \text{ و».
  - **العربية التراثية:** [السطر ٩١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/comparing-size.tex#L91)؛ الطبعة التراثية: [ص ٧٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=72) (ترقيم المتن: ٧١) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «A$ مهما تكن المجموعة~$A$. وللتلميح، افرض أن $g\colon \Pow{A} \to A$ !!{injective}، وضع $D = \Setabs{g(B)}{B \subseteq A \text{ و».
- **OLP-0036 — اختلاف أحجام المجموعات ومبرهنة كانتور، وقوع ٢٣:**
  - **الأصل:** [السطر ١٤٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/comparing-size.tex#L147). الشاهد المسجل: «!!{injective} to derive a contradiction.».
  - **العربية المعيارية:** [السطر ١٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/comparing-size.tex#L150)؛ الطبعة الدولية: [ص ٧٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=76) (ترقيم المتن: ٧٥) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٧٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=76) (ترقيم المتن: ٧٥) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «!!{injective} لاستخلاص تناقض.».
  - **العربية التراثية:** [السطر ٩٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/comparing-size.tex#L92)؛ الطبعة التراثية: [ص ٧٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=72) (ترقيم المتن: ٧١) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «} g(B) \notin B}$، ثم خذ $x = g(D)$. واستخرج التناقض من كون $g$ !!{injective}.».

## دالة متباينة؛ دالة متباينة

الأصل الإنجليزي: `injective function; injection`. معرّف القرار: `locale-ar-chosen-a1b533cd76b82eb0`.

**المعنى المقصود:** الدالة injective/injection: لكل قيمة في المجال المقابل سابق واحد على الأكثر، أو تكافؤًا f(x)=f(y) يستلزم x=y.

**سبب الاختيار:** تؤدي «دالة متباينة» الشرط الرياضي في المواضع الثلاثة. لكن معجم دمشق يثبت injection باسم «تطبيق متباين»، ويستعمل القرار العبارة نفسها للصفة injective function وللاسم injection؛ لذلك لا يُدّعى أن الاختيار هو الرأس الرسمي الوحيد.

**سؤال مفتوح:** هل يُفضَّل في هذا الكتاب «دالة متباينة» أم الرأس المعجمي «تطبيق متباين»؟ وهل ينبغي التمييز لفظيًا بين injective function وinjection، أم تكفي العبارة الواحدة ما دام التعريف يثبت شرط السابق الواحد على الأكثر وشرط f(x)=f(y)⇒x=y؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0022 — أنواع الدوال، وقوع ١:**
  - **الأصل:** [السطر ٥٢](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/function-kinds.tex#L52). الشاهد المسجل: «Now, any function maps each possible input to a unique output. But there are also functions which never map different inputs to the same outputs. Such functions are called !!{injective}, and can be pictured as in \olref{fig:injective}. \begin{figure} \olass…».
  - **العربية المعيارية:** [السطر ٥١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/function-kinds.tex#L51)؛ الطبعة الدولية: [ص ٥٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=54) (ترقيم المتن: ٥٣)، [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=54) (ترقيم المتن: ٥٣)، [ص ٥٥](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=55) (ترقيم المتن: ٥٤) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\begin{explain} تقرن كل دالة كل مدخل ممكن بمخرج وحيد. غير أن ثمة أيضًا دوال لا تقرن مدخلين مختلفين بالمخرج نفسه قط. وتسمى هذه الدوال !!{injective}، ويمكن تمثيلها كما في \olref{fig:injective}. \begin{figure} \olasset{assets/diagrams/injective.tikz} \caption{…».

## بناء الأعداد الصحيحة فئات تكافؤ للأزواج المرتبة من الأعداد الطبيعية

الأصل الإنجليزي: `integer construction as Nat squared modulo Intequiv`. معرّف القرار: `locale-ar-chosen-cb652d1abe21aa7f`.

**المعنى المقصود:** إنشاء Z بوصفها فئات تكافؤ الأزواج من N² تحت (a,b)~(c,d) iff a+d=c+b، ثم تعريف العمليات وتضمين N.

**سبب الاختيار:** العبارة تلخص البناء من غير تغيير المعادلات أو اتجاه التضمين. يشهد المعجم للمكوّنات «عدد صحيح» و«زوج مرتب» و«عدد طبيعي»، ويستعمل «صفوف تكافؤ» حيث يستعمل النص «فئات تكافؤ». لا يشهد القانون المحلي للعبارة المركبة كاملة، ولذلك تبقى صياغة الملخص قابلة للتصحيح.

**سؤال مفتوح:** هل الصياغة الأوضح لهذا القرار «بناء الأعداد الصحيحة بوصفها فئات تكافؤ للأزواج المرتبة من الأعداد الطبيعية»، أم يُفضَّل «صفوف تكافؤ» موافقةً لمعجم دمشق، أو تصريح «خارج قسمة N² بعلاقة ∼»؟ وهل ينبغي أن يذكر الملخص صراحةً تضمين n↦[(n,0)]؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0042 — من ℕ إلى ℤ، وقوع ١:**
  - **الأصل:** [السطر ١٨](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/arithmetization/integers.tex#L18). الشاهد المسجل: «We already know that the ordered pairs of natural numbers are the !!{element}s of $\Nat^2$. And we are assuming that we understand $\Nat$. So here is a na\"{i}ve suggestion, based on the two realisations we have had: \emph{let's treat integers as ordered pa…».
  - **الأصل:** [السطر ٣٩](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/arithmetization/integers.tex#L39). الشاهد المسجل: «Now we can use this equivalence relation to take equivalence classes: \begin{defn} The integers are the equivalence classes, under $\Intequiv$, of ordered pairs of natural numbers; that is, $\Int = \equivclass{\Nat^2}{\Intequiv}$. \end{defn} Now, one might…».
  - **الأصل:** [السطر ٥٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/arithmetization/integers.tex#L57). الشاهد المسجل: «One final thing remains. We have constructed the integers using natural numbers. But this will mean that the natural numbers \emph{are not themselves integers}. We will return to the philosophical significance of this in \olref[ref]{sec}. On a purely techni…».
  - **العربية المعيارية:** [السطر ١٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/arithmetization/integers.tex#L18)؛ الطبعة الدولية: [ص ٨٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=87) (ترقيم المتن: ٨٦) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=87) (ترقيم المتن: ٨٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ونعلم من قبل أن الأزواج المرتبة من الأعداد الطبيعية هي !!{element}s المجموعة $\Nat^2$. ونفترض أننا نفهم $\Nat$. ومن ثم فهذا اقتراح ساذج يستند إلى الملاحظتين السابقتين: \emph{لنعامل الأعداد الصحيحة على أنها أزواج مرتبة من الأعداد الطبيعية}. والواقع أن هذا ال…».
  - **العربية المعيارية:** [السطر ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/arithmetization/integers.tex#L50)؛ الطبعة الدولية: [ص ٨٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=88) (ترقيم المتن: ٨٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=88) (ترقيم المتن: ٨٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «يمكننا الآن أن نستعمل علاقة التكافؤ هذه لأخذ فئات التكافؤ: \begin{defn} الأعداد الصحيحة هي فئات تكافؤ الأزواج المرتبة من الأعداد الطبيعية بالنسبة إلى $\Intequiv$؛ أي إن $\Int = \equivclass{\Nat^2}{\Intequiv}$. \end{defn} قد تكون لدى المرء ردود \emph{فلسفية}…».
  - **العربية المعيارية:** [السطر ٧٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/arithmetization/integers.tex#L78)؛ الطبعة الدولية: [ص ٨٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=88) (ترقيم المتن: ٨٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٨٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=88) (ترقيم المتن: ٨٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «بقي أمر أخير. لقد بنينا الأعداد الصحيحة باستعمال الأعداد الطبيعية. غير أن هذا يعني أن الأعداد الطبيعية \emph{ليست هي نفسها أعدادًا صحيحة}. وسنعود إلى الدلالة الفلسفية لهذا في \olref[ref]{sec}. لكننا نحتاج، من الناحية التقنية المحضة، إلى طريقة تمكّننا من معا…».

## مقدمة

الأصل الإنجليزي: `Introduction`. معرّف القرار: `retro-0005-0050:section:bf7d96f5da6110c2`.

**المعنى المقصود:** عنوان افتتاحي يقدم مادة الباب/الفصل قبل التعريفات والنتائج.

**سبب الاختيار:** «مقدمة» المقابل العربي العادي المباشر لـ Introduction، وتتطابق نسختا العربية. لا توجد دلالة رياضية خاصة تستدعي معجم مصطلحات.

**سؤال مفتوح:** لا سؤال؛ لم تُوسم هذه الحالة لمراجعة خبيرة إضافية.

**كل وقوع مسجل لهذا القرار:**

- **OLP-0028 — مقدمة، وقوع ١:**
  - **الأصل:** [السطر ١١](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/introduction.tex#L11). الشاهد المسجل: «\olsection{Introduction}».
  - **العربية المعيارية:** [السطر ١١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/introduction.tex#L11)؛ الطبعة الدولية: [ص ٦٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=62) (ترقيم المتن: ٦١) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=62) (ترقيم المتن: ٦١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{مقدمة}».
  - **العربية التراثية:** [السطر ١١](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/introduction.tex#L11)؛ الطبعة التراثية: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=59) (ترقيم المتن: ٥٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\olsection{مقدمة}».

## معكوس

الأصل الإنجليزي: `inverse`. معرّف القرار: `retro-0005-0050:emphasis:ffd8b07fb5042cf7`.

**المعنى المقصود:** الدالة g:\Nat^2\to\Nat التي تعكس التعداد المتعرج: ترسل كل زوج مرتب إلى العدد الطبيعي الذي يحتل عنده ذلك الزوج موضعه في التعداد، مثل ⟨1,2⟩↦7، لا من العدد الطبيعي إلى الزوج.

**سبب الاختيار:** الموضعان يعرّفان g بوصفها معكوس التعداد التقابلي المتعرج من \Nat إلى \Nat^2؛ لذلك يكون نوعها g:\Nat^2\to\Nat واتجاهها من الزوج إلى رقم موضعه. وDAM يثبت بصريًا inverse function «دالة عكسية» وشروط التركيب بالهوية. الاسم «معكوس» صحيح دلاليًا، لكنه لا يطابق رأس المدخل «عكسية» حرفيًا.

**سؤال مفتوح:** هل نحول «معكوس التعداد» إلى «الدالة العكسية للتعداد» اتساقًا مع DAM؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0031 — دوال المزاوجة والرموز، وقوع ١:**
  - **الأصل:** [السطر ١٨](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/pairing.tex#L18). الشاهد المسجل: «nice to have to hand the \emph{inverse} of the zig-zag enumeration,».
  - **العربية المعيارية:** [السطر ١٧](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/pairing.tex#L17)؛ الطبعة الدولية: [ص ٦٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=68) (ترقيم المتن: ٦٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=68) (ترقيم المتن: ٦٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «أكثر مباشرة. أي سيكون من المفيد أن يكون في متناولنا \emph{معكوس}».
  - **العربية التراثية:** [السطر ١٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/pairing.tex#L16)؛ الطبعة التراثية: [ص ٦٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=64) (ترقيم المتن: ٦٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «غير تتبع سبيل؟ المطلوب \emph{معكوس} التعداد المتعرج».
- **OLP-0031 — دوال المزاوجة والرموز، وقوع ٢:**
  - **الأصل:** [السطر ٤٧](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/size-of-sets/pairing.tex#L47). الشاهد المسجل: «This function $g$ is the \emph{inverse} of an enumeration of a set of».
  - **العربية المعيارية:** [السطر ٤٦](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/size-of-sets/pairing.tex#L46)؛ الطبعة الدولية: [ص ٦٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=68) (ترقيم المتن: ٦٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٦٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=68) (ترقيم المتن: ٦٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «هذه الدالة $g$ هي \emph{معكوس} تعداد مجموعة من الأزواج. وتسمى مثل».
  - **العربية التراثية:** [السطر ٤٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/size-of-sets/pairing.tex#L43)؛ الطبعة التراثية: [ص ٦٤](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=64) (ترقيم المتن: ٦٣) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «فـ$g$ \emph{معكوس} تعداد لمجموعة أزواج، واسم هذا الصنف».

## معكوس العلاقة؛ الضرب النسبي

الأصل الإنجليزي: `inverse relation; relative product`. معرّف القرار: `locale-ar-chosen-a8914e552cca8132`.

**المعنى المقصود:** معكوس العلاقة يقلب (x,y) إلى (y,x)، والضرب النسبي يمر بوسيط y بحيث Rxy وSyz.

**سبب الاختيار:** تحفظ الشواهد اتجاهي العمليتين وصيغهما. يثبت المعجم inverse relation باسم «علاقة عكسية»، لا «معكوس العلاقة»، ولم يعثر البحث الحرفي في كامل مشتقات المعجم على relative product أو «الضرب النسبي». لذلك يبقى الجزء الثاني غير موثق رسميًا في القانون المحلي.

**سؤال مفتوح:** هل يُبدَّل «معكوس العلاقة» إلى الرأس المعجمي «العلاقة العكسية»، أم أن صيغة الإضافة أدق اتساقًا مع معكوس الدالة؟ وهل «الضرب النسبي» هو المصطلح العربي المتخصص الصحيح لـ relative product في جبر العلاقات، أم يُفضَّل «تركيب العلاقات» مع التنبيه إلى اتجاه R|S؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0171 — التعبير عن العلاقات في articlestructure Structure، وقوع ١:**
  - **الأصل:** [السطر ٩٦](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/first-order-logic/models-theories/expressing-relations.tex#L96). الشاهد المسجل: «\item the relative product $R \mid R$;».
  - **العربية المعيارية:** [السطر ٩٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/first-order-logic/models-theories/expressing-relations.tex#L92)؛ الطبعة الدولية: [ص ٢٥٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=252) (ترقيم المتن: ٢٥١) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٢٥٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=252) (ترقيم المتن: ٢٥١) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «\item الضرب النسبي $R \mid R$؛».
  - **العربية التراثية:** [السطر ٩٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/first-order-logic/models-theories/expressing-relations.tex#L92)؛ الطبعة التراثية: [ص ٢٤٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=247) (ترقيم المتن: ٢٤٦) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «\item الضرب النسبي $R \mid R$؛».
- **OLP-0025 — تركيب الدوال، وقوع ٢:**
  - **الأصل:** [السطر ٢٠](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/composition.tex#L20). الشاهد المسجل: «functions is the analogue of the operation of relative product on».
  - **العربية المعيارية:** [السطر ١٩](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/composition.tex#L19)؛ الطبعة الدولية: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=59) (ترقيم المتن: ٥٨) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة)؛ طبعة المشرق: [ص ٥٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=59) (ترقيم المتن: ٥٨) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «العملية على الدوال نظير عملية الضرب النسبي على العلاقات الواردة في».
  - **العربية التراثية:** [السطر ١٨](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/functions/composition.tex#L18)؛ الطبعة التراثية: [ص ٥٦](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=56) (ترقيم المتن: ٥٥) (صفحة بدء الوحدة فحسب، لا صفحة اللفظ المثبتة بالدقة). الشاهد المسجل: «\oliflabeldef{sfr:rel:ops:sec}{وهذا نظير الضرب النسبي للعلاقات».
- **OLP-0019 — عمليات على العلاقات، وقوع ٣:**
  - **الأصل:** [السطر ٢٥](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/operations.tex#L25). الشاهد المسجل: «The \emph{relative product} of $R$ and $S$ is $(R \mid S) =».
  - **العربية المعيارية:** [السطر ٢٥](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/operations.tex#L25)؛ الطبعة الدولية: [ص ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=50) (ترقيم المتن: ٤٩) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٠](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=50) (ترقيم المتن: ٤٩) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «\emph{الضرب النسبي} للعلاقتين $R$ و$S$ هو $(R \mid S) =».
  - **العربية التراثية:** [السطر ٢٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/operations.tex#L24)؛ الطبعة التراثية: [ص ٤٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=48) (ترقيم المتن: ٤٧)، [ص ٤٩](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=49) (ترقيم المتن: ٤٨) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ونسمّي \emph{الضرب النسبي} لـ$R$ و$S$ المجموعة $(R \mid S) =».

## معكوس الدالة؛ معكوس أيسر؛ معكوس أيمن

الأصل الإنجليزي: `inverse; left inverse; right inverse of a function`. معرّف القرار: `locale-ar-chosen-d212f1928bcb3fd7`.

**المعنى المقصود:** المعكوس ثنائي الجهة، والمعكوس الأيسر g∘f=id_A، والمعكوس الأيمن f∘h=id_B.

**سبب الاختيار:** يحفظ النص اتجاه التركيب في كل تعريف. لكن معجم دمشق يثبت «دالة عكسية» و«مقلوب من اليسار» و«مقلوب من اليمين»، وهي صيغ تختلف عن «معكوس الدالة؛ معكوس أيسر؛ معكوس أيمن». فلا يوجد مسوغ لعرض اختيار الكتاب كأنه الإجماع الرسمي الوحيد.

**سؤال مفتوح:** في سياق الدوال، هل الأنسب «معكوس الدالة/معكوس أيسر/معكوس أيمن»، أم ألفاظ معجم دمشق «دالة عكسية/مقلوب من اليسار/مقلوب من اليمين»؟ وهل تقتضي سلامة اتجاه التركيب إضافة g∘f=id_A وf∘h=id_B إلى سجل المصطلح دائمًا؟

**كل وقوع مسجل لهذا القرار:**

- **OLP-0024 — معكوسات الدوال، وقوع ١:**
  - **الأصل:** [السطر ٢٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/inverses.tex#L24). الشاهد المسجل: «This is made more precise by the notion of an inverse of a function. \end{explain} \begin{defn} A function $g \colon B \to A$ is an \emph{inverse} of a function $f \colon A \to B$ if $f(g(y)) = y$ and $g(f(x)) = x$ for all $x \in A$ and $y \in B$. \end{defn}».
  - **الأصل:** [السطر ٥٤](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/functions/inverses.tex#L54). الشاهد المسجل: «Let's go slowly. We'll divide the question into two: Given a function~$f\colon A \to B$, when is there a function $g\colon B \to A$ so that $g(f(x)) = x$? Such a $g$ ``undoes'' what $f$ does, and is called a \emph{left inverse} of~$f$. Secondly, when is the…».
  - **العربية المعيارية:** [السطر ٢٣](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/inverses.tex#L23)؛ الطبعة الدولية: [ص ٥٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=57) (ترقيم المتن: ٥٦) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٧](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=57) (ترقيم المتن: ٥٦) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ويجعل مفهوم معكوس الدالة هذا الأمر أدق. \end{explain} \begin{defn} تكون الدالة $g \colon B \to A$ \emph{معكوسًا} للدالة $f \colon A \to B$ إذا كان $f(g(y)) = y$ و$g(f(x)) = x$ لكل $x \in A$ ولكل $y \in B$. \end{defn}».
  - **العربية المعيارية:** [السطر ٥٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/functions/inverses.tex#L52)؛ الطبعة الدولية: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٥٨](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=58) (ترقيم المتن: ٥٧) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «ولنمض بتؤدة، فنقسم السؤال قسمين. إذا كانت لدينا دالة~$f\colon A \to B$، فمتى توجد دالة $g\colon B \to A$ بحيث $g(f(x)) = x$؟ إن $g$ من هذا القبيل «تبطل» ما تفعله~$f$، وتسمى \emph{معكوسًا أيسر} لـ~$f$. ثم متى توجد دالة $h\colon B \to A$ بحيث $f(h(y)) = y$؟ إ…».

## هي

الأصل الإنجليزي: `is`. معرّف القرار: `retro-0005-0050:emphasis:c3a39ad651361116`.

**المعنى المقصود:** رابطة إسناد مؤنثة في تقرير أن R، لا S، هي علاقة الترتيب المختارة اعتباطًا.

**سبب الاختيار:** الإنجليزية تشدد is لإبراز أن الاختيار اتفاقي، والعربية تشدد «هي» فتستعيد هذا التقابل وتوافق «العلاقة» تأنيثًا. هذا قرار نحوي سياقي لا مدخل معجمي.

**سؤال مفتوح:** لا سؤال؛ لم تُوسم هذه الحالة لمراجعة خبيرة إضافية.

**كل وقوع مسجل لهذا القرار:**

- **OLP-0013 — تأملات فلسفية، وقوع ١:**
  - **الأصل:** [السطر ٣٦](https://github.com/OpenLogicProject/OpenLogic/blob/9620cc73f9c8e0ad003c514a5d3748f29611c4c0/content/sets-functions-relations/relations/reflections.tex#L36). الشاهد المسجل: «rather than $S$ (or vice versa) \emph{is} the ordering relation, as a».
  - **العربية المعيارية:** [السطر ٣٤](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar/content/sets-functions-relations/relations/reflections.tex#L34)؛ الطبعة الدولية: [ص ٤٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/00_OPENLOGIC_ar_R3_MSA_INTERNATIONAL.pdf#page=43) (ترقيم المتن: ٤٢) (موضع السطر مطابق لصفحة القارئ)؛ طبعة المشرق: [ص ٤٣](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-current-msa-pdf-sync-20260924/03_OPENLOGIC_ar_R3_MSA_MACHREK.pdf#page=43) (ترقيم المتن: ٤٢) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «العكس) \emph{هي} علاقة الترتيب بحكم الواقع. (وهذه حالة بسيطة جدًا من حجة».
  - **العربية التراثية:** [السطر ٣٢](https://github.com/KokunoYumeto/OpenLogic-ar/blob/86a4a7c11c0a0289ade28cb8f96acbacf9c01844/source/locale/ar-classical/content/sets-functions-relations/relations/reflections.tex#L32)؛ الطبعة التراثية: [ص ٤٢](https://github.com/KokunoYumeto/OpenLogic-ar/releases/download/ar-olp-0722-classical-eastern-rtl-complete-20260926/00-CLASSICAL-01_OPENLOGIC_ar_R3_READER.pdf#page=42) (ترقيم المتن: ٤١) (موضع السطر مطابق لصفحة القارئ). الشاهد المسجل: «بأنها \emph{هي} العلاقة في نفس الأمر، فتحكم محض يوقع في الحرج.».
