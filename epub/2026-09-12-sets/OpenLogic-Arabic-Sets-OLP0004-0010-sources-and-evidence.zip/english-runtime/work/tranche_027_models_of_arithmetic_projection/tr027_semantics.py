#!/usr/bin/env python3
"""Structural speech and native MathML for frozen OLAB-TR-027 formulas."""

from __future__ import annotations

import hashlib
import html
import importlib.util
import re
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
BASE_PATH = PROJECT / "work" / "tranche_026_model_theory_basics_projection" / "tr026_semantics.py"
PINNED_BASE_SHA256 = "78c661a1413b2dad83c5ccb03cb153e4cd7fc1211b733109cef4196bf1829ed1"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if sha256_file(BASE_PATH) != PINNED_BASE_SHA256:
    raise RuntimeError("TR-027 structural base identity mismatch")
spec = importlib.util.spec_from_file_location("tr027_bound_tr026_semantics", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError("cannot load hash-bound TR-026 semantics")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
core = base.core


def contract(required: int = 0, optional: int = 0, unbraced: bool = False) -> dict[str, Any]:
    return {
        "required_arguments": required,
        "maximum_optional_arguments": optional,
        "allow_unbraced_arguments": unbraced,
        "projection_role": "tr027_models_of_arithmetic_semantic_token",
        "formerly_unsupported_by_nd_contract": True,
    }


core.MACRO_CONTRACTS.update({
    "Int": contract(),
    "NotProves": contract(),
    "OCon": contract(0, 1),
    "OPrf": contract(0, 1),
    "Th": contract(1, 0, True),
    "begin": contract(1),
    "concat": contract(),
    "end": contract(1),
    "gn": contract(1),
    "hline": contract(),
    "mathfrak": contract(1),
    "nless": contract(),
    "nsless": contract(),
    "nsplus": contract(),
    "nssucc": contract(),
    "nstimes": contract(),
    "nszero": contract(),
    "num": contract(1),
    "oplus": contract(),
    "qquad": contract(),
    "setminus": contract(),
    "tag": contract(1),
})


_base_reader_tex = base.reader_tex


def reader_tex(normalized_tex: str) -> str:
    value = _base_reader_tex(normalized_tex).replace(r"\Proves/", r"\NotProves")
    value = value.replace(r"\not<", r"\nless")
    value = re.sub(
        r"\^\{(?:\\nssucc)+\}\s*([A-Za-z])",
        lambda match: r"\text{iterated predecessor of }" + match.group(1),
        value,
    )
    value = re.sub(
        r"\^\\nssucc\s+([A-Za-z])",
        lambda match: r"\text{predecessor of }" + match.group(1),
        value,
    )
    value = re.sub(
        r"\\begin\{array\}\{[^{}]*\}",
        lambda _match: r"\text{table begins}",
        value,
    )
    value = value.replace(r"\begin{cases}", r"\text{cases begin}")
    value = re.sub(r"\\end\{(?:array|cases)\}", r"\\text{table ends}", value)
    value = value.replace(r"\hline", r"\text{table rule}")
    value = value.replace(r"\qquad", r"\quad")
    value = re.sub(r"\\tag\{\$([^{}]*)\$\}", r"\\tag{\1}", value)
    return value


def parse_ast(normalized_tex: str) -> list[dict[str, Any]]:
    return core.parse_formula_ast(reader_tex(normalized_tex))


_base_mathml_node = base.mathml_node


def _render_option(option: str) -> str:
    return base.base.mathml_nodes(core.parse_formula_ast(reader_tex(option)))


def mathml_node(node: dict[str, Any]) -> str:
    if node.get("type") == "group" and not node.get("children"):
        return '<mspace width="0em"></mspace>'
    if node.get("type") != "macro":
        return _base_mathml_node(node)
    name = node["name"]
    args = [base.base.mathml_nodes(argument) for argument in node["arguments"]]
    options = [_render_option(option) for option in node["options"]]
    operator = {
        "Int": "ℤ", "NotProves": "⊬", "concat": "⌢", "nsless": "≺",
        "nless": "≮", "nsplus": "⊕", "nssucc": "∗", "nstimes": "⊗", "nszero": "𝘇",
        "oplus": "⊕", "setminus": "∖",
    }
    if name in operator:
        return f"<mo>{operator[name]}</mo>"
    if name == "Th":
        return f'<mrow><mi mathvariant="normal">Th</mi><mo>(</mo>{args[0]}<mo>)</mo></mrow>'
    if name == "num":
        return f"<mover>{args[0]}<mo>¯</mo></mover>"
    if name == "gn":
        return f"<mrow><mo>⌜</mo>{args[0]}<mo>⌝</mo></mrow>"
    if name in {"OCon", "OPrf"}:
        label = "Con" if name == "OCon" else "Prf"
        head = f'<mi mathvariant="sans-serif">{label}</mi>'
        return f"<msub>{head}{options[0]}</msub>" if options else head
    if name == "mathfrak":
        return f'<mstyle mathvariant="fraktur">{args[0]}</mstyle>'
    if name == "tag":
        return f"<mrow><mtext>row label </mtext>{args[0]}</mrow>"
    if name in {"begin", "end", "hline", "qquad"}:
        return '<mspace width="1em"></mspace>'
    return _base_mathml_node(node)


base.base.reader_tex = reader_tex
base.base.mathml_node = mathml_node


def _repair_juxtaposed_variables(value: str) -> str:
    replacements = {
        "<mi>xy</mi>": "<mrow><mi>x</mi><mo>⁢</mo><mi>y</mi></mrow>",
        "<mi>nm</mi>": "<mrow><mi>n</mi><mo>⁢</mo><mi>m</mi></mrow>",
    }
    for source, target in replacements.items():
        value = value.replace(source, target)
    return value


def _render_fragment(tex: str) -> str:
    return _repair_juxtaposed_variables(base.base.mathml_nodes(core.parse_formula_ast(reader_tex(tex))))


def _raw_cell(value: str) -> tuple[str, str]:
    return ("raw", value)


def _table(rows: list[list[str | tuple[str, str]]]) -> str:
    rendered_rows = []
    for row in rows:
        cells = []
        for cell in row:
            body = cell[1] if isinstance(cell, tuple) and cell[0] == "raw" else _render_fragment(str(cell))
            cells.append(f"<mtd>{body}</mtd>")
        rendered_rows.append("<mtr>" + "".join(cells) + "</mtr>")
    return "<mtable>" + "".join(rendered_rows) + "</mtable>"


def _structural_table_body(expression_id: str, normalized_tex: str) -> str | None:
    if expression_id == "expr-53c172b5c4c61663":
        successor = _table([["x", r"x^\nssucc"], ["n", "n+1"], ["a", "a"]])
        addition = _table([
            [r"x \nsplus y", "0", "m", "a"], ["0", "0", "m", "a"],
            ["n", "n", "n+m", "a"], ["a", "a", "a", "a"],
        ])
        multiplication = _table([
            [r"x \nstimes y", "0", "m", "a"], ["0", "0", "0", "0"],
            ["n", "0", "nm", "a"], ["a", "0", "a", "a"],
        ])
        return f'<mrow>{successor}<mspace width="1em"></mspace>{addition}<mspace width="1em"></mspace>{multiplication}</mrow>'
    if expression_id == "expr-cfd32f3e0dec89aa":
        successor = _table([["x", r"x^\nssucc"], ["n", "n+1"], ["a", "a"], ["b", "b"]])
        addition = _table([
            [r"x \nsplus y", "m", "a", "b"], ["n", "n+m", "b", "a"],
            ["a", "a", "b", "a"], ["b", "b", "b", "a"],
        ])
        return f'<mrow>{successor}<mspace width="1em"></mspace>{addition}</mrow>'
    if expression_id == "expr-8feac84deb26f044":
        addition_cases = _table([
            ["x+y-1", r"\text{if }x>0\text{ and }y>0"],
            ["0", r"\text{otherwise}"],
        ])
        multiplication_cases = _table([
            ["1", r"\text{if }x=1\text{ or }y=1"],
            ["xy-x-y+2", r"\text{if }x>1\text{ and }y>1"],
            ["0", r"\text{otherwise}"],
        ])
        return _table([
            [r"\Assign{+}{K'}(x,y)", "=", _raw_cell(addition_cases)],
            [r"\Assign{\times}{K'}(x,y)", "=", _raw_cell(multiplication_cases)],
        ])
    if expression_id in {"expr-9e8238f66180fc0d", "expr-ccd0d23b56b6a247"}:
        successor_cases = _table([
            ["x+1", r"\text{if }x\in\Nat"], ["a", r"\text{if }x=a"],
        ])
        addition_cases = _table([
            ["x+y", r"\text{if }x\in\Nat\text{ and }y\in\Nat"], ["a", r"\text{otherwise}"],
        ])
        multiplication_cases = _table([
            ["xy", r"\text{if }x\in\Nat\text{ and }y\in\Nat"],
            ["0", r"\text{if }x=0\text{ or }y=0"], ["a", r"\text{otherwise}"],
        ])
        second_binder = r"x \in \Domain{K}" if r"\Setabs{\tuple{x,a}}{x \in \Domain{K}}" in normalized_tex else r"n \in \Domain{K}"
        order_value = r"\Setabs{\tuple{x,y}}{x\in\Nat\text{ and }y\in\Nat\text{ and }x<y}\cup\Setabs{\tuple{x,a}}{" + second_binder + "}"
        return _table([
            [r"\Assign{\Obj{0}}{K}", "=", "0"],
            [r"\Assign{\prime}{K}(x)", "=", _raw_cell(successor_cases)],
            [r"\Assign{+}{K}(x,y)", "=", _raw_cell(addition_cases)],
            [r"\Assign{\times}{K}(x,y)", "=", _raw_cell(multiplication_cases)],
            [r"\Assign{<}{K}", "=", order_value],
        ])
    return None


def _finite_string_body(expression_id: str) -> str | None:
    """Keep finite words over the one-letter alphabet as symbol sequences."""
    lengths = {
        "expr-961b6dd3ede3cb8e": 2,
        "expr-9834876dcfb05cb1": 3,
    }
    length = lengths.get(expression_id)
    if length is None:
        return None
    return "<mrow>" + "".join("<mi>a</mi>" for _ in range(length)) + "</mrow>"


def native_mathml(expression_id: str, normalized_tex: str, display: str) -> str:
    if display not in {"inline", "block"}:
        raise ValueError(f"invalid display mode: {display}")
    body = _finite_string_body(expression_id)
    if body is None:
        body = _structural_table_body(expression_id, normalized_tex)
    if body is None:
        body = base.base.mathml_nodes(parse_ast(normalized_tex))
    body = _repair_juxtaposed_variables(body)
    if not body:
        raise ValueError(f"empty MathML body: {expression_id}")
    annotation = html.escape(normalized_tex)
    return (
        f'<math xmlns="http://www.w3.org/1998/Math/MathML" display="{display}" '
        f'data-expression-id="{expression_id}"><semantics>{body}'
        f'<annotation encoding="application/x-tex">{annotation}</annotation>'
        f'</semantics></math>'
    )


_base_spoken_macro = base.spoken_macro


def spoken_macro(node: dict[str, Any]) -> str:
    name = node["name"]
    args = [base.spoken_nodes(argument) for argument in node["arguments"]]
    options = [base.spoken_nodes(core.parse_formula_ast(reader_tex(option))) for option in node["options"]]
    fixed = {
        "Int": "the integers", "NotProves": "does not prove", "Proves": "proves",
        "concat": "concatenated with", "nless": "is not less than", "nsless": "is less than in the model",
        "nsplus": "model addition", "nssucc": "model successor",
        "nstimes": "model multiplication", "nszero": "model zero",
        "oplus": "circle plus", "prime": "successor symbol", "setminus": "set minus",
        "lfalse": "falsum", "liff": "if and only if",
        "hline": "table rule", "qquad": "",
    }
    if name in fixed:
        return fixed[name]
    if name == "Th":
        return f"theory {args[0]}"
    if name == "num":
        return f"the numeral for {args[0]}"
    if name == "gn":
        return f"the Goedel number of {args[0]}"
    if name == "OCon":
        return "the formal consistency statement" + (f" for {options[0]}" if options else "")
    if name == "OPrf":
        return "the formal proof predicate" + (f" for {options[0]}" if options else "")
    if name == "Obj":
        return f"object language symbol {args[0]}"
    if name == "mathfrak":
        return f"structure {args[0]}"
    if name == "tag":
        return f"row labeled {args[0]}"
    if name in {"eq", "neq"}:
        relation = "equals" if name == "eq" else "is not equal to"
        if len(options) == 2:
            return f"{options[0]} {relation} {options[1]}"
        if len(options) == 1:
            return f"{relation} the block of {options[0]}"
        return relation
    if name == "begin":
        return "table begins"
    if name == "end":
        return "table ends"
    return _base_spoken_macro(node)


base.spoken_macro = spoken_macro


SMALL = {
    0: "zero", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five",
    6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten",
    11: "eleven", 12: "twelve", 13: "thirteen", 14: "fourteen",
    15: "fifteen", 16: "sixteen", 17: "seventeen", 18: "eighteen",
    19: "nineteen", 20: "twenty",
}


def number_word(value: int) -> str:
    if value in SMALL:
        return SMALL[value]
    tens = {2: "twenty", 3: "thirty", 4: "forty", 5: "fifty", 6: "sixty", 7: "seventy", 8: "eighty", 9: "ninety"}
    if value < 100:
        return tens[value // 10] + (" " + SMALL[value % 10] if value % 10 else "")
    if value < 1000:
        return SMALL[value // 100] + " hundred" + (" " + number_word(value % 100) if value % 100 else "")
    return " ".join(SMALL[int(digit)] for digit in str(value))


def spoken_math(normalized_tex: str) -> str:
    finite_words = {
        "aa": "a followed by a",
        "aaa": "a followed by a followed by a",
    }
    if normalized_tex in finite_words:
        return finite_words[normalized_tex]
    speech = base.spoken_nodes(parse_ast(normalized_tex))
    speech = speech.replace("$", " ").replace("'", " prime ").replace("!", "")
    speech = speech.replace("*", " Kleene star ")
    speech = speech.replace("non minus standard", "nonstandard")
    speech = re.sub(r"at assignment\s+([A-Za-z]+)", r"the block of \1", speech)
    speech = re.sub(r"\b([ghs]) such that\b", r"\1 from", speech)
    speech = re.sub(r"\d+", lambda match: number_word(int(match.group())), speech)
    speech = re.sub(r"\s+", " ", speech).strip(" ,")
    if not speech or re.search(r"[\\{}$\d]", speech):
        raise ValueError(f"speech residue or empty output for {normalized_tex!r}: {speech!r}")
    return speech


SOURCE_CORRECTIONS: dict[str, dict[str, Any]] = {
    "TR027-SOURCE-FORMULA-001": {
        "file": "content/model-theory/models-of-arithmetic/introduction.tex",
        "line": 67,
        "lines": [67],
        "affected_formula_ids": ["projected-formula-0012896"],
        "kind": "missing_proof_witness_argument",
        "source_prose": "the existential proof-predicate occurrence supplies only the falsum code",
        "reader_prose": "the proof predicate takes x and the falsum code",
        "disclosure": "The existentially bound x must be the first argument of the proof predicate. The frozen source omits that argument; the reader supplies it and retains the source formula for provenance.",
    },
    "TR027-SOURCE-PROSE-002": {
        "file": "content/model-theory/models-of-arithmetic/standard-models.tex",
        "line": 167,
        "lines": [167, 168],
        "affected_formula_ids": ["projected-formula-0013051"],
        "kind": "range_mislabeled_as_domain",
        "source_prose": "an element not in the domain of s is used to contradict surjectivity",
        "reader_prose": "an element not in the range of s is used to contradict surjectivity",
        "disclosure": "Surjectivity concerns the range, not the domain. The reader says range while preserving the frozen wording in the correction ledger.",
    },
    "TR027-SOURCE-PROSE-003": {
        "file": "content/model-theory/models-of-arithmetic/models-of-q.tex",
        "line": 56,
        "lines": [55, 56, 57],
        "affected_formula_ids": ["projected-formula-0013172", "projected-formula-0013173", "projected-formula-0013174", "projected-formula-0013175", "projected-formula-0013176", "projected-formula-0013177", "projected-formula-0013178"],
        "kind": "missing_closing_parenthesis_in_abbreviation_list",
        "source_prose": "the parenthetical description of model addition is left open",
        "reader_prose": "the parenthetical description of model addition is closed before model multiplication",
        "disclosure": "The reader closes the parenthetical description of model addition before introducing model multiplication.",
    },
    "TR027-SOURCE-PROSE-004": {
        "file": "content/model-theory/models-of-arithmetic/models-of-q.tex",
        "line": 105,
        "lines": [103, 104, 105],
        "affected_formula_ids": ["projected-formula-0013209"],
        "kind": "out_of_domain_case_symbol",
        "source_prose": "the K-model case split says y equals b",
        "reader_prose": "the K-model case split says y equals a",
        "disclosure": "Structure K has the extra element a, not b. The reader names a in the case split, matching the displayed cases that follow.",
    },
    "TR027-SOURCE-FORMULA-005": {
        "file": "content/model-theory/models-of-arithmetic/models-of-q.tex",
        "line": 166,
        "lines": [166],
        "affected_formula_ids": ["projected-formula-0013257"],
        "kind": "wrong_addend_in_case_verification",
        "source_prose": "the b plus a case ends with b plus y",
        "reader_prose": "the b plus a case ends with b plus a",
        "disclosure": "The third nonstandard case fixes y as a. The reader replaces the stray y in the final term with a and retains the frozen alignment beside it.",
    },
    "TR027-SOURCE-PROSE-006": {
        "file": "content/model-theory/models-of-arithmetic/models-of-pa.tex",
        "line": 64,
        "lines": [64, 65, 66],
        "affected_formula_ids": ["projected-formula-0013341", "projected-formula-0013342", "projected-formula-0013343", "projected-formula-0013344"],
        "kind": "missing_nonzero_qualification_for_predecessor",
        "source_prose": "every x has a predecessor",
        "reader_prose": "every nonzero x has a predecessor",
        "disclosure": "Model zero has no predecessor in a model of Peano arithmetic. The reader restricts the predecessor assertion to nonzero x.",
    },
    "TR027-SOURCE-FORMULA-007": {
        "file": "content/model-theory/models-of-arithmetic/models-of-pa.tex",
        "line": 225,
        "lines": [225, 226],
        "affected_formula_ids": ["projected-formula-0013499", "projected-formula-0013500"],
        "kind": "inconsistent_model_addition_symbol",
        "source_prose": "the averaging equations use circle plus",
        "reader_prose": "the averaging equations use model addition",
        "disclosure": "The proof discusses addition inside M and otherwise uses the model-addition symbol. The reader replaces both circle-plus occurrences in each averaging equation with model addition.",
    },
    "TR027-SOURCE-PROSE-008": {
        "file": "content/model-theory/models-of-arithmetic/models-of-pa.tex",
        "line": 239,
        "lines": [239, 240, 241],
        "affected_formula_ids": [],
        "kind": "missing_enumerability_qualification",
        "source_prose": "all nonstandard block orders are said to be denumerable and ordered like the rationals",
        "reader_prose": "the rational-order conclusion is restricted to enumerable models",
        "disclosure": "Density and absence of endpoints alone do not force an arbitrary block order to be the rational order. The reader restricts the denumerability and rational-order conclusion to enumerable models.",
    },
    "TR027-SOURCE-FORMULA-009": {
        "file": "content/model-theory/models-of-arithmetic/computable-models.tex",
        "line": 66,
        "lines": [65, 66],
        "affected_formula_ids": ["projected-formula-0013556"],
        "kind": "set_builder_binder_mismatch",
        "source_prose": "the tuple contains x but the condition binds n",
        "reader_prose": "the tuple and condition both use x",
        "disclosure": "The second set builder contains the tuple x comma a, so its condition must range x over the domain. The reader replaces the stray n with x.",
    },
    "TR027-SOURCE-FORMULA-010": {
        "file": "content/model-theory/models-of-arithmetic/computable-models.tex",
        "line": 70,
        "lines": [69, 70],
        "affected_formula_ids": ["projected-formula-0013561"],
        "kind": "nonbijective_transport_map",
        "source_prose": "g of n equals n plus one for positive n",
        "reader_prose": "g of n equals n minus one for positive n",
        "disclosure": "With g of zero equal to a, the printed plus-one rule omits zero and one from the range and is not a bijection. The transported operations that follow require g of n to equal n minus one for positive n; the reader uses that rule.",
    },
    "TR027-SOURCE-PROSE-011": {
        "file": "content/model-theory/models-of-arithmetic/computable-models.tex",
        "line": 120,
        "lines": [119, 120, 121],
        "affected_formula_ids": ["projected-formula-0013597", "projected-formula-0013598"],
        "kind": "tennenbaum_statement_missing_isomorphism_qualification",
        "source_prose": "the standard structure N is literally the only computable model of PA",
        "reader_prose": "every computable model of PA is standard and hence isomorphic to N",
        "disclosure": "Computable presentations isomorphic to the standard model need not be literally identical to it. The reader states the Tennenbaum conclusion as: every computable model of PA is standard, hence isomorphic to N.",
    },
}


def macro_names(nodes: list[dict[str, Any]]) -> set[str]:
    return base.base.macro_names(nodes)


def semantic_class(normalized_tex: str) -> str:
    if r"\OCon" in normalized_tex or r"\OPrf" in normalized_tex or r"\gn" in normalized_tex:
        return "arithmetized_syntax_or_incompleteness"
    if r"\Sat" in normalized_tex:
        return "model_satisfaction"
    if r"\Proves" in normalized_tex:
        return "arithmetical_derivability"
    if r"\Th" in normalized_tex:
        return "arithmetical_theory"
    if any(token in normalized_tex for token in (r"\nszero", r"\nssucc", r"\nsplus", r"\nstimes", r"\nsless")):
        return "nonstandard_arithmetic_structure"
    if any(token in normalized_tex for token in (r"\Struct", r"\Domain", r"\Assign", r"\Value")):
        return "structure_interpretation_or_term_value"
    if any(token in normalized_tex for token in (r"\lforall", r"\lexists", r"\lif", r"\liff", r"\land", r"\lor", r"\lnot")):
        return "first_order_arithmetic_formula"
    if any(token in normalized_tex for token in ("=", r"\in", r"\notin", r"\subseteq", "<", ">")):
        return "arithmetic_relation_or_equation"
    return "arithmetic_notation_or_term"
