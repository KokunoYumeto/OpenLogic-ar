"""Reusable structural MathML extension for syntactic codes and rule labels.

The accepted recursive-functions parser supplies token and table structure.
No expression's semantic speech is inferred from successful parsing.
"""
from pathlib import Path
import hashlib, html, importlib.util, re
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[1]
BASE=PROJECT/'work/tranche_030_recursive_functions_projection/tr030_semantics.py'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='37407ed7d79ec284b511a53a6bdd264d457597b55b5a3f5a6003dc95a15f1bfe'
spec=importlib.util.spec_from_file_location('arithmetized_syntax_structural_base',BASE)
base=importlib.util.module_from_spec(spec); spec.loader.exec_module(base)
core=base.core
for name,args,opt in [('Gn',1,0),('scode',1,0),('Prf',0,1),('LeftR',1,0),('RightR',1,0),('Intro',1,1),('Elim',1,1),('Discharge',2,0)]:
    core.MACRO_CONTRACTS[name]=base.contract(args,opt,True)
for name in ['delta','pi','fCenter','Sequent','Cut','Weakening','Contraction','Exchange','openTuple','closeTuple']:
    core.MACRO_CONTRACTS[name]=base.contract()
core.ENVIRONMENT_CONTRACTS['aligned']=core.environment_contract('math_table','other',formerly_unsupported=True,nested_math=True)
previous=base.mathml_node

def mathml_node(node):
    if node.get('type')=='control_symbol' and node.get('value') in {',',';',':'}:
        return '<mspace width="'+{',':'0.1667em',';':'0.2778em',':':'0.2222em'}[node['value']]+'"/>'
    if node.get('type')!='macro': return previous(node)
    name=node['name']; args=base._args(node); opts=base._options(node)
    fixed={'delta':'δ','pi':'π','Gamma':'Γ','Delta':'Δ','fCenter':'⇒','Sequent':'⇒','openTuple':'⟨','closeTuple':'⟩'}
    if name in fixed: return '<mo>'+fixed[name]+'</mo>' if name not in {'delta','pi','Gamma','Delta'} else '<mi>'+fixed[name]+'</mi>'
    if name in {'Cut','Weakening','Contraction','Exchange'}: return '<mi mathvariant="normal">'+{'Cut':'Cut','Weakening':'W','Contraction':'C','Exchange':'X'}[name]+'</mi>'
    if name=='scode': return '<msub><mi mathvariant="normal">c</mi>'+args[0]+'</msub>'
    if name=='Gn':
        left='<msup><mspace width="0em"/><mstyle mathsize="70%"><mo style="display:inline-block;transform:scaleX(-1)">#</mo></mstyle></msup>'
        right='<msup><mspace width="0em"/><mstyle mathsize="70%"><mo>#</mo></mstyle></msup>'
        return '<mrow data-notation="goedel-number">'+left+args[0]+right+'</mrow>'
    if name=='Prf':
        p='<mi mathvariant="normal">Prf</mi>'
        return '<msub>'+p+opts[0]+'</msub>' if opts else p
    if name in {'LeftR','RightR','Intro','Elim'}:
        label={'LeftR':'L','RightR':'R','Intro':'Intro','Elim':'Elim'}[name]
        p='<mrow>'+args[0]+'<mi mathvariant="normal">'+label+'</mi></mrow>'
        return '<msub>'+p+opts[0]+'</msub>' if opts else p
    if name=='Discharge': return '<msup><mrow><mo>[</mo>'+args[0]+'<mo>]</mo></mrow>'+args[1]+'</msup>'
    return previous(node)

base.base.base.base.mathml_node=mathml_node

def trailing_rule_options(tex):
    """The source rule macros take their optional label after the argument."""
    pattern=re.compile(r'\\(?:Intro|Elim)(?![A-Za-z])'); cursor=0
    while (m:=pattern.search(tex,cursor)):
        start=m.end()
        while start<len(tex) and tex[start].isspace(): start+=1
        end=start
        if tex[start:start+1]=='{':
            depth=1; end=start+1
            while end<len(tex) and depth:
                if tex[end]=='{': depth+=1
                elif tex[end]=='}': depth-=1
                end+=1
        else:
            atom=re.match(r'\\[A-Za-z]+|.',tex[start:]); end=start+len(atom.group()) if atom else start
        probe=end
        while probe<len(tex) and tex[probe].isspace(): probe+=1
        if tex[probe:probe+1]=='[':
            close=tex.find(']',probe+1)
            if close<0: raise ValueError('unclosed rule label')
            tex=tex[:m.end()]+tex[probe:close+1]+tex[m.end():end]+tex[close+1:]
            cursor=close+1
        else: cursor=end
    return tex

def native_mathml(expression_id,tex,display='inline'):
    surrogate=trailing_rule_options(tex)
    # TeX thin spacing between digit groups does not split one integer into
    # separate operands. Keep the exact source spelling only in annotation.
    surrogate=re.sub(r'(?<=\d)\\,(?=\d)','',surrogate)
    # A TeX prime is a superscript even inside a later indexed parenthesis.
    surrogate=re.sub(r"(?<=[A-Za-z0-9}])('+)",lambda m:'^{'+r'\prime'*len(m.group(1))+'}',surrogate)
    value=base.native_mathml(expression_id,surrogate,display)
    if surrogate!=tex: value=value.replace('<annotation encoding="application/x-tex">'+html.escape(surrogate)+'</annotation>','<annotation encoding="application/x-tex">'+html.escape(tex)+'</annotation>')
    root=ET.fromstring(value); namespace='http://www.w3.org/1998/Math/MathML'; q=lambda t:'{'+namespace+'}'+t
    changed=False
    for node in reversed(list(root.iter())):
        if node.tag not in {q('msup'),q('msub')} or len(node)!=2: continue
        inner=node[0]; opposite=q('msub') if node.tag==q('msup') else q('msup')
        if inner.tag!=opposite or len(inner)!=2: continue
        # Explicit braced/parenthesized bases have an intervening mrow and
        # deliberately do not satisfy this same-atom adjacency condition.
        base_node=inner[0]; sub=inner[1] if node.tag==q('msup') else node[1]; sup=node[1] if node.tag==q('msup') else inner[1]
        node.tag=q('msubsup'); node[:]=[base_node,sub,sup]; changed=True
    if changed:
        ET.register_namespace('',namespace); value=ET.tostring(root,encoding='unicode')
    return value
