"""Batch-local execution of the hash-pinned native-MathML forwarding module."""
from pathlib import Path
import hashlib
import sys

sys.dont_write_bytecode = True
_project = Path(__file__).resolve().parents[2]
_target = _project / "work/tr059_tr064_semantic_batch/structural_mathml.py"
_expected = "9bb1e368cda043dc0078236e8b1c54d0bb2db19f9acc982bb4b3c2113e3c1484"
_source = _target.read_bytes()
if hashlib.sha256(_source).hexdigest() != _expected:
    raise ValueError("native-MathML forwarding source drift")
exec(compile(_source, str(_target), "exec"), globals())

# This batch's source adds the ordinary TeX constructs below that are not in
# the sealed TR059--TR064 grammar.  Keep the inherited parser fail-closed by
# contracting only those exact command names, then render their mathematical
# topology with native MathML.  ``unitline`` and ``unitsquare`` are the exact
# ``\text{L}`` and ``\text{S}`` definitions in the already pinned
# open-logic-config.sty.
for _name in (
    "nsubseteq", "subsetneq", "sqsubseteq", "exists", "forall",
    "rightarrow", "lim", "unitline", "unitsquare", "ell", "epsilon",
    "nu", "xi", "Phi", "Psi", "Theta", "Upsilon", "Xi", "chi",
    "gamma", "iota", "kappa", "psi", "rho", "theta", "upsilon",
    "varphi", "zeta",
):
    core.MACRO_CONTRACTS[_name] = base.contract()
for _name in ("dot", "mathrm"):
    core.MACRO_CONTRACTS[_name] = base.contract(1)
core.MACRO_CONTRACTS["nicefrac"] = base.contract(2)

_sealed_mathml_node = base.renderer.mathml_node


def _batch_mathml_node(node):
    if node.get("type") != "macro":
        return _sealed_mathml_node(node)
    name = node["name"]
    symbols = {
        "nsubseteq": "⊈",
        "subsetneq": "⊊",
        "sqsubseteq": "⊑",
        "exists": "∃",
        "forall": "∀",
        "rightarrow": "→",
    }
    if name in symbols:
        return "<mo>" + symbols[name] + "</mo>"
    greek = {
        "ell": "ℓ", "epsilon": "ε", "nu": "ν", "xi": "ξ",
        "Phi": "Φ", "Psi": "Ψ", "Theta": "Θ", "Upsilon": "Υ",
        "Xi": "Ξ", "chi": "χ", "gamma": "γ", "iota": "ι",
        "kappa": "κ", "psi": "ψ", "rho": "ρ", "theta": "θ",
        "upsilon": "υ", "varphi": "φ", "zeta": "ζ",
    }
    if name in greek:
        return "<mi>" + greek[name] + "</mi>"
    if name == "lim":
        return '<mi mathvariant="normal">lim</mi>'
    if name in {"unitline", "unitsquare"}:
        return "<mtext>" + {"unitline": "L", "unitsquare": "S"}[name] + "</mtext>"
    args = grammar._args(node)
    if name == "dot":
        return '<mover accent="true">' + args[0] + "<mo>˙</mo></mover>"
    if name == "mathrm":
        return '<mstyle mathvariant="normal">' + args[0] + "</mstyle>"
    if name == "nicefrac":
        return "<mfrac>" + args[0] + args[1] + "</mfrac>"
    return _sealed_mathml_node(node)


# The inherited renderer dispatches through this module-level hook.
base.renderer.mathml_node = _batch_mathml_node
base.mathml_node = _batch_mathml_node

_forwarded_native_mathml = native_mathml


def native_mathml(expression_id, tex, display="inline", source_context=None):
    """Render source-bound TikZ foreach label variables as their value list."""
    notation = (source_context or {}).get("mathml_notation", {})
    if notation.get("notation") != "tikz_foreach_label_variable":
        return _forwarded_native_mathml(
            expression_id, tex, display, source_context=source_context
        )
    required = {"notation", "source_identifier", "role", "expanded_values"}
    allowed = required | {"source_duplicate_preserved"}
    if frozenset(notation) not in {frozenset(required), frozenset(allowed)}:
        raise ValueError("invalid TikZ foreach label-variable context shape")
    if display != "inline" or tex != notation["source_identifier"]:
        raise ValueError("TikZ foreach label-variable source identity mismatch")
    if notation["role"] not in {
        "horizontal_axis_tick_label", "vertical_axis_tick_label"
    }:
        raise ValueError("unsupported TikZ foreach label-variable role")
    values = notation["expanded_values"]
    if (
        not isinstance(values, list)
        or len(values) < 2
        or not all(isinstance(value, str) and re.fullmatch(r"-?[0-9]+", value)
                   for value in values)
    ):
        raise ValueError("invalid TikZ foreach expanded tick values")
    if notation.get("source_duplicate_preserved") is True:
        if len(values) == len(set(values)):
            raise ValueError("declared TikZ tick duplicate is absent")
    elif len(values) != len(set(values)):
        raise ValueError("undeclared TikZ tick duplicate")
    raw = _source_text(source_context)
    offset = source_context.get("offset")
    if (
        source_context.get("normalized_tex") != tex
        or not isinstance(offset, int)
        or raw[offset:offset + len(tex) + 2] != "$" + tex + "$"
    ):
        raise ValueError("TikZ foreach label-variable source replay mismatch")

    rendered = []
    for value in values:
        if value.startswith("-"):
            rendered.append("<mrow><mo>−</mo><mn>" + value[1:] + "</mn></mrow>")
        else:
            rendered.append("<mn>" + value + "</mn>")
    body = '<mo separator="true">,</mo>'.join(rendered)
    duplicate = (
        ' data-source-duplicate-preserved="true"'
        if notation.get("source_duplicate_preserved") is True else ""
    )
    annotation = html.escape(tex).replace("\r", "&#13;")
    return (
        '<math xmlns="http://www.w3.org/1998/Math/MathML" display="inline" '
        'data-expression-id="' + html.escape(expression_id, quote=True) + '" '
        'data-source-notation="tikz-foreach-label-variable" '
        'data-axis-tick-role="' + notation["role"] + '"' + duplicate + '>'
        '<semantics><mrow data-expanded-values="source-order">' + body + '</mrow>'
        '<annotation encoding="application/x-tex">' + annotation + '</annotation>'
        '</semantics></math>'
    )
