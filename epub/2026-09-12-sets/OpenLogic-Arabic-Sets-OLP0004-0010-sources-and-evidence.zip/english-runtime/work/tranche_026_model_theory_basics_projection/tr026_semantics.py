#!/usr/bin/env python3
"""Structural MathML and words-only mathematics for frozen OLAB-TR-026.

The already audited parser/MathML implementation from TR-025 is hash-bound and
extended here with the complete, finite macro vocabulary of Basics of Model
Theory.  This module does not choose meanings: expression and occurrence
meaning remains tranche-local authored authority.
"""

from __future__ import annotations

import hashlib
import importlib.util
import re
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
BASE_PATH = PROJECT / "work" / "tranche_025_fol_beyond_projection" / "tr025_semantics.py"
PINNED_BASE_SHA256 = "2c55779f8195b931f1ed6a0cb66a44cfad253f442dc95d58aefa45905d9ed229"
CORE_PATH = PROJECT / "work" / "tranche_008_syntax_semantics_projection" / "formula_parser_core.py"
PINNED_CORE_SHA256 = "b90d5a716fc8a558e43b148ef114dfc02a56134b144b8fd64b722835d4e986de"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if sha256_file(BASE_PATH) != PINNED_BASE_SHA256:
    raise RuntimeError("TR-026 shared MathML implementation identity check failed")
if sha256_file(CORE_PATH) != PINNED_CORE_SHA256:
    raise RuntimeError("TR-026 parser-core identity check failed")

spec = importlib.util.spec_from_file_location("tr026_bound_tr025_mathml", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError("cannot load hash-bound MathML implementation")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
core = base.core


def contract(required: int = 0, optional: int = 0, unbraced: bool = False) -> dict[str, Any]:
    return {
        "required_arguments": required,
        "maximum_optional_arguments": optional,
        "allow_unbraced_arguments": unbraced,
        "projection_role": "tr026_model_theory_semantic_token",
        "formerly_unsupported_by_nd_contract": True,
    }


# Complete named-macro vocabulary in the 223 frozen normalized shapes.
core.MACRO_CONTRACTS.update({
    "Assign": contract(2, 0, True),
    "Expan": contract(2),
    "PIso": contract(1),
    "QuantRank": contract(1),
    "Rat": contract(),
    "Real": contract(),
    "Sat": contract(2),
    "Notsat": contract(2),
    "Setabs": contract(2),
    "Theory": contract(1),
    "Value": contract(2),
    "approx": contract(),
    "bigcup": contract(),
    "cap": contract(),
    "cdots": contract(),
    "circ": contract(),
    "colon": contract(),
    "dom": contract(1),
    "elemequiv": contract(),
    "elemequivn": contract(1),
    "emptyseq": contract(),
    "emptyset": contract(),
    "equiv": contract(),
    "ge": contract(),
    "in": contract(),
    "iso": contract(),
    "ison": contract(1),
    "langle": contract(),
    "ldots": contract(),
    "le": contract(),
    "models": contract(),
    "neq": contract(0, 2),
    "notag": contract(),
    "notin": contract(),
    "ollabel": contract(1),
    "omega": contract(),
    "rangle": contract(),
    "simeq": contract(),
    "subseteq": contract(),
    "substruct": contract(),
    "mathbf": contract(1),
})

_base_reader_tex = base.reader_tex


def reader_tex(normalized_tex: str) -> str:
    value = normalized_tex.replace(r"\Sat/", r"\Notsat")
    value = re.sub(r"\\iso\[([^\]]+)\]", lambda match: r"\ison{" + match.group(1) + "}", value)
    value = re.sub(r"\\elemequiv\[([^\]]+)\]", lambda match: r"\elemequivn{" + match.group(1) + "}", value)
    return _base_reader_tex(value)


base.reader_tex = reader_tex

base.MATHML_OPERATOR.update({
    "Rat": "ℚ", "Real": "ℝ", "approx": "≈", "bigcup": "⋃",
    "cap": "∩", "cdots": "⋯", "circ": "∘", "colon": ":",
    "elemequiv": "≡", "emptyset": "∅", "equiv": "≡", "ge": "≥",
    "in": "∈", "iso": "≅", "langle": "⟨", "ldots": "…",
    "le": "≤", "models": "⊨", "neq": "≠", "notin": "∉",
    "omega": "ω", "rangle": "⟩", "simeq": "≃", "subseteq": "⊆",
    "substruct": "⊆",
})

_base_mathml_node = base.mathml_node


def _args(node: dict[str, Any]) -> list[str]:
    return [base.mathml_nodes(argument) for argument in node["arguments"]]


def mathml_node(node: dict[str, Any]) -> str:
    if node.get("type") != "macro":
        return _base_mathml_node(node)
    name = node["name"]
    arguments = _args(node)
    if name == "Expan":
        return f'<mrow><mstyle mathvariant="fraktur">{arguments[0]}</mstyle><mo>[</mo>{arguments[1]}<mo>]</mo></mrow>'
    if name == "PIso":
        return f'<mstyle mathvariant="script">{arguments[0]}</mstyle>'
    if name == "QuantRank":
        return f'<mrow><mi mathvariant="normal">qr</mi><mo>(</mo>{arguments[0]}<mo>)</mo></mrow>'
    if name in {"Sat", "Notsat"}:
        symbol = "⊨" if name == "Sat" else "⊭"
        model = f'<mstyle mathvariant="fraktur">{arguments[0]}</mstyle>'
        return f"<mrow>{model}<mo>{symbol}</mo>{arguments[1]}</mrow>"
    if name == "Setabs":
        return f"<mrow><mo>{{</mo>{arguments[0]}<mo>|</mo>{arguments[1]}<mo>}}</mo></mrow>"
    if name == "Theory":
        model = f'<mstyle mathvariant="fraktur">{arguments[0]}</mstyle>'
        return f'<mrow><mi mathvariant="normal">Th</mi><mo>(</mo>{model}<mo>)</mo></mrow>'
    if name == "Value":
        model = f'<mstyle mathvariant="fraktur">{arguments[1]}</mstyle>'
        value = f"<mrow><mo>⟦</mo>{arguments[0]}<mo>⟧</mo></mrow>"
        return f"<msup>{value}{model}</msup>"
    if name == "dom":
        return f'<mrow><mi mathvariant="normal">dom</mi><mo>(</mo>{arguments[0]}<mo>)</mo></mrow>'
    if name == "emptyseq":
        return "<mrow><mo>⟨</mo><mo>⟩</mo></mrow>"
    if name == "mathbf":
        return f'<mstyle mathvariant="bold">{arguments[0]}</mstyle>'
    if name == "ison":
        return f"<msub><mo>≅</mo>{arguments[0]}</msub>"
    if name == "elemequivn":
        return f"<msub><mo>≡</mo>{arguments[0]}</msub>"
    if name in {"notag", "ollabel"}:
        return '<mspace width="0em"></mspace>'
    return _base_mathml_node(node)


base.mathml_node = mathml_node


def parse_ast(normalized_tex: str) -> list[dict[str, Any]]:
    return base.parse_ast(normalized_tex)


def native_mathml(expression_id: str, normalized_tex: str, display: str) -> str:
    return base.native_mathml(expression_id, normalized_tex, display)


OPERATOR_SPEECH = {
    "approx": "approximately equivalent to", "bigcup": "the union of",
    "cap": "intersect", "cdots": "and so on", "circ": "composed with",
    "colon": "such that", "cup": "union", "dots": "and so on",
    "elemequiv": "is elementarily equivalent to", "emptyset": "the empty set",
    "equiv": "is equivalent to", "ge": "is greater than or equal to",
    "geq": "is greater than or equal to", "ident": "is syntactically identical to",
    "in": "is in", "iso": "is isomorphic to", "land": "and",
    "langle": "left angle bracket", "ldots": "and so on", "le": "is less than or equal to",
    "lif": "implies", "lnot": "not", "lor": "or", "models": "satisfies",
    "Nat": "the natural numbers", "neq": "is not equal to", "notin": "is not in",
    "omega": "omega", "Rat": "the rational numbers", "Real": "the real numbers",
    "rangle": "right angle bracket", "simeq": "is isomorphic to",
    "subseteq": "is a subset of", "substruct": "is a substructure of",
    "times": "cross", "to": "to",
}


def _plain(value: str) -> str:
    value = value.replace("!A", "formula A").replace("!B", "formula B")
    value = value.replace("~", " ")
    replacements = {
        "!=": " is not equal to ", "<=": " is less than or equal to ",
        ">=": " is greater than or equal to ", "=": " equals ",
        "<": " is less than ", ">": " is greater than ", "+": " plus ",
        "-": " minus ", ":": " such that ", "|": " such that ",
        "&": " ", "\\": " ", "_": " sub ",
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    value = value.replace("(", " open parenthesis ").replace(")", " close parenthesis ")
    value = value.replace("[", " at assignment ").replace("]", " ")
    value = value.replace(",", " comma ").replace(";", " semicolon ")
    value = value.replace(".", " ")
    return re.sub(r"\s+", " ", value).strip()


def spoken_nodes(nodes: list[dict[str, Any]]) -> str:
    pieces: list[str] = []
    for node in nodes:
        kind = node["type"]
        if kind == "text":
            pieces.append(_plain(node["value"]))
        elif kind == "group":
            pieces.append(spoken_nodes(node["children"]))
        elif kind == "script":
            word = "sub" if node["kind"] == "subscript" else "superscript"
            pieces.append(f"{word} {spoken_nodes([node['argument']])}")
        elif kind == "control_symbol":
            if node["value"] not in {"{", "}", "\\", "&"}:
                pieces.append(_plain(node["value"]))
        elif kind == "row_break":
            pieces.append("next row")
        elif kind == "alignment_separator":
            continue
        elif kind == "macro":
            pieces.append(spoken_macro(node))
        else:
            raise ValueError(f"unhandled speech AST node: {kind}")
    return re.sub(r"\s+", " ", " ".join(piece for piece in pieces if piece)).strip(" ,")


def spoken_macro(node: dict[str, Any]) -> str:
    name = node["name"]
    args = [spoken_nodes(arg) for arg in node["arguments"]]
    opts = [spoken_nodes(core.parse_formula_ast(opt)) for opt in node["options"]]
    if name in OPERATOR_SPEECH:
        return OPERATOR_SPEECH[name]
    if name == "Assign":
        return f"the interpretation of {args[0]} in structure {args[1]}"
    if name == "Domain":
        return f"the domain of structure {args[0]}"
    if name == "Expan":
        return f"the expansion of structure {args[0]} by relation {args[1]}"
    if name == "Gamma":
        return "Gamma"
    if name == "Lang":
        return f"language {args[0]}"
    if name == "PIso":
        return args[0]
    if name == "QuantRank":
        return f"the quantifier rank of {args[0]}"
    if name in {"Sat", "Notsat"}:
        verb = "satisfies" if name == "Sat" else "does not satisfy"
        return f"structure {args[0]} {verb} {args[1]}"
    if name == "Setabs":
        return f"the set of {args[0]} such that {args[1]}"
    if name == "Struct":
        return f"structure {args[0]}"
    if name == "Theory":
        return f"the theory of structure {args[0]}"
    if name == "Value":
        return f"the value of {args[0]} in structure {args[1]}"
    if name == "dom":
        return f"the domain of {args[0]}"
    if name == "emptyseq":
        return "the empty sequence"
    if name == "mathbf":
        return f"bold {args[0]}"
    if name == "ison":
        return f"is partially isomorphic to at level {args[0]}"
    if name == "elemequivn":
        return f"is elementarily equivalent through quantifier rank {args[0]} to"
    if name in {"lforall", "lexists"}:
        quantifier = "for every" if name == "lforall" else "there exists"
        if len(opts) == 2:
            return f"{quantifier} {opts[0]}, {opts[1]}"
        return quantifier + (" " + " ".join(opts) if opts else "")
    if name == "eq":
        return f"{opts[0]} equals {opts[1]}" if len(opts) == 2 else "equals"
    if name == "tuple":
        return f"the tuple {args[0]}"
    if name in {"text", "intertext"}:
        return _plain(base.literal_text(node["arguments"][0]))
    if name == "quad":
        return ""
    if name in {"notag", "ollabel"}:
        return ""
    raise ValueError(f"no words-only contract for macro {name!r}")


def spoken_math(normalized_tex: str) -> str:
    speech = spoken_nodes(parse_ast(normalized_tex))
    speech = re.sub(r"\s+", " ", speech).strip(" ,")
    if not speech or re.search(r"[\\{}$]", speech):
        raise ValueError(f"speech residue or empty output for {normalized_tex!r}: {speech!r}")
    return speech


def semantic_class(normalized_tex: str) -> str:
    if r"\Sat" in normalized_tex or r"\models" in normalized_tex:
        return "satisfaction_or_theory"
    if any(token in normalized_tex for token in (r"\iso", r"\simeq", r"\elemequiv", r"\approx")):
        return "isomorphism_or_equivalence"
    if any(token in normalized_tex for token in (r"\lforall", r"\lexists", r"\lif", r"\land", r"\lor", r"\lnot")):
        return "first_order_formula"
    if any(token in normalized_tex for token in ("=", r"\in", r"\subseteq", r"\substruct", "<", ">")):
        return "mathematical_relation_or_equation"
    return "model_theory_notation"


SOURCE_CORRECTIONS: dict[str, dict[str, Any]] = {
    "TR026-SOURCE-FORMULA-001": {
        "file": "content/model-theory/basics/isomorphism.tex",
        "line": 89,
        "expression_id": "expr-449980c431a75564",
        "affected_formula_ids": ["projected-formula-0012530"],
        "kind": "wrong_structure_in_term_value_clause",
        "source_prose": "the second row uses the interpretation of f in M",
        "reader_prose": "the second row uses the interpretation of f in M prime",
        "disclosure": "The left side evaluates t in M prime under h composed with s, so its function clause must use the interpretation of f in M prime. The frozen display prints M; the reader discloses and speaks M prime.",
    },
    "TR026-SOURCE-FORMULA-002": {
        "file": "content/model-theory/basics/isomorphism.tex",
        "line": 96,
        "expression_id": "expr-94eb1c931162851e",
        "affected_formula_ids": ["projected-formula-0012533"],
        "kind": "missing_closing_parenthesis_in_alignment",
        "source_prose": "the first equality leaves the outer application of h unclosed",
        "reader_prose": "the first equality closes h after the interpretation term",
        "disclosure": "The first row opens h applied to the interpretation of f but has only the inner closing parenthesis. The reader supplies the missing outer close while retaining the frozen source formula beside the corrected reading.",
    },
    "TR026-SOURCE-PROSE-003": {
        "file": "content/model-theory/basics/partial-iso.tex",
        "line": 76,
        "affected_formula_ids": ["projected-formula-0012653", "projected-formula-0012654"],
        "kind": "duplicated_indefinite_article",
        "source_prose": "p is a an isomorphism",
        "reader_prose": "p is an isomorphism",
        "disclosure": "The reader removes the duplicated article in the conclusion of the back-and-forth construction.",
    },
}
