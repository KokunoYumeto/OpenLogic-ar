"""Fail-closed TR045–TR049 structural MathML over the frozen TR036 base.

This grammar module does not author speech, repair source claims, or confer
acceptance. All imported accepted helper files remain byte-for-byte frozen.
"""
from pathlib import Path
from functools import lru_cache
import hashlib
import html
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE_PATH = HERE.parent / "tr036_tr044_semantic_batch" / "structural_mathml.py"
BASE_SHA256 = "6dabf4e23fbb52d59ab6aba2df445b2897825b8464c1700cff834ff93bc698cf"
if hashlib.sha256(BASE_PATH.read_bytes()).hexdigest() != BASE_SHA256:
    raise RuntimeError("frozen TR036–TR044 MathML foundation identity mismatch")
spec = importlib.util.spec_from_file_location("tr045_tr049_frozen_structural_base", BASE_PATH)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
PROJECT = HERE.parents[1]
SOURCE_ROOT = base.SOURCE_ROOT
CONFIG_SHA256 = base.CONFIG_SHA256
SOURCE_DEFINITION_PINS = (
    {"path": "open-logic-config.sty", "sha256": CONFIG_SHA256,
     "rules": "truth values; pAssign, pValue, pSat, tf argument topology; Log names and postfix indices; PVar, Frm, iR and nSequent; inherited fn, Th, eq and lambda conventions"},
    {"path": "content/lambda-calculus/syntax/abbreviated-syntax.tex", "sha256": "b9987c121bb971f20b15b2e4700b11b7f03ce17e854887de1de2a83c817f288f",
     "rules": "unparenthesized lambda abstraction has the widest possible scope; TeX optional-argument boundaries are not mathematical fences"},
    {"path": "sty/open-logic-referencing.sty", "sha256": "6b8df594d50b522a261d7e8fb36c4bf02b8e5d5433b6f096259ff9a3f076eed4",
     "rules": "olref three optional namespace components plus mandatory target; embedded references remain explicitly authored bindings"},
    {"path": "sty/bussproofs-extra.sty", "sha256": "7dcbc725f91babecb177f2a7dcf9c2bd83800bd9ed30b1f8b25f4eaa9fa60fcf",
     "rules": "AxiomC braced node content and imported bussproofs convention used by the bounded postfix proof stack"},
)
for pin in SOURCE_DEFINITION_PINS:
    if hashlib.sha256((SOURCE_ROOT / pin["path"]).read_bytes()).hexdigest() != pin["sha256"]:
        raise RuntimeError("immutable source definition identity mismatch: " + pin["path"])

ORACLE_ROUTES = {}
CHAPTER_CONFIGURATION_PINS = []
ORACLE_MANIFEST_PINS = []
SOURCE_AUTHORITY_PINS = []
SOURCE_RECORDS = {}
for config_path in sorted((HERE / "chapters").glob("*.json")):
    config_data = config_path.read_bytes()
    configuration = json.loads(config_data)
    route = Path(configuration["oracle"])
    oracle = (PROJECT / route).resolve() if not route.is_absolute() else route.resolve()
    tranche_id = configuration["tranche_id"]
    if tranche_id in ORACLE_ROUTES:
        raise RuntimeError("duplicate configured source authority: " + tranche_id)
    ORACLE_ROUTES[tranche_id] = oracle
    CHAPTER_CONFIGURATION_PINS.append({"path": config_path.relative_to(PROJECT).as_posix(),
                                       "sha256": hashlib.sha256(config_data).hexdigest()})
    manifest_path = oracle / "EVIDENCE_MANIFEST.json"
    manifest_data = manifest_path.read_bytes()
    manifest_hash = hashlib.sha256(manifest_data).hexdigest()
    if manifest_hash != configuration["oracle_manifest_sha256"]:
        raise RuntimeError("configured oracle manifest identity mismatch: " + tranche_id)
    ORACLE_MANIFEST_PINS.append({"path": str(manifest_path), "sha256": manifest_hash})
    manifest = json.loads(manifest_data)
    authority_pin = next((item for item in manifest["artifacts"] if item["path"] == "SOURCE_AUTHORITY.json"), None)
    if authority_pin is None:
        raise RuntimeError("configured oracle lacks a source-authority byte pin")
    authority_path = oracle / authority_pin["path"]
    authority_data = authority_path.read_bytes()
    authority_hash = hashlib.sha256(authority_data).hexdigest()
    if authority_hash != authority_pin["sha256"]:
        raise RuntimeError("configured source authority identity mismatch: " + tranche_id)
    SOURCE_AUTHORITY_PINS.append({"tranche_id": tranche_id, "path": str(authority_path),
                                  "sha256": authority_hash, "manifest_sha256": manifest_hash})
    authority = json.loads(authority_data)
    if Path(authority["authority_root"]).resolve() != SOURCE_ROOT.resolve() or authority.get("mutable") is not False:
        raise RuntimeError("new batch authority root or immutability mismatch")
    for record in authority["source_records"]:
        if record["path"] in SOURCE_RECORDS and SOURCE_RECORDS[record["path"]] != record["sha256"]:
            raise RuntimeError("conflicting new batch source identities")
        SOURCE_RECORDS[record["path"]] = record["sha256"]
if not ORACLE_ROUTES:
    raise RuntimeError("no configured chapter source authorities")
# Compatibility for the bounded probe; rendering resolves every chapter via
# ORACLE_ROUTES above and does not assume a batch number or oracle root.
ORACLE = next(iter(ORACLE_ROUTES.values())).parent


@lru_cache(maxsize=None)
def _verified_source(file):
    if file not in SOURCE_RECORDS:
        raise ValueError("source context is outside the configured frozen batch")
    data = (SOURCE_ROOT / file).read_bytes()
    if hashlib.sha256(data).hexdigest() != SOURCE_RECORDS[file]:
        raise ValueError("frozen source context identity mismatch: " + file)
    return data.decode("utf-8")


def _source_text(context):
    return _verified_source(context.get("file"))


# Lexically bound notation in the reused renderer must resolve only against
# this batch's immutable source records. This is an in-memory import hook.
base._source_text = _source_text

core = base.core
grammar = base.grammar
render_nodes = base.render_nodes
previous_node = base.mathml_node
SYMBOLS = {"star": "⋆", "odot": "⊙", "triangle": "△", "sim": "∼", "infty": "∞", "nSequent": "∣"}
LOG_NAMES = {"LogCL": "C", "LogIL": "I", "LogLuk": "Ł", "LogGod": "G", "LogKs": "Ks",
             "LogKw": "Kw", "LogLP": "LP", "LogRM": "RM", "LogHal": "Hal"}
for name in SYMBOLS | {"True": "T", "False": "F", "Undef": "U"}:
    core.MACRO_CONTRACTS[name] = base.contract()
for name in LOG_NAMES:
    core.MACRO_CONTRACTS[name] = base.contract(0, 1)
for name in ("pAssign", "pValue", "tf", "Log", "underbrace", "mathord"):
    core.MACRO_CONTRACTS[name] = base.contract(1)
core.MACRO_CONTRACTS["smash"] = base.contract(1, 1)
core.MACRO_CONTRACTS["Frm"] = base.contract(0, 1)
for name in ("pSat", "pNotsat", "iR"):
    core.MACRO_CONTRACTS[name] = base.contract(2)
core.MACRO_CONTRACTS["PVar"] = base.contract()
core.MACRO_CONTRACTS["phantom"] = base.contract(1)
PROOF_ARITIES = {"UnaryInfC": 1, "BinaryInfC": 2, "TrinaryInfC": 3, "QuaternaryInfC": 4, "QuinaryInfC": 5}
for name in ("AxiomC", "RightLabel", *PROOF_ARITIES):
    core.MACRO_CONTRACTS[name] = base.contract(1)
core.MACRO_CONTRACTS["DisplayProof"] = base.contract()
base.POSTFIX_OPTIONS.update({"tf", "Log", "pSat", "pNotsat", "iR"})


def _parenthesized(text, offset):
    """Read xparse's optional d() argument without confusing nested groups."""
    depth, cursor = 1, offset + 1
    while cursor < len(text):
        if text[cursor] == "\\":
            command = core.control_sequence_at(text, cursor)
            cursor = command[1] if command else cursor + 1
            continue
        if text[cursor] == "{":
            _, _, cursor, _ = core.parse_balanced(text, cursor)
            continue
        if text[cursor] == "(":
            depth += 1
        elif text[cursor] == ")":
            depth -= 1
            if depth == 0:
                return cursor + 1, text[offset + 1:cursor]
        cursor += 1
    raise ValueError("unclosed parenthesized pValue argument")


_previous_invocation = core.parse_macro_invocation


def parse_macro_invocation(text, offset):
    invocation = _previous_invocation(text, offset)
    name = invocation["name"]
    if name == "Entails":
        # open-logic-config.sty:391-403 defines a boolean slash followed by an
        # optional subscript.  Preserve the slash as an internal first option
        # so the AST can distinguish vDash from nvDash without exposing the
        # source punctuation as a MathML operand.
        cursor = core.skip_space(text, invocation["end"])
        negated = text[cursor:cursor + 1] == "/"
        if negated:
            cursor = core.skip_space(text, cursor + 1)
        options = ["/"] if negated else []
        if text[cursor:cursor + 1] == "[":
            _, _, cursor, value = core.parse_balanced(text, cursor, "[")
            options.append(value)
        invocation["options"] = options
        invocation["end"] = cursor
    elif name == "pValue":
        cursor = core.skip_space(text, invocation["end"])
        if text[cursor:cursor + 1] == "(":
            cursor, value = _parenthesized(text, cursor)
            invocation["arguments"].append(value)
            invocation["end"] = cursor
        cursor = core.skip_space(text, invocation["end"])
        if text[cursor:cursor + 1] == "[":
            _, _, cursor, value = core.parse_balanced(text, cursor, "[")
            invocation["options"] = [value]
            invocation["end"] = cursor
    elif name == "underbrace":
        cursor = core.skip_space(text, invocation["end"])
        if text[cursor:cursor + 1] == "_":
            cursor = core.skip_space(text, cursor + 1)
            if text[cursor:cursor + 1] == "{":
                _, _, cursor, value = core.parse_balanced(text, cursor)
            else:
                command = core.control_sequence_at(text, cursor)
                end = command[1] if command else cursor + 1
                value, cursor = text[cursor:end], end
            invocation["arguments"].append(value)
            invocation["end"] = cursor
    return invocation


core.parse_macro_invocation = parse_macro_invocation


def mathml_node(node):
    if node.get("type") != "macro":
        return previous_node(node)
    name = node["name"]
    if name not in set(SYMBOLS) | set(LOG_NAMES) | {"True", "False", "Undef", "pAssign", "pValue", "tf", "Log", "underbrace", "mathord", "smash", "Frm", "pSat", "pNotsat", "iR", "PVar", "phantom", "Entails"}:
        return previous_node(node)
    args, opts = grammar._args(node), grammar._options(node)
    if name in SYMBOLS:
        return '<mo>' + SYMBOLS[name] + '</mo>'
    if name in {"True", "False", "Undef"}:
        return '<mi mathvariant="double-struck">' + {"True": "T", "False": "F", "Undef": "U"}[name] + '</mi>'
    if name == "PVar":
        return '<msub><mi mathvariant="normal">At</mi><mn>0</mn></msub>'
    if name == "Entails":
        raw_options = node.get("options", [])
        negated = bool(raw_options and raw_options[0] == "/")
        subscript_index = 1 if negated else 0
        operator = '<mo>' + ('⊭' if negated else '⊨') + '</mo>'
        return ('<msub>' + operator + opts[subscript_index] + '</msub>'
                if len(opts) > subscript_index else operator)
    if name == "phantom":
        # Native phantom layout represents exactly the source's invisible
        # alignment material; it is not an added mathematical operand.
        return '<mphantom>' + args[0] + '</mphantom>'
    if name in LOG_NAMES:
        head = '<mi mathvariant="bold">' + LOG_NAMES[name] + '</mi>'
        return '<msub>' + head + opts[0] + '</msub>' if opts else head
    if name == "Log":
        head = base._named_style(node["arguments"][0], "bold")
        return '<msub>' + head + opts[0] + '</msub>' if opts else head
    if name == "pAssign":
        return base._first_style(node["arguments"][0], "fraktur")
    if name == "pValue":
        head = '<mover accent="true">' + base._first_style(node["arguments"][0], "fraktur") + '<mo>¯</mo></mover>'
        if opts:
            head = '<msub>' + head + opts[0] + '</msub>'
        return '<mrow>' + head + ('<mo>(</mo>' + args[1] + '<mo>)</mo>' if len(args) == 2 else '') + '</mrow>'
    if name in {"pSat", "pNotsat"}:
        operator = '<mo>' + ('⊨' if name == 'pSat' else '⊭') + '</mo>'
        if opts:
            operator = '<msub>' + operator + opts[0] + '</msub>'
        return '<mrow>' + base._first_style(node["arguments"][0], "fraktur") + operator + args[1] + '</mrow>'
    if name == "tf":
        head = '<mover accent="true">' + args[0] + '<mo>~</mo></mover>'
        return '<msub>' + head + opts[0] + '</msub>' if opts else head
    if name == "iR":
        head = '<msub>' + args[0] + opts[0] + '</msub>' if opts else args[0]
        return '<mrow>' + head + args[1] + '</mrow>'
    if name == "underbrace":
        head = '<munder accentunder="true">' + args[0] + '<mo>⏟</mo></munder>'
        return '<munder>' + head + args[1] + '</munder>' if len(args) == 2 else head
    if name in {"mathord", "smash"}:
        return args[0]
    if name == "Frm":
        head = '<mi mathvariant="normal">Frm</mi>'
        if opts:
            head = '<mrow>' + head + '<mo>(</mo>' + base._first_style(grammar.parse_ast(node["options"][0]), "script") + '<mo>)</mo></mrow>'
        return head
    raise ValueError("missing explicit new MathML contract: " + name)


base.renderer.mathml_node = mathml_node


def _proof_mathml(expression_id, tex, display, source_context):
    """Native topology for a complete, explicitly supported postfix proof.

This grammar only combines supplied premises, conclusions and rule labels.
Unknown proof commands, stack underflow or surplus proof roots fail closed.
"""
    if source_context is None:
        raise ValueError("postfix proof requires hash-verified source context")
    if display not in {"inline", "block"}:
        raise ValueError("invalid display mode: " + display)
    stack, label, cursor, ended = [], None, 0, False

    def fragment(source):
        source = source.strip()
        if source.startswith('$') and source.endswith('$'):
            source = source[1:-1]
        value = native_mathml(expression_id, source, source_context=source_context)
        root = ET.fromstring(value)
        namespace = '{http://www.w3.org/1998/Math/MathML}'
        return ET.tostring(root.find(namespace + 'semantics')[0], encoding='unicode')

    while (cursor := core.skip_space(tex, cursor)) < len(tex):
        invocation = core.parse_macro_invocation(tex, cursor)
        command = invocation["name"]
        if ended:
            raise ValueError("material after DisplayProof is unsupported")
        if command == "AxiomC":
            stack.append(fragment(invocation["arguments"][0]))
        elif command == "RightLabel":
            if label is not None:
                raise ValueError("unconsumed postfix proof rule label")
            label = fragment(invocation["arguments"][0])
        elif command in PROOF_ARITIES:
            count = PROOF_ARITIES[command]
            if len(stack) < count:
                raise ValueError("postfix proof premise stack underflow")
            premises, stack = stack[-count:], stack[:-count]
            numerator = '<mrow>' + '<mspace width="2em"/>'.join(premises) + '</mrow>'
            conclusion = fragment(invocation["arguments"][0])
            inference = '<mfrac linethickness="thin">' + numerator + conclusion + '</mfrac>'
            if label is not None:
                inference = '<mrow>' + inference + '<mspace width="0.5em"/>' + label + '</mrow>'
                label = None
            stack.append(inference)
        elif command == "DisplayProof":
            ended = True
        else:
            raise ValueError("unsupported command in postfix proof: " + command)
        cursor = invocation["end"]
    if not ended or len(stack) != 1 or label is not None:
        raise ValueError("incomplete or ambiguous postfix proof")
    annotation = html.escape(tex).replace('\r', '&#13;')
    return (f'<math xmlns="http://www.w3.org/1998/Math/MathML" display="{display}" '
            f'data-expression-id="{html.escape(expression_id, quote=True)}" data-proof-structure="postfix-inference">'
            f'<semantics>{stack[0]}<annotation encoding="application/x-tex">{annotation}</annotation></semantics></math>')


_MATHML_NAMESPACE = "http://www.w3.org/1998/Math/MathML"
_Q = lambda name: "{" + _MATHML_NAMESPACE + "}" + name
_WIDEST_SCOPE_CONTINUATIONS = {
    "projected-formula-0023016": {
        "file": "content/lambda-calculus/lambda-definability/primitive-recursive-functions.tex",
        "tex_sha256": "ea4e4dd4a814275c975d38be608902484c81ce31e4b19030829d7271a65de3a1",
        "mode": "next-row", "target_depth": 2, "moved_token": "m"},
    "projected-formula-0023035": {
        "file": "content/lambda-calculus/lambda-definability/fixpoints.tex",
        "tex_sha256": "3a92e2a77861c0eca372f39dacba079899d1d69b47e101401423efd4d1346fc9",
        "mode": "next-row", "target_depth": 1, "moved_token": "Mult"},
    "projected-formula-0023087": {
        "file": "content/lambda-calculus/lambda-definability/fixpoints.tex",
        "tex_sha256": "540280aaf3c57a0dfc1acd3926ce7053f3106e3b2962481d711ad9c3d9da3b8b",
        "mode": "same-row", "target_depth": 2, "moved_token": "Y"},
}


def _is_lambda_row(element):
    children = list(element)
    return (element.tag == _Q("mrow") and len(children) >= 5 and
            children[0].tag == _Q("mi") and children[0].text == "λ" and
            children[2].tag == _Q("mo") and children[2].text == ".")


def _lambda_body(element):
    if not _is_lambda_row(element) or list(element)[-1].tag != _Q("mrow"):
        raise ValueError("widest-scope lambda does not have the expected structural body")
    return list(element)[-1]


def _widest_scope_mathml(value, tex, source_context):
    """Move source continuation factors into the printed lambdas' bodies.

    The immutable source declares that an unfenced lambda has widest scope.
    These three displays cross an alignment-row or TeX optional-argument
    boundary, neither of which is a mathematical fence.  The base renderer
    preserves the tokens but initially places the continuations as siblings;
    this bounded transform moves those existing nodes, adding no operands or
    parentheses and retaining the exact TeX annotation.
    """
    formula_id = (source_context or {}).get("formula_id")
    contract = _WIDEST_SCOPE_CONTINUATIONS.get(formula_id)
    if contract is None:
        return value
    context_normalized = source_context.get("normalized_tex")
    context_raw = source_context.get("tex")
    if (source_context.get("file") != contract["file"] or
            not isinstance(context_normalized, str) or
            hashlib.sha256(context_normalized.encode()).hexdigest() != contract["tex_sha256"] or
            tex not in {context_normalized, context_raw}):
        raise ValueError("widest-scope source identity mismatch: " + formula_id)
    root = ET.fromstring(value)
    semantics = root.find(_Q("semantics"))
    if semantics is None or not len(semantics):
        raise ValueError("widest-scope MathML lacks native semantics: " + formula_id)
    presentation = semantics[0]
    before_parentheses = [(item.text or "") for item in presentation.iter(_Q("mo")) if item.text in {"(", ")"}]
    before_lambdas = sum(1 for item in presentation.iter() if _is_lambda_row(item))
    moved = []
    if contract["mode"] == "next-row":
        if presentation.tag != _Q("mtable") or len(presentation) < 2:
            raise ValueError("widest-scope continuation lacks two display rows: " + formula_id)
        first_row, continuation_row = list(presentation)[:2]
        first_cells, continuation_cells = list(first_row), list(continuation_row)
        if len(first_cells) < 2 or len(continuation_cells) < 2 or not len(first_cells[-1]) or not len(continuation_cells[-1]):
            raise ValueError("widest-scope continuation has unexpected alignment cells: " + formula_id)
        equation = list(first_cells[-1])[0]
        outer = next((child for child in list(equation) if _is_lambda_row(child)), None)
        if outer is None:
            raise ValueError("widest-scope outer lambda missing: " + formula_id)
        target = outer
        for _ in range(contract["target_depth"] - 1):
            target = next((item for item in target.iter() if item is not target and _is_lambda_row(item)), None)
            if target is None:
                raise ValueError("widest-scope nested lambda missing: " + formula_id)
        continuation = list(continuation_cells[-1])[0]
        while len(continuation) and list(continuation)[0].tag == _Q("mspace"):
            continuation.remove(list(continuation)[0])
        moved = list(continuation)
        if not moved:
            raise ValueError("widest-scope continuation is empty: " + formula_id)
        body = _lambda_body(target)
        body.append(ET.Element(_Q("mspace"), {"linebreak": "newline", "width": "0em"}))
        for child in moved:
            continuation.remove(child); body.append(child)
        presentation.remove(continuation_row)
    else:
        equation = next((item for item in presentation.iter(_Q("mrow"))
                         if len(item) >= 3 and list(item)[0].tag == _Q("mo") and
                         list(item)[0].text == "↠" and _is_lambda_row(list(item)[1])), None)
        if equation is None:
            raise ValueError("widest-scope reduction row missing: " + formula_id)
        outer = list(equation)[1]
        target = outer
        for _ in range(contract["target_depth"] - 1):
            target = next((item for item in target.iter() if item is not target and _is_lambda_row(item)), None)
            if target is None:
                raise ValueError("widest-scope nested lambda missing: " + formula_id)
        moved = list(equation)[2:]
        if not moved:
            raise ValueError("widest-scope following factor missing: " + formula_id)
        body = _lambda_body(target)
        for child in moved:
            equation.remove(child); body.append(child)
    target.set("data-source-scope", "widest-continuation")
    root.set("data-authored-scope-topology", "widest-lambda-continuation")
    moved_text = "".join("".join(item.itertext()) for item in moved)
    if contract["moved_token"] not in moved_text:
        raise ValueError("widest-scope expected continuation token missing: " + formula_id)
    after_parentheses = [(item.text or "") for item in presentation.iter(_Q("mo")) if item.text in {"(", ")"}]
    after_lambdas = sum(1 for item in presentation.iter() if _is_lambda_row(item))
    if before_parentheses != after_parentheses or before_lambdas != after_lambdas:
        raise ValueError("widest-scope transform invented or removed a fence/lambda: " + formula_id)
    ET.register_namespace("", _MATHML_NAMESPACE)
    # Preserve CRLF bytes in the exact source TeX annotation across the
    # ElementTree round trip; literal CR is otherwise XML-normalized on read.
    return ET.tostring(root, encoding="unicode", short_empty_elements=True).replace("\r", "&#13;")


def native_mathml(expression_id, tex, display="inline", source_context=None):
    if source_context is not None:
        _source_text(source_context)
    if re.match(r"\s*\\AxiomC\b", tex):
        return _proof_mathml(expression_id, tex, display, source_context)
    surrogate = tex.replace(r"\pSat/", r"\pNotsat")
    value = base.native_mathml(expression_id, surrogate, display, source_context=source_context)
    annotation = html.escape(tex).replace("\r", "&#13;")
    value = re.sub(r'(<annotation encoding="application/x-tex">).*?(</annotation>)',
                   lambda match: match[1] + annotation + match[2], value, flags=re.S)
    return _widest_scope_mathml(value, tex, source_context)
