#!/usr/bin/env python3
"""Native semantic rendering for frozen OLAB-TR-025 expressions.

The module is deliberately tranche-local.  It hash-pins the already frozen
parser core, declares the complete macro vocabulary used by Beyond
First-order Logic, and produces structural presentation MathML.  Speech and
meaning are explicit authored authority in ``author_tr025.py``; this module
does not invent semantic prose or provide a catch-all renderer.
"""

from __future__ import annotations

import hashlib
import html
import re
import sys
from pathlib import Path
from typing import Any, Iterable


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
CORE_DIR = PROJECT / "work" / "tranche_008_syntax_semantics_projection"
CORE_PATH = CORE_DIR / "formula_parser_core.py"
PINNED_CORE_SHA256 = "b90d5a716fc8a558e43b148ef114dfc02a56134b144b8fd64b722835d4e986de"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if not CORE_PATH.is_file() or sha256_file(CORE_PATH) != PINNED_CORE_SHA256:
    raise RuntimeError("TR-025 parser-core identity check failed")
if str(CORE_DIR) not in sys.path:
    sys.path.insert(0, str(CORE_DIR))
import formula_parser_core as core  # noqa: E402


def contract(required: int = 0, optional: int = 0, unbraced: bool = False) -> dict[str, Any]:
    return {
        "required_arguments": required,
        "maximum_optional_arguments": optional,
        "allow_unbraced_arguments": unbraced,
        "projection_role": "tr025_beyond_first_order_semantic_token",
        "formerly_unsupported_by_nd_contract": True,
    }


# Complete vocabulary after reader-only normalization performed by reader_tex.
core.MACRO_CONTRACTS = {
    "Assign": contract(2),
    "Atom": contract(2),
    "Box": contract(),
    "Delta": contract(),
    "Diamond": contract(),
    "Domain": contract(1, 0, True),
    "Entails": contract(),
    "Gamma": contract(),
    "Lang": contract(1, 0, True),
    "Log": contract(1),
    "Nat": contract(),
    "Obj": contract(1, 0, True),
    "Omega": contract(),
    "Proves": contract(),
    "Struct": contract(1, 0, True),
    "Subst": contract(3),
    "cdot": contract(),
    "cup": contract(),
    "dots": contract(),
    "eq": contract(0, 2),
    "geq": contract(),
    "ident": contract(),
    "intertext": contract(1),
    "lambd": contract(0, 2),
    "land": contract(),
    "lexists": contract(0, 2),
    "lexistsunique": contract(0, 2),
    "lfalse": contract(),
    "lforall": contract(0, 2, True),
    "lif": contract(),
    "liff": contract(),
    "lnot": contract(),
    "log": contract(),
    "lor": contract(),
    "mModel": contract(1, 0, True),
    "mNotsat": contract(2, 1),
    "mSat": contract(2, 1),
    "neq": contract(0, 2),
    "prime": contract(),
    "quad": contract(),
    "sigma": contract(),
    "sqrt": contract(1, 0, True),
    "tau": contract(),
    "text": contract(1),
    "times": contract(),
    "to": contract(),
    "tuple": contract(1),
    "vec": contract(1, 0, True),
}
core.ENVIRONMENT_CONTRACTS = {}
core.ALLOWED_CONTROL_SYMBOLS = frozenset(set(core.ALLOWED_CONTROL_SYMBOLS) | {"&", "{", "}", "\\"})


# One source-prose defect is material to the interpretation of the adjacent
# formula.  Source bytes remain immutable; the correction is disclosed in the
# producer artifacts and limited to reader metadata.
SOURCE_CORRECTIONS: dict[str, dict[str, Any]] = {
    "TR025-SOURCE-PROSE-001": {
        "file": "content/first-order-logic/beyond/higher-order-logic.tex",
        "line": 87,
        "expression_id": "expr-9c3245dfb4ac54c1",
        "affected_formula_ids": ["projected-formula-0012234"],
        "kind": "lambda_bound_variable_type_mismatch",
        "source_prose": "for any x of type sigma",
        "reader_prose": "for any x of type tau",
        "disclosure": (
            "The lambda clause at line sixty eight declares x to have type tau, "
            "so the function defined by lambda x dot s takes inputs of type tau. "
            "The later source sentence says sigma; the reader states tau while "
            "preserving the frozen source text."
        ),
    },
    "TR025-SOURCE-FORMULA-002": {
        "file": "content/first-order-logic/beyond/second-order-logic.tex",
        "line": 142,
        "expression_id": "expr-e7e35496e8ce02fb",
        "affected_formula_ids": ["projected-formula-0012092"],
        "kind": "successor_notation_mismatch",
        "source_prose": "if s of x equals s of y, then x equals y",
        "reader_prose": "if successor x equals successor y, then x equals y",
        "disclosure": (
            "The displayed language declares the object-language prime symbol "
            "as successor, but this injectivity axiom prints s as the function "
            "name. The reader identifies s here as successor while preserving "
            "the frozen formula."
        ),
    },
    "TR025-SOURCE-PROSE-003": {
        "file": "content/first-order-logic/beyond/intuitionistic-logic.tex",
        "line": 115,
        "affected_formula_ids": [],
        "kind": "duplicated_demonstrative",
        "source_prose": "This following theorem makes this more precise.",
        "reader_prose": "The following theorem makes this more precise.",
        "disclosure": "The reader corrects the source phrase 'This following theorem' to 'The following theorem.'",
    },
    "TR025-SOURCE-PROSE-004": {
        "file": "content/first-order-logic/beyond/intuitionistic-logic.tex",
        "line": 137,
        "affected_formula_ids": [],
        "kind": "missing_as_in_definition_lead_in",
        "source_prose": "It is defined inductively follows",
        "reader_prose": "It is defined inductively as follows",
        "disclosure": "The reader supplies the missing word 'as' in the definition lead-in.",
    },
    "TR025-SOURCE-PROSE-005": {
        "file": "content/first-order-logic/beyond/intuitionistic-logic.tex",
        "line": 201,
        "lines": [201, 202],
        "affected_formula_ids": [],
        "kind": "missing_and_wrong_indefinite_articles",
        "source_prose": "a set W, partial order R on W with a least element, and an monotone assignment",
        "reader_prose": "a set W, a partial order R on W with a least element, and a monotone assignment",
        "disclosure": "The reader supplies the missing article before partial order and changes 'an monotone' to 'a monotone.'",
    },
    "TR025-SOURCE-PROSE-006": {
        "file": "content/first-order-logic/beyond/other-logics.tex",
        "line": 14,
        "affected_formula_ids": [],
        "kind": "duplicated_indefinite_article",
        "source_prose": "create your own a syntax",
        "reader_prose": "create your own syntax",
        "disclosure": "The reader removes the extra article in 'create your own a syntax.'",
    },
    "TR025-SOURCE-PROSE-007": {
        "file": "content/first-order-logic/beyond/other-logics.tex",
        "line": 34,
        "affected_formula_ids": [],
        "kind": "verb_form_typo",
        "source_prose": "you may find such creatures studies",
        "reader_prose": "you may find such creatures studied",
        "disclosure": "The reader corrects 'creatures studies' to 'creatures studied.'",
    },
    "TR025-SOURCE-PROSE-008": {
        "file": "content/first-order-logic/beyond/second-order-logic.tex",
        "line": 212,
        "affected_formula_ids": [],
        "kind": "wrong_preposition_in_contrast",
        "source_prose": "give up the full second-order semantics in terms of the weaker one",
        "reader_prose": "give up the full second-order semantics in favor of the weaker one",
        "disclosure": "The reader changes 'in terms of' to 'in favor of' to preserve the stated contrast.",
    },
}


def reader_tex(normalized_tex: str) -> str:
    # Open Logic slash suffixes are typographic negation idioms.  Distinct
    # macro names make their semantics explicit before parsing.
    value = normalized_tex.replace(r"\mSat/", r"\mNotsat")
    value = value.replace(r"\eq/", r"\neq")
    value = value.replace(r"\lexists!", r"\lexistsunique")
    return value


def parse_ast(normalized_tex: str) -> list[dict[str, Any]]:
    nodes = core.parse_formula_ast(reader_tex(normalized_tex))
    # ``mSat`` takes its optional world argument after both required
    # arguments.  The shared parser accepts prefix optional arguments, so bind
    # this source-defined postfix form explicitly instead of leaving ``[w]``
    # as unrelated punctuation in the MathML tree.
    if (
        len(nodes) == 2
        and nodes[0]["type"] == "macro"
        and nodes[0]["name"] in {"mSat", "mNotsat"}
        and nodes[1]["type"] == "text"
    ):
        match = re.fullmatch(r"\s*\[([^\]]+)\]\s*", nodes[1]["value"])
        if match:
            nodes[0]["options"] = [match.group(1)]
            nodes = [nodes[0]]
    return nodes


MATHML_OPERATOR = {
    "Box": "□",
    "Delta": "Δ",
    "Diamond": "◇",
    "Entails": "⊨",
    "Gamma": "Γ",
    "Nat": "ℕ",
    "Omega": "Ω",
    "Proves": "⊢",
    "cdot": "·",
    "cup": "∪",
    "dots": "…",
    "geq": "≥",
    "ident": "≡",
    "land": "∧",
    "lfalse": "⊥",
    "lif": "→",
    "liff": "↔",
    "lnot": "¬",
    "lor": "∨",
    "prime": "′",
    "sigma": "σ",
    "tau": "τ",
    "times": "×",
    "to": "→",
}

CONTROL = {
    "{": "{", "}": "}", "[": "[", "]": "]", "(": "(", ")": ")",
    ",": ",", ";": ";", "!": "", ":": ":", " ": "", "&": "", "\\": "",
}


def _tokens(value: str) -> list[str]:
    return re.findall(r"![A-Z]|[A-Za-z]+|[0-9]+|!=|<=|>=|[^\s]", value)


def text_fragments(value: str) -> list[str]:
    rendered: list[str] = []
    operators = {
        "=": "=", "<": "&lt;", ">": "&gt;", "+": "+", "-": "−",
        "/": "/", "|": "|", ":": ":",
    }
    punctuation = set("(),;[]'.")
    for token in _tokens(value):
        if token.startswith("!") and len(token) == 2:
            token = token[1:]
        if token in {"!", "$", "~", "&"}:
            continue
        if token.isdigit():
            rendered.append(f"<mn>{token}</mn>")
        elif token.isalpha():
            rendered.append(f"<mi>{html.escape(token)}</mi>")
        elif token in operators:
            rendered.append(f"<mo>{operators[token]}</mo>")
        elif token in punctuation:
            rendered.append(f"<mo>{html.escape(token)}</mo>")
        else:
            rendered.append(f"<mo>{html.escape(token)}</mo>")
    return rendered


ASCII_PRIME = "<mo>&#x27;</mo>"
UNICODE_PRIME = "<mo>′</mo>"


def pop_script_base(rendered: list[str]) -> str:
    if not rendered:
        raise ValueError("script has no MathML base")
    start = len(rendered) - 1
    delimiter_pairs = {
        "<mo>)</mo>": ("<mo>(</mo>", "<mo>)</mo>"),
        "<mo>]</mo>": ("<mo>[</mo>", "<mo>]</mo>"),
        "<mo>}</mo>": ("<mo>{</mo>", "<mo>}</mo>"),
    }
    if rendered[start] in delimiter_pairs:
        opening, closing = delimiter_pairs[rendered[start]]
        depth = 0
        for index in range(len(rendered) - 1, -1, -1):
            if rendered[index] == closing:
                depth += 1
            elif rendered[index] == opening:
                depth -= 1
                if depth == 0:
                    start = index
                    break
        else:
            raise ValueError("script follows an unmatched closing delimiter")
    base_parts = rendered[start:]
    del rendered[start:]
    return base_parts[0] if len(base_parts) == 1 else "<mrow>" + "".join(base_parts) + "</mrow>"


def bind_postfix_prime(rendered: list[str]) -> list[str]:
    result: list[str] = []
    for fragment in rendered:
        if fragment != ASCII_PRIME:
            result.append(fragment)
            continue
        base = pop_script_base(result)
        result.append(f"<msup>{base}{UNICODE_PRIME}</msup>")
    return result


def literal_text(nodes: list[dict[str, Any]]) -> str:
    pieces: list[str] = []
    for node in nodes:
        kind = node["type"]
        if kind == "text":
            pieces.append(node["value"].replace("~", " ").replace("!!{", "").replace("}", ""))
        elif kind == "group":
            pieces.append(literal_text(node["children"]))
        elif kind == "control_symbol":
            pieces.append(CONTROL.get(node["value"], node["value"]))
        elif kind == "macro" and node["name"] in {"text", "intertext"}:
            pieces.append(literal_text(node["arguments"][0]))
        elif kind == "macro" and node["name"] == "quad":
            pieces.append(" ")
        elif kind == "script":
            pieces.append(literal_text([node["argument"]]))
        elif kind in {"row_break", "alignment_separator"}:
            pieces.append(" ")
        else:
            pieces.append("")
    return re.sub(r"\s+", " ", "".join(pieces)).strip()


def intertext_mathml(nodes: list[dict[str, Any]]) -> str:
    """Render prose containing dollar-delimited inline mathematics structurally.

    The source's modal-axiom display uses ``\\intertext`` with three embedded
    formulas.  Treating the whole argument as ``mtext`` would erase the
    formula operands and operators from the accessibility tree.
    """

    rendered: list[str] = []
    prose_parts: list[str] = []
    math_parts: list[str] = []
    in_math = False

    def flush_prose() -> None:
        if not prose_parts:
            return
        prose = "".join(prose_parts)
        prose = prose.replace("~", " ").replace("``", "“").replace("''", "”")
        prose = prose.replace("!!", "")
        prose = re.sub(r"\s+", " ", prose)
        if prose:
            rendered.append(f"<mtext>{html.escape(prose)}</mtext>")
        prose_parts.clear()

    def flush_math() -> None:
        if math_parts:
            rendered.extend(math_parts)
            math_parts.clear()

    for node in nodes:
        if node["type"] == "group" and not in_math:
            prose_parts.append(literal_text(node["children"]))
            continue
        if node["type"] != "text":
            if in_math:
                math_parts.append(mathml_node(node))
            else:
                flush_prose()
                rendered.append(mathml_node(node))
            continue
        parts = node["value"].split("$")
        for index, part in enumerate(parts):
            if part:
                if in_math:
                    math_parts.extend(text_fragments(part))
                else:
                    prose_parts.append(part)
            if index < len(parts) - 1:
                if in_math:
                    flush_math()
                else:
                    flush_prose()
                in_math = not in_math
    if in_math:
        raise ValueError("unclosed dollar-delimited mathematics in intertext")
    flush_prose()
    return "<mrow>" + "".join(rendered) + "</mrow>"


def mathml_nodes(nodes: list[dict[str, Any]]) -> str:
    if any(node["type"] in {"row_break", "alignment_separator"} for node in nodes):
        return mathml_table(nodes)
    rendered: list[str] = []
    for node in nodes:
        kind = node["type"]
        if kind == "text":
            rendered.extend(text_fragments(node["value"]))
        elif kind == "script":
            base = pop_script_base(rendered)
            argument = node["argument"]
            if (
                argument["type"] == "group"
                and len(argument["children"]) == 1
                and argument["children"][0] == {"type": "text", "value": "st"}
            ):
                script = "<mrow><mi>s</mi><mi>t</mi></mrow>"
            else:
                script = mathml_node(argument)
            tag = "msub" if node["kind"] == "subscript" else "msup"
            rendered.append(f"<{tag}>{base}{script}</{tag}>")
        else:
            rendered.append(mathml_node(node))
    return "<mrow>" + "".join(bind_postfix_prime(rendered)) + "</mrow>"


def mathml_table(nodes: list[dict[str, Any]]) -> str:
    rows: list[list[list[dict[str, Any]]]] = [[[]]]
    for node in nodes:
        if node["type"] == "row_break":
            rows.append([[]])
        elif node["type"] == "alignment_separator":
            rows[-1].append([])
        elif node["type"] == "macro" and node["name"] == "intertext":
            if rows[-1] != [[]]:
                rows.append([[]])
            rows[-1][0].append(node)
            rows.append([[]])
        else:
            rows[-1][-1].append(node)
    rows = [row for row in rows if any(cell for cell in row)]
    width = max(len(row) for row in rows)
    rendered_rows: list[str] = []
    for row in rows:
        if (
            len(row) == 1
            and len(row[0]) == 1
            and row[0][0]["type"] == "macro"
            and row[0][0]["name"] == "intertext"
        ):
            cells = f'<mtd columnspan="{width}">{mathml_node(row[0][0])}</mtd>'
        else:
            rendered_cells: list[str] = []
            for cell in row:
                body = mathml_nodes(cell) if cell else ""
                if body == "<mrow></mrow>":
                    body = ""
                rendered_cells.append(f"<mtd>{body}</mtd>")
            cells = "".join(rendered_cells)
            cells += "<mtd></mtd>" * (width - len(row))
        rendered_rows.append(f"<mtr>{cells}</mtr>")
    return "<mtable>" + "".join(rendered_rows) + "</mtable>"


def _optional(option: str) -> str:
    return mathml_nodes(core.parse_formula_ast(option))


def mathml_node(node: dict[str, Any]) -> str:
    kind = node["type"]
    if kind == "text":
        return "".join(text_fragments(node["value"]))
    if kind == "group":
        return mathml_nodes(node["children"])
    if kind == "control_symbol":
        value = CONTROL[node["value"]]
        return f"<mo>{value}</mo>" if value else "<mrow></mrow>"
    if kind == "alignment_separator":
        return '<mspace width="1em"></mspace>'
    if kind == "row_break":
        return '<mspace linebreak="newline"></mspace>'
    if kind == "script":
        return mathml_node(node["argument"])
    if kind != "macro":
        raise ValueError(f"unsupported AST node type: {kind}")
    name = node["name"]
    arguments = [mathml_nodes(argument) for argument in node["arguments"]]
    options = [_optional(option) for option in node["options"]]
    if name in MATHML_OPERATOR:
        return f"<mo>{MATHML_OPERATOR[name]}</mo>"
    if name == "Assign":
        structure = f'<mstyle mathvariant="fraktur">{arguments[1]}</mstyle>'
        return f"<msup>{arguments[0]}{structure}</msup>"
    if name == "Atom":
        return f"<mrow>{arguments[0]}<mo>(</mo>{arguments[1]}<mo>)</mo></mrow>"
    if name == "Domain":
        structure = f'<mstyle mathvariant="fraktur">{arguments[0]}</mstyle>'
        return f"<mrow><mo>|</mo>{structure}<mo>|</mo></mrow>"
    if name == "Lang":
        return f'<mstyle mathvariant="script">{arguments[0]}</mstyle>'
    if name == "Log":
        return f'<mstyle mathvariant="bold">{arguments[0]}</mstyle>'
    if name == "Obj":
        return f'<mstyle mathvariant="sans-serif-italic">{arguments[0]}</mstyle>'
    if name in {"Struct", "mModel"}:
        return f'<mstyle mathvariant="fraktur">{arguments[0]}</mstyle>'
    if name == "Subst":
        return f"<mrow>{arguments[0]}<mo>[</mo>{arguments[1]}<mo>/</mo>{arguments[2]}<mo>]</mo></mrow>"
    if name in {"eq", "neq"}:
        symbol = "=" if name == "eq" else "≠"
        if options:
            if len(options) != 2:
                raise ValueError("identity macro requires two optional arguments")
            return f"<mrow>{options[0]}<mo>{symbol}</mo>{options[1]}</mrow>"
        return f"<mo>{symbol}</mo>"
    if name in {"lexists", "lexistsunique", "lforall"}:
        symbol = {"lexists": "∃", "lexistsunique": "∃!", "lforall": "∀"}[name]
        return f"<mrow><mo>{symbol}</mo>{''.join(options)}</mrow>"
    if name == "lambd":
        if len(options) != 2:
            raise ValueError("lambda macro requires binder and body")
        return f"<mrow><mo>λ</mo>{options[0]}<mo>.</mo>{options[1]}</mrow>"
    if name in {"mSat", "mNotsat"}:
        symbol = "⊩" if name == "mSat" else "⊮"
        model = f'<mstyle mathvariant="fraktur">{arguments[0]}</mstyle>'
        if options:
            return f"<mrow>{model}<mo>,</mo>{options[0]}<mo>{symbol}</mo>{arguments[1]}</mrow>"
        return f"<mrow>{model}<mo>{symbol}</mo>{arguments[1]}</mrow>"
    if name == "sqrt":
        return f"<msqrt>{arguments[0]}</msqrt>"
    if name == "tuple":
        return f"<mrow><mo>⟨</mo>{arguments[0]}<mo>⟩</mo></mrow>"
    if name == "vec":
        return f"<mover>{arguments[0]}<mo>→</mo></mover>"
    if name == "log":
        return '<mi mathvariant="normal">log</mi>'
    if name == "intertext":
        return intertext_mathml(node["arguments"][0])
    if name == "text":
        return intertext_mathml(node["arguments"][0])
    if name == "quad":
        return '<mspace width="1em"></mspace>'
    raise ValueError(f"no MathML contract for macro {name!r}")


def native_mathml(expression_id: str, normalized_tex: str, display: str) -> str:
    if display not in {"inline", "block"}:
        raise ValueError(f"invalid MathML display mode: {display}")
    body = mathml_nodes(parse_ast(normalized_tex))
    if not body:
        raise ValueError(f"empty MathML body: {expression_id}")
    return (
        f'<math xmlns="http://www.w3.org/1998/Math/MathML" display="{display}" '
        f'data-expression-id="{expression_id}">{body}</math>'
    )


def macro_names(nodes: Iterable[dict[str, Any]]) -> set[str]:
    result: set[str] = set()
    for node in nodes:
        kind = node["type"]
        if kind == "macro":
            result.add(node["name"])
            for argument in node["arguments"]:
                result.update(macro_names(argument))
            for option in node["options"]:
                result.update(macro_names(core.parse_formula_ast(option)))
        elif kind == "group":
            result.update(macro_names(node["children"]))
        elif kind == "script":
            result.update(macro_names([node["argument"]]))
    return result


def semantic_class(normalized_tex: str) -> str:
    names = macro_names(parse_ast(normalized_tex))
    if names.intersection({"mSat", "mNotsat", "mModel"}):
        return "kripke_model_or_forcing"
    if names.intersection({"Box", "Diamond", "Log"}):
        return "modal_formula_or_system"
    if names.intersection({"lambd", "sigma", "tau", "Omega"}) or r"\to" in normalized_tex:
        return "higher_order_type_or_term"
    if "Subst" in names or "Atom" in names and "R" in normalized_tex:
        return "second_order_formula_or_relation"
    if names.intersection({"lexists", "lexistsunique", "lforall"}):
        return "quantified_formula"
    if names.intersection({"Entails", "Proves"}):
        return "consequence_or_derivability"
    if names.intersection({"Assign", "Domain", "Struct"}):
        return "structure_interpretation"
    if names.intersection({"land", "lor", "lif", "liff", "lnot", "lfalse"}) or "!" in normalized_tex:
        return "formula_or_connective"
    if names.intersection({"Lang", "Obj", "eq", "neq"}):
        return "language_symbol_term_or_identity"
    return "contextual_mathematical_notation"
