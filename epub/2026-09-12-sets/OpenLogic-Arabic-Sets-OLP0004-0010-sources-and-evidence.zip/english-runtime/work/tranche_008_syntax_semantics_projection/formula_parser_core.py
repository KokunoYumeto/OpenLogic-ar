#!/usr/bin/env python3
"""Fail-closed parser and deterministic projection builder for OLAB-TR-005.

The implementation is deliberately content-bounded.  It replays the frozen
complete-book profile, selects only the fourteen source instances certified by
the Size-of-Sets oracle, and parses that projected stream against explicit macro and
environment contracts.  The immutable Open Logic checkout is read-only.
"""

from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import importlib.util
import json
import re
import sys
from collections import Counter
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
DEFAULT_OUTPUT = PROJECT / "evidence" / "tranche_005_size_of_sets_projection"
COLD_ROOT = HERE / "cold_replay"
ORACLE = PROJECT / "evidence" / "tranche_005_size_of_sets_oracle"
SIDECAR_ROOT = PROJECT / "evidence" / "source_anomaly_resolution"
SETS_FINAL_QA = PROJECT / "evidence" / "independent_tranche_002_sets_final_qa"
CENSUS_BUILDER = PROJECT / "work" / "complete_census" / "build_complete_census.py"
AUTHORITY_ROOT = Path(
    r"upstream-source"
)

TRANCHE_ID = "OLAB-TR-005"
CHAPTER_KEY = "sfr:siz"
PINNED_COMMIT = "9620cc73f9c8e0ad003c514a5d3748f29611c4c0"
EXPECTED_ORACLE_MANIFEST_SHA256 = "f8519c44ed8bd84fdb833599ca5449876dd5f948c7bd17eba9653b4b9fea2087"
EXPECTED_ORACLE_VALIDATION_SHA256 = "b6cd3df655f982746e32e9e5f47251369b2ceb184d11c75efba0a9c7c0a07758"
EXPECTED_CENSUS_BUILDER_SHA256 = "f526d25c872ef09b3be7d15317d5a8c64436552c7e3ed6553c4f2116205b6bc5"
EXPECTED_SIDECAR_SHA256 = "cea56b20572a47ed2880c143fd5817a202e3f55b2e9aa117c7259255f03ae857"
EXPECTED_SETS_FINAL_HOLD_SHA256 = "95bf1e84002bdac05ebe2472b0b1cce7b94be2b14ef4bee1f0f0739c13d9f9aa"
EXPECTED_SETS_STATIC_QA_SHA256 = "e0c66c4429bee279be26e788ea1b6bef5ff96c216c6ed7e9e3ea1cf30c7a58fa"

EXPECTED_SOURCE_INSTANCES = tuple(f"inst-{number:05d}" for number in range(27, 41))
EXPECTED_COUNTS = {
    "source_instances": 14,
    "source_files": 14,
    "projected_macro_families_closed": 50,
    "projected_macro_calls_closed": 1117,
    "projected_environment_families_closed": 3,
    "projected_environment_instances_closed": 18,
    "environments": 137,
    "formulas": 1082,
    "expression_shapes": 398,
    "formal_objects": 73,
    "diagrams": 0,
    "references": 42,
    "labels": 34,
}


class ProjectionError(RuntimeError):
    """A fail-closed projection error."""


def require(condition: bool, detail: str) -> None:
    if not condition:
        raise ProjectionError(detail)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_text(value: str) -> str:
    return sha256_bytes(value.encode("utf-8"))


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n"


def compact_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8", newline="\n")


def write_json(path: Path, value: Any) -> None:
    write_text(path, canonical_json(value))


def write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    write_text(path, "".join(compact_json(dict(row)) + "\n" for row in rows))


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def assert_file_hash(path: Path, expected: str, label: str) -> None:
    require(path.is_file(), f"missing {label}: {path}")
    actual = sha256_file(path)
    require(actual == expected, f"{label} hash drift: expected {expected}, got {actual}")


def require_unique(rows: Sequence[Mapping[str, Any]], field: str, label: str) -> None:
    values = [row.get(field) for row in rows]
    require(None not in values, f"{label} has a row without {field}")
    duplicates = sorted(value for value, count in Counter(values).items() if count > 1)
    require(not duplicates, f"duplicate {label} {field}: {duplicates[:5]}")


def reconcile_exact(
    parsed: Sequence[Mapping[str, Any]],
    oracle: Sequence[Mapping[str, Any]],
    fields: Sequence[str],
    label: str,
) -> None:
    require(len(parsed) == len(oracle), f"{label} count drift: parsed {len(parsed)}, oracle {len(oracle)}")
    for ordinal, (actual, expected) in enumerate(zip(parsed, oracle), 1):
        for field in fields:
            require(
                actual.get(field) == expected.get(field),
                f"{label} #{ordinal} {field} drift: parsed {actual.get(field)!r}, oracle {expected.get(field)!r}",
            )


def safe_output(path: Path) -> Path:
    resolved = path.resolve()
    default = DEFAULT_OUTPUT.resolve()
    cold = COLD_ROOT.resolve()
    allowed = resolved == default or (resolved != cold and resolved.is_relative_to(cold))
    require(allowed, f"refusing output outside isolated Size-of-Sets projection paths: {resolved}")
    return resolved


def load_census_module() -> Any:
    assert_file_hash(CENSUS_BUILDER, EXPECTED_CENSUS_BUILDER_SHA256, "complete-census builder")
    spec = importlib.util.spec_from_file_location("size_of_sets_frozen_complete_census", CENSUS_BUILDER)
    require(spec is not None and spec.loader is not None, "cannot load frozen complete-census builder")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def verify_oracle() -> dict[str, Any]:
    manifest_path = ORACLE / "EVIDENCE_MANIFEST.json"
    assert_file_hash(manifest_path, EXPECTED_ORACLE_MANIFEST_SHA256, "Size-of-Sets oracle evidence manifest")
    assert_file_hash(ORACLE / "VALIDATION_RECEIPT.json", EXPECTED_ORACLE_VALIDATION_SHA256, "Size-of-Sets oracle validation")
    manifest = read_json(manifest_path)
    require(manifest["result"] == "PASS", "Size-of-Sets oracle is not PASS")
    require(manifest["authority_commit"] == PINNED_COMMIT, "Size-of-Sets oracle commit drift")
    require(manifest["tranche_id"] == TRANCHE_ID, "Size-of-Sets oracle tranche drift")
    require(len(manifest["artifacts"]) == manifest["artifact_count"] == 26, "Size-of-Sets oracle manifest count drift")
    for record in manifest["artifacts"]:
        path = ORACLE / record["path"]
        assert_file_hash(path, record["sha256"], f"oracle artifact {record['path']}")
        require(path.stat().st_size == int(record["bytes"]), f"oracle artifact byte drift: {record['path']}")
    boundary = read_json(ORACLE / "SOURCE_BOUNDARY.json")
    require(boundary["result"] == "PASS_SOURCE_CLOSED_REFERENCE_FAIL_CLOSED" and boundary["source_closed"], "source boundary is open")
    require(len(boundary["hard_source_blockers"]) == 1 and boundary["hard_source_blockers"][0]["kind"] == "duplicate_label", "oracle did not preserve the duplicate-label blocker")
    require(boundary["sidecar_boundary"]["relevant_interventions"] == ["SAR-003"], "SAR-003 intersection drift")
    require(boundary["sidecar_boundary"]["relevant_reference_rules"] == ["REFRULE-002"], "REFRULE-002 intersection drift")
    assert_file_hash(SIDECAR_ROOT / "PROJECTION_SIDECAR.json", EXPECTED_SIDECAR_SHA256, "projection sidecar")
    assert_file_hash(SETS_FINAL_QA / "SUPERSEDING_UX_FINDING.json", EXPECTED_SETS_FINAL_HOLD_SHA256, "Sets final-freeze hold")
    assert_file_hash(SETS_FINAL_QA / "STATIC_QA_RECEIPT.json", EXPECTED_SETS_STATIC_QA_SHA256, "Sets static QA receipt")
    hold = read_json(SETS_FINAL_QA / "SUPERSEDING_UX_FINDING.json")
    require(hold["final_freeze_status"] == "HELD", "Sets final-freeze state changed; reassess reader boundary")
    return manifest


def macro_contract(
    required: int,
    optional: int,
    domain: str,
    role: str,
    *,
    expansion: str | None = None,
    formerly_unsupported: bool = False,
    allow_unbraced_arguments: bool = False,
) -> dict[str, Any]:
    return {
        "required_arguments": required,
        "maximum_optional_arguments": optional,
        "domain": domain,
        "projection_role": role,
        "canonical_expansion": expansion,
        "allow_unbraced_arguments": allow_unbraced_arguments,
        "formerly_unsupported_by_nd_contract": formerly_unsupported,
        "status": "CLOSED_BY_GENERALIZED_PARSER" if formerly_unsupported else "CLOSED_EXISTING_CORE",
    }


# Every named macro in the projected fourteen-file stream is explicit.  The 50
# formerly unsupported projected families are marked so closure can be audited
# independently of the already-supported core.
MACRO_CONTRACTS: dict[str, dict[str, Any]] = {
    "@": macro_contract(0, 0, "document", "sentence_spacing_control", formerly_unsupported=True),
    "Bin": macro_contract(0, 0, "math", "named_set", expansion=r"\mathbb{B}", formerly_unsupported=True),
    "Id": macro_contract(1, 0, "math", "identity_function", expansion=r"\mathrm{Id}_{#1}", formerly_unsupported=True),
    "Int": macro_contract(0, 0, "math", "named_set", expansion=r"\mathbb{Z}", formerly_unsupported=True),
    "Nat": macro_contract(0, 0, "math", "named_set", expansion=r"\mathbb{N}", formerly_unsupported=True),
    "OLEndChapterHook": macro_contract(0, 0, "document", "chapter_end_hook"),
    "PosInt": macro_contract(0, 0, "math", "named_set", expansion=r"\mathbb{Z}^{+}", formerly_unsupported=True),
    "Pow": macro_contract(1, 0, "math", "power_set", expansion=r"\wp(#1)", formerly_unsupported=True),
    "Rat": macro_contract(0, 0, "math", "named_set", expansion=r"\mathbb{Q}", formerly_unsupported=True),
    "Real": macro_contract(0, 0, "math", "named_set", expansion=r"\mathbb{R}", formerly_unsupported=True),
    "S": macro_contract(0, 0, "document", "section_symbol", expansion="§", formerly_unsupported=True),
    "Setabs": macro_contract(2, 0, "math", "set_builder", expansion=r"\{ #1 : #2 \}", formerly_unsupported=True),
    "begin": macro_contract(1, 0, "document", "environment_open"),
    "big": macro_contract(0, 0, "math", "delimiter_size", formerly_unsupported=True),
    "bigcup": macro_contract(0, 0, "math", "large_union", expansion="⋃", formerly_unsupported=True),
    "cap": macro_contract(0, 0, "math", "intersection", expansion="∩", formerly_unsupported=True),
    "cardeq": macro_contract(2, 0, "math", "equinumerosity", expansion=r"#1 \approx #2", formerly_unsupported=True),
    "cardle": macro_contract(2, 0, "math", "cardinality_no_larger", expansion=r"#1 \preceq #2", formerly_unsupported=True),
    "cardless": macro_contract(2, 0, "math", "cardinality_smaller", expansion=r"#1 \prec #2", formerly_unsupported=True),
    "cardneq": macro_contract(2, 0, "math", "not_equinumerous", expansion=r"#1 \not\approx #2", formerly_unsupported=True),
    "cdot": macro_contract(0, 0, "math", "multiplication_dot", expansion="·", formerly_unsupported=True),
    "citep": macro_contract(1, 2, "document", "parenthetical_citation", formerly_unsupported=True),
    "citet": macro_contract(1, 2, "document", "textual_citation", formerly_unsupported=True),
    "colon": macro_contract(0, 0, "math", "mapping_colon", expansion=":", formerly_unsupported=True),
    "comp": macro_contract(2, 0, "math", "function_composition", expansion=r"#2 \circ #1", formerly_unsupported=True),
    "cref": macro_contract(1, 0, "document", "clever_cross_reference", formerly_unsupported=True),
    "cup": macro_contract(0, 0, "math", "union", expansion="∪"),
    "ddots": macro_contract(0, 0, "math", "diagonal_ellipsis", expansion="⋱", formerly_unsupported=True),
    "dots": macro_contract(0, 0, "math", "ellipsis"),
    "emph": macro_contract(1, 0, "document", "emphasis"),
    "emptyset": macro_contract(0, 0, "math", "empty_set", expansion="∅", formerly_unsupported=True),
    "end": macro_contract(1, 0, "document", "environment_close"),
    "footnote": macro_contract(1, 1, "document", "footnote"),
    "frac": macro_contract(2, 0, "math", "fraction", formerly_unsupported=True),
    "hline": macro_contract(0, 0, "math", "array_horizontal_rule", formerly_unsupported=True),
    "in": macro_contract(0, 0, "math", "membership", expansion="∈"),
    "infty": macro_contract(0, 0, "math", "infinity", expansion="∞", formerly_unsupported=True),
    "item": macro_contract(0, 1, "document", "list_item"),
    "label": macro_contract(1, 0, "document", "literal_label_definition"),
    "lceil": macro_contract(0, 0, "math", "left_ceiling", expansion="⌈", formerly_unsupported=True),
    "ldots": macro_contract(0, 0, "math", "low_ellipsis"),
    "left": macro_contract(0, 0, "math", "scalable_left_delimiter", formerly_unsupported=True),
    "mathbf": macro_contract(1, 0, "math", "bold_math_identifier", formerly_unsupported=True, allow_unbraced_arguments=True),
    "neq": macro_contract(0, 0, "math", "not_equal", expansion="≠", formerly_unsupported=True),
    "noindent": macro_contract(0, 0, "document", "paragraph_noindent", formerly_unsupported=True),
    "notin": macro_contract(0, 0, "math", "nonmembership", expansion="∉", formerly_unsupported=True),
    "olchapter": macro_contract(3, 0, "document", "chapter_heading"),
    "olfileid": macro_contract(3, 0, "document", "file_identity"),
    "ollabel": macro_contract(1, 0, "document", "label_definition"),
    "olref": macro_contract(1, 3, "document", "cross_reference"),
    "olsection": macro_contract(1, 0, "document", "section_heading"),
    "omega": macro_contract(0, 0, "math", "lowercase_omega", expansion="ω", formerly_unsupported=True),
    "overline": macro_contract(1, 0, "math", "overline", formerly_unsupported=True),
    "phantom": macro_contract(1, 0, "math", "invisible_spacing_copy", formerly_unsupported=True),
    "printtoken": macro_contract(2, 0, "document", "formatted_vocabulary_token", formerly_unsupported=True),
    "rceil": macro_contract(0, 0, "math", "right_ceiling", expansion="⌉", formerly_unsupported=True),
    "right": macro_contract(0, 0, "math", "scalable_right_delimiter", formerly_unsupported=True),
    "setminus": macro_contract(0, 0, "math", "set_difference", expansion="∖", formerly_unsupported=True),
    "small": macro_contract(0, 0, "document", "small_text_switch", formerly_unsupported=True),
    "subseteq": macro_contract(0, 0, "math", "subset_or_equal", expansion="⊆"),
    "text": macro_contract(1, 0, "math", "embedded_text", formerly_unsupported=True),
    "tfrac": macro_contract(2, 0, "math", "text_style_fraction", formerly_unsupported=True),
    "times": macro_contract(0, 0, "math", "cartesian_product", expansion="×", formerly_unsupported=True),
    "to": macro_contract(0, 0, "math", "function_arrow", expansion="→", formerly_unsupported=True),
    "tuple": macro_contract(1, 0, "math", "tuple", expansion="⟨#1⟩", formerly_unsupported=True),
    "underbrace": macro_contract(1, 0, "math", "underbrace", formerly_unsupported=True),
    "usetoken": macro_contract(2, 0, "document", "vocabulary_token", formerly_unsupported=False),
    "vdots": macro_contract(0, 0, "math", "vertical_ellipsis", expansion="⋮", formerly_unsupported=True),
}


def environment_contract(role: str, object_class: str, *, formerly_unsupported: bool = False, **extra: Any) -> dict[str, Any]:
    return {
        "projection_role": role,
        "object_class": object_class,
        "formerly_unsupported_by_nd_contract": formerly_unsupported,
        "status": "CLOSED_BY_GENERALIZED_PARSER" if formerly_unsupported else "CLOSED_EXISTING_CORE",
        **extra,
    }


ENVIRONMENT_CONTRACTS: dict[str, dict[str, Any]] = {
    "align*": environment_contract("aligned_display_math", "display_math", top_level_formula=True),
    "array": environment_contract(
        "math_table", "other", formerly_unsupported=True, nested_math=True, required_preamble_arguments=1
    ),
    "cases": environment_contract("piecewise_cases", "other", formerly_unsupported=True, nested_math=True),
    "cor": environment_contract("corollary", "corollary", optional_title=True),
    "defn": environment_contract("definition", "definition", optional_title=True),
    "editorial": environment_contract("editorial_note", "other"),
    "enumerate": environment_contract("ordered_list", "other"),
    "ex": environment_contract("example", "example", optional_title=True),
    "explain": environment_contract("explanatory_block", "other"),
    "prob": environment_contract("exercise", "exercise", optional_title=True),
    "proof": environment_contract("proof", "other", optional_title=True),
    "prop": environment_contract("proposition", "proposition", optional_title=True),
    "quote": environment_contract("block_quotation", "other", formerly_unsupported=True),
    "thm": environment_contract("theorem", "theorem", optional_title=True),
}

FORMERLY_UNSUPPORTED_MACROS = frozenset(name for name, row in MACRO_CONTRACTS.items() if row["formerly_unsupported_by_nd_contract"])
FORMERLY_UNSUPPORTED_ENVIRONMENTS = frozenset(
    name for name, row in ENVIRONMENT_CONTRACTS.items() if row["formerly_unsupported_by_nd_contract"]
)
SOURCE_STAGE_ONLY_CONSTRUCTS = frozenset({"oliflabeldef", "olimport", "tagblock"})
ALLOWED_CONTROL_SYMBOLS = frozenset({"{", "}", "\\", "[", "]", "(", ")", ",", ";", "!", ":", " "})


@dataclass(frozen=True)
class ProjectionSegment:
    segment_id: str
    instance_id: str
    file: str
    source_start: int
    source_end: int
    global_start: int
    global_end: int
    local_start: int
    local_end: int
    text: str
    source: Any


class CandidateProjection:
    def __init__(self, segments: Sequence[ProjectionSegment]):
        require(segments, "candidate projection has no segments")
        self.segments = list(segments)
        self.text = "".join(segment.text for segment in segments)
        self._local_starts = [segment.local_start for segment in segments]

    def segment_at(self, local_offset: int) -> ProjectionSegment:
        require(0 <= local_offset < len(self.text), f"candidate local offset outside projection: {local_offset}")
        index = bisect.bisect_right(self._local_starts, local_offset) - 1
        segment = self.segments[index]
        require(local_offset < segment.local_end, f"candidate source-map gap at local offset {local_offset}")
        return segment

    def origin(self, local_offset: int) -> tuple[Any, int, str]:
        segment = self.segment_at(local_offset)
        return segment.source, segment.source_start + local_offset - segment.local_start, segment.instance_id

    def global_offset(self, local_offset: int) -> int:
        segment = self.segment_at(local_offset)
        return segment.global_start + local_offset - segment.local_start

    def global_end(self, local_end: int) -> int:
        require(local_end > 0, "cannot map empty end coordinate")
        return self.global_offset(local_end - 1) + 1


def build_candidate_projection(module: Any) -> tuple[CandidateProjection, Any, list[dict[str, Any]]]:
    require(AUTHORITY_ROOT.is_dir(), f"authority root missing: {AUTHORITY_ROOT}")
    require(module.read_head_without_git(AUTHORITY_ROOT) == PINNED_COMMIT, "immutable authority commit drift")
    profile = read_json(ORACLE / "PROFILE_ORACLE.json")
    instance_oracle = read_jsonl(ORACLE / "source_instances.jsonl")
    candidate_ids = set(EXPECTED_SOURCE_INSTANCES)
    require(tuple(row["instance_id"] for row in instance_oracle) == EXPECTED_SOURCE_INSTANCES, "instance order drift")

    graph = module.SourceGraph(AUTHORITY_ROOT)
    graph.load(module.ENTRY)
    initial_tags, _mutations = module.parse_tag_values(AUTHORITY_ROOT)
    require(initial_tags == profile["initial_tags"], "initial tag profile drift")
    replay = module.Projection(graph, initial_tags)
    replay.execute_about()
    replay.execute_entry()
    preliminary = module.macro_records(
        replay.projected.text, replay.projected.origin, module.WANTED_MACROS, "size-of-sets-pre-label-selection"
    )
    complete_labels = {row["full_key"] for row in module.label_definition_records(preliminary)}
    resolved, label_decisions = module.resolve_label_conditionals(replay.projected, complete_labels)
    oracle_decisions = read_jsonl(ORACLE / "tag_decisions.jsonl")
    replay_label_decisions = [row for row in label_decisions if row["instance_id"] in candidate_ids]
    require(len(replay_label_decisions) == 8, "label-conditional replay count drift")
    require(Counter(row["kind"] for row in oracle_decisions) == {"oliflabeldef": 8}, "decision oracle drift")

    segments: list[ProjectionSegment] = []
    local_cursor = 0
    for global_start, chunk in zip(resolved.starts, resolved.chunks):
        if chunk.instance_id not in candidate_ids:
            continue
        text = chunk.text
        segment = ProjectionSegment(
            segment_id=f"size-of-sets-segment-{len(segments)+1:04d}",
            instance_id=chunk.instance_id,
            file=chunk.source.relpath,
            source_start=chunk.source_start,
            source_end=chunk.source_start + len(text),
            global_start=global_start,
            global_end=global_start + len(text),
            local_start=local_cursor,
            local_end=local_cursor + len(text),
            text=text,
            source=chunk.source,
        )
        segments.append(segment)
        local_cursor += len(text)
    projection = CandidateProjection(segments)
    require({segment.instance_id for segment in segments} == candidate_ids, "candidate projection instance loss")
    require(not any("\\" + name in projection.text for name in SOURCE_STAGE_ONLY_CONSTRUCTS), "selection/import residue")
    return projection, graph, replay.instances


def control_sequence_at(text: str, offset: int) -> tuple[str, int, bool] | None:
    if offset >= len(text) or text[offset] != "\\":
        return None
    if offset + 1 >= len(text):
        return ("", offset + 1, False)
    if text[offset + 1].isalpha() or text[offset + 1] == "@":
        end = offset + 2
        while end < len(text) and (text[end].isalpha() or text[end] == "@"):
            end += 1
        return text[offset + 1 : end], end, True
    return text[offset + 1], offset + 2, False


def is_escaped(text: str, offset: int) -> bool:
    backslashes = 0
    cursor = offset - 1
    while cursor >= 0 and text[cursor] == "\\":
        backslashes += 1
        cursor -= 1
    return backslashes % 2 == 1


def skip_space(text: str, offset: int) -> int:
    while offset < len(text) and text[offset].isspace():
        offset += 1
    return offset


def parse_balanced(text: str, offset: int, opener: str = "{") -> tuple[int, int, int, str]:
    closer = {"{": "}", "[": "]"}[opener]
    start = skip_space(text, offset)
    require(start < len(text) and text[start] == opener, f"expected {opener!r} at offset {start}")
    depth = 1
    cursor = start + 1
    while cursor < len(text):
        char = text[cursor]
        if char == "\\":
            command = control_sequence_at(text, cursor)
            cursor = command[1] if command else cursor + 1
            continue
        if char == opener:
            depth += 1
        elif char == closer:
            depth -= 1
            if depth == 0:
                return start, cursor + 1, cursor + 1, text[start + 1 : cursor]
        cursor += 1
    raise ProjectionError(f"unclosed {opener!r} group starting at offset {start}")


def parse_macro_invocation(text: str, offset: int) -> dict[str, Any]:
    command = control_sequence_at(text, offset)
    require(command is not None and command[2], f"expected named macro at offset {offset}")
    name, after, _is_word = command
    require(name in MACRO_CONTRACTS, f"uncontracted named macro \\{name} at offset {offset}")
    contract = MACRO_CONTRACTS[name]
    cursor = after
    options: list[str] = []
    for _ in range(int(contract["maximum_optional_arguments"])):
        probe = skip_space(text, cursor)
        if probe >= len(text) or text[probe] != "[":
            break
        _start, _end, cursor, value = parse_balanced(text, probe, "[")
        options.append(value)
    arguments: list[str] = []
    for _ in range(int(contract["required_arguments"])):
        probe = skip_space(text, cursor)
        if probe < len(text) and text[probe] == "{":
            _start, _end, cursor, value = parse_balanced(text, probe, "{")
        else:
            require(contract["allow_unbraced_arguments"], f"expected braced argument for \\{name} at offset {probe}")
            require(probe < len(text), f"missing unbraced argument for \\{name}")
            if text[probe] == "\\":
                nested = control_sequence_at(text, probe)
                require(nested is not None, f"bad unbraced control sequence argument for \\{name}")
                cursor = nested[1]
            else:
                cursor = probe + 1
            value = text[probe:cursor]
        arguments.append(value)
    if name in {"begin", "end"}:
        require(arguments[0] in ENVIRONMENT_CONTRACTS, f"uncontracted environment {arguments[0]!r}")
    return {
        "name": name,
        "start": offset,
        "end": cursor,
        "options": options,
        "arguments": arguments,
        "contract": contract,
    }


def scan_macro_occurrences(text: str, projection: CandidateProjection) -> tuple[list[dict[str, Any]], Counter[str], Counter[str]]:
    rows: list[dict[str, Any]] = []
    named: Counter[str] = Counter()
    symbols: Counter[str] = Counter()
    cursor = 0
    while cursor < len(text):
        command = control_sequence_at(text, cursor)
        if command is None:
            cursor += 1
            continue
        name, after, is_word = command
        if not is_word:
            symbols[name] += 1
            cursor = after
            continue
        invocation = parse_macro_invocation(text, cursor)
        named[name] += 1
        source, source_offset, instance_id = projection.origin(cursor)
        row = {
            "macro_occurrence_id": f"size-of-sets-macro-{len(rows)+1:05d}",
            "name": name,
            "instance_id": instance_id,
            **source.location(source_offset),
            "local_start": cursor,
            "local_end": invocation["end"],
            "global_start": projection.global_offset(cursor),
            "global_end": projection.global_end(invocation["end"]),
            "arguments": invocation["arguments"],
            "options": invocation["options"],
            "projection_role": invocation["contract"]["projection_role"],
            "formerly_unsupported_by_nd_contract": invocation["contract"]["formerly_unsupported_by_nd_contract"],
            "invocation_sha256": sha256_text(text[cursor : invocation["end"]]),
        }
        rows.append(row)
        cursor = after  # Nested macros inside arguments must also be inventoried.
    return rows, named, symbols


def scan_environments(text: str, projection: CandidateProjection) -> list[dict[str, Any]]:
    pattern = re.compile(r"\\(begin|end)\{([A-Za-z@*_-]+)\}")
    stack: list[dict[str, Any]] = []
    closed: list[dict[str, Any]] = []
    for match in pattern.finditer(text):
        kind, name = match.group(1), match.group(2)
        require(name in ENVIRONMENT_CONTRACTS, f"uncontracted environment {name!r} at local offset {match.start()}")
        if kind == "begin":
            header_end = match.end()
            title: str | None = None
            preamble: list[str] = []
            probe = skip_space(text, header_end)
            contract = ENVIRONMENT_CONTRACTS[name]
            if contract.get("optional_title") and probe < len(text) and text[probe] == "[":
                _start, _end, header_end, title = parse_balanced(text, probe, "[")
            for _ in range(int(contract.get("required_preamble_arguments", 0))):
                _start, _end, header_end, value = parse_balanced(text, header_end, "{")
                preamble.append(value)
            stack.append(
                {
                    "name": name,
                    "local_start": match.start(),
                    "open_end": match.end(),
                    "header_end": header_end,
                    "title_tex": title,
                    "preamble": preamble,
                }
            )
            continue
        require(stack, f"orphan environment end {name!r} at local offset {match.start()}")
        opened = stack.pop()
        require(opened["name"] == name, f"environment mismatch: opened {opened['name']!r}, closed {name!r}")
        source, source_offset, instance_id = projection.origin(opened["local_start"])
        global_start = projection.global_offset(opened["local_start"])
        global_end = projection.global_end(match.end())
        closed.append(
            {
                **opened,
                "local_end": match.end(),
                "close_start": match.start(),
                "global_start": global_start,
                "global_end": global_end,
                "instance_id": instance_id,
                **source.location(source_offset),
                "projection_role": ENVIRONMENT_CONTRACTS[name]["projection_role"],
                "object_class": ENVIRONMENT_CONTRACTS[name]["object_class"],
                "formerly_unsupported_by_nd_contract": ENVIRONMENT_CONTRACTS[name][
                    "formerly_unsupported_by_nd_contract"
                ],
                "content_sha256": sha256_text(text[opened["open_end"] : match.start()]),
                "semantic_content_sha256": sha256_text(text[opened["header_end"] : match.start()]),
            }
        )
    require(not stack, f"unclosed environment(s): {[row['name'] for row in stack]}")
    closed.sort(key=lambda row: (int(row["local_start"]), -int(row["local_end"])))
    return closed


def scan_formulas(
    text: str, projection: CandidateProjection, environments: Sequence[Mapping[str, Any]]
) -> list[dict[str, Any]]:
    math_starts = {
        int(row["local_start"]): row
        for row in environments
        if ENVIRONMENT_CONTRACTS[row["name"]].get("top_level_formula")
    }
    rows: list[dict[str, Any]] = []

    def add(delimiter: str, start: int, content_start: int, content_end: int, end: int) -> None:
        tex = text[content_start:content_end]
        normalized = " ".join(tex.split())
        require(normalized, f"empty formula at local offset {start}")
        source, source_offset, instance_id = projection.origin(start)
        end_source, _end_offset, end_instance = projection.origin(end - 1)
        require(source.relpath == end_source.relpath and instance_id == end_instance, "formula crosses a source boundary")
        rows.append(
            {
                "delimiter": delimiter,
                "tex": tex,
                "normalized_tex": normalized,
                "expression_id": "expr-" + sha256_text(normalized)[:16],
                "instance_id": instance_id,
                **source.location(source_offset),
                "local_start": start,
                "local_end": end,
                "global_start": projection.global_offset(start),
                "global_end": projection.global_end(end),
            }
        )

    cursor = 0
    while cursor < len(text):
        if cursor in math_starts:
            env = math_starts[cursor]
            add(env["name"], cursor, int(env["open_end"]), int(env["close_start"]), int(env["local_end"]))
            cursor = int(env["local_end"])
            continue
        if text[cursor] == "$" and not is_escaped(text, cursor):
            marker = "$$" if text.startswith("$$", cursor) else "$"
            content_start = cursor + len(marker)
            close = content_start
            while close < len(text) and (not text.startswith(marker, close) or is_escaped(text, close)):
                close += 1
            require(close < len(text), f"unclosed {marker} formula at local offset {cursor}")
            add(marker, cursor, content_start, close, close + len(marker))
            cursor = close + len(marker)
            continue
        if text.startswith(r"\[", cursor) and not is_escaped(text, cursor):
            close = cursor + 2
            while close < len(text) and (not text.startswith(r"\]", close) or is_escaped(text, close)):
                close += 1
            require(close < len(text), f"unclosed \\[ formula at local offset {cursor}")
            add(r"\[...\]", cursor, cursor + 2, close, close + 2)
            cursor = close + 2
            continue
        if text.startswith(r"\(", cursor) and not is_escaped(text, cursor):
            close = cursor + 2
            while close < len(text) and (not text.startswith(r"\)", close) or is_escaped(text, close)):
                close += 1
            require(close < len(text), f"unclosed \\( formula at local offset {cursor}")
            add(r"\(...\)", cursor, cursor + 2, close, close + 2)
            cursor = close + 2
            continue
        command = control_sequence_at(text, cursor)
        cursor = command[1] if command is not None else cursor + 1
    return rows


class FormulaParser:
    """Small lossless-enough TeX AST parser for the explicitly contracted subset."""

    def __init__(self, text: str):
        self.text = text
        self.length = len(text)

    def parse(self) -> list[dict[str, Any]]:
        nodes, cursor = self._sequence(0, stop_char=None, stop_environment=None)
        require(cursor == self.length, f"formula parser stopped at {cursor} of {self.length}")
        return nodes

    def _sequence(
        self, cursor: int, *, stop_char: str | None, stop_environment: str | None
    ) -> tuple[list[dict[str, Any]], int]:
        nodes: list[dict[str, Any]] = []
        while cursor < self.length:
            if stop_char and self.text[cursor] == stop_char:
                return nodes, cursor + 1
            if self.text[cursor] == "}":
                raise ProjectionError(f"orphan closing brace in formula at offset {cursor}")
            if self.text.startswith(r"\end", cursor):
                invocation = parse_macro_invocation(self.text, cursor)
                name = invocation["arguments"][0]
                if stop_environment == name:
                    return nodes, invocation["end"]
                raise ProjectionError(f"orphan or mismatched \\end{{{name}}} in formula at offset {cursor}")
            char = self.text[cursor]
            if char == "{":
                children, cursor = self._sequence(cursor + 1, stop_char="}", stop_environment=None)
                nodes.append({"type": "group", "children": children})
                continue
            if char == "\\":
                command = control_sequence_at(self.text, cursor)
                require(command is not None, f"bad control sequence at formula offset {cursor}")
                name, after, is_word = command
                if not is_word:
                    require(name in ALLOWED_CONTROL_SYMBOLS, f"uncontracted control symbol \\{name}")
                    nodes.append({"type": "row_break" if name == "\\" else "control_symbol", "value": name})
                    cursor = after
                    continue
                if name == "begin":
                    invocation = parse_macro_invocation(self.text, cursor)
                    environment = invocation["arguments"][0]
                    contract = ENVIRONMENT_CONTRACTS[environment]
                    header_cursor = invocation["end"]
                    preamble: list[str] = []
                    for _ in range(int(contract.get("required_preamble_arguments", 0))):
                        _start, _end, header_cursor, value = parse_balanced(self.text, header_cursor, "{")
                        preamble.append(value)
                    children, cursor = self._sequence(
                        header_cursor, stop_char=None, stop_environment=environment
                    )
                    nodes.append(
                        {
                            "type": "environment",
                            "name": environment,
                            "role": contract["projection_role"],
                            "preamble": preamble,
                            "children": children,
                        }
                    )
                    continue
                invocation = parse_macro_invocation(self.text, cursor)
                arguments = []
                # Reparse the argument payloads as formula/text token trees.
                for value in invocation["arguments"]:
                    arguments.append(FormulaParser(value).parse())
                nodes.append(
                    {
                        "type": "macro",
                        "name": name,
                        "role": invocation["contract"]["projection_role"],
                        "options": invocation["options"],
                        "arguments": arguments,
                    }
                )
                cursor = invocation["end"]
                continue
            if char in {"^", "_"}:
                script_kind = "superscript" if char == "^" else "subscript"
                cursor = skip_space(self.text, cursor + 1)
                require(cursor < self.length, f"{script_kind} has no argument")
                if self.text[cursor] == "{":
                    children, cursor = self._sequence(cursor + 1, stop_char="}", stop_environment=None)
                    argument: dict[str, Any] = {"type": "group", "children": children}
                elif self.text[cursor] == "\\":
                    command = control_sequence_at(self.text, cursor)
                    require(command is not None, f"bad script control sequence at offset {cursor}")
                    name, after, is_word = command
                    if is_word:
                        require(name not in {"begin", "end"}, "environment boundary cannot be an unbraced script")
                        invocation = parse_macro_invocation(self.text, cursor)
                        argument = {
                            "type": "macro",
                            "name": name,
                            "role": invocation["contract"]["projection_role"],
                            "options": invocation["options"],
                            "arguments": [FormulaParser(value).parse() for value in invocation["arguments"]],
                        }
                        cursor = invocation["end"]
                    else:
                        require(name in ALLOWED_CONTROL_SYMBOLS, f"uncontracted script control symbol \\{name}")
                        argument = {"type": "control_symbol", "value": name}
                        cursor = after
                else:
                    argument = {"type": "text", "value": self.text[cursor]}
                    cursor += 1
                nodes.append({"type": "script", "kind": script_kind, "argument": argument})
                continue
            if char == "&":
                nodes.append({"type": "alignment_separator"})
                cursor += 1
                continue
            start = cursor
            while cursor < self.length and self.text[cursor] not in "{}\\^_&":
                if stop_char and self.text[cursor] == stop_char:
                    break
                cursor += 1
            require(cursor > start, f"formula parser made no progress at offset {cursor}")
            value = self.text[start:cursor]
            nodes.append({"type": "text", "value": value})
        require(stop_char is None, f"unclosed formula group expecting {stop_char!r}")
        require(stop_environment is None, f"unclosed formula environment {stop_environment!r}")
        return nodes, cursor


def parse_formula_ast(text: str) -> list[dict[str, Any]]:
    return FormulaParser(text).parse()


def mask_comments(text: str) -> str:
    chars = list(text)
    cursor = 0
    while cursor < len(chars):
        if chars[cursor] == "%" and not is_escaped(text, cursor):
            end = text.find("\n", cursor)
            if end < 0:
                end = len(chars)
            for index in range(cursor, end):
                chars[index] = " "
            cursor = end
        else:
            cursor += 1
    return "".join(chars)


def split_options(value: str) -> dict[str, str | bool]:
    parts: list[str] = []
    depth = 0
    start = 0
    for index, char in enumerate(value):
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
        elif char == "," and depth == 0:
            parts.append(value[start:index].strip())
            start = index + 1
    parts.append(value[start:].strip())
    result: dict[str, str | bool] = {}
    for part in parts:
        if not part:
            continue
        if "=" in part:
            key, item = part.split("=", 1)
            result[key.strip()] = item.strip()
        else:
            result[part] = True
    return result


def parse_relation_tikz(text: str, diagram_id: str) -> dict[str, Any]:
    """Parse the three inline relation diagrams into a closed graph model.

    The source uses two ordinary directed graphs and one compact TikZ tree.
    We retain exact source hashes, explicit vertex labels, and a complete edge
    list/parent-child list so no diagram-only information is lost.
    """
    masked = mask_comments(text)
    named = Counter(match.group(1) for match in re.finditer(r"\\([A-Za-z@]+)", masked))
    unknown = sorted(set(named) - {"begin", "end", "node", "draw"})
    require(not unknown, f"{diagram_id}: uncontracted TikZ commands {unknown}")
    picture_open = re.search(r"\\begin\{tikzpicture\}", masked)
    picture_close = re.search(r"\\end\{tikzpicture\}", masked)
    require(picture_open is not None and picture_close is not None, f"{diagram_id}: missing tikzpicture boundary")
    require(picture_open.start() < picture_close.start(), f"{diagram_id}: reversed tikzpicture boundary")
    option_probe = skip_space(masked, picture_open.end())
    picture_options: dict[str, str | bool] = {}
    if option_probe < len(masked) and masked[option_probe] == "[":
        _start, _end, _after, value = parse_balanced(masked, option_probe, "[")
        picture_options = split_options(value)

    environment_pattern = re.compile(r"\\(begin|end)\{tikzpicture\}")
    env_stack: list[str] = []
    for match in environment_pattern.finditer(masked):
        if match.group(1) == "begin":
            env_stack.append("tikzpicture")
        else:
            require(env_stack and env_stack.pop() == "tikzpicture", f"{diagram_id}: TikZ environment mismatch")
    require(not env_stack, f"{diagram_id}: unclosed TikZ environment")

    labels = [
        " ".join(match.group(1).replace("$", "").split())
        for match in re.finditer(r"(?:\\node|(?<!\\)\bnode)\s*(?:\[[^\]]*\]\s*)?(?:\([^)]*\)\s*)?(?:\[[^\]]*\]\s*)?\{([^{}]+)\}", masked)
    ]
    draw_rows: list[dict[str, Any]] = []
    for ordinal, match in enumerate(re.finditer(r"\\draw\s+([^;]+);", masked), 1):
        raw = match.group(0)
        endpoints = re.findall(r"\(([A-Za-z0-9_]+)\)", raw)
        require(len(endpoints) >= 2, f"{diagram_id}: draw #{ordinal} has no endpoint pair")
        draw_rows.append(
            {
                "edge_id": f"{diagram_id}-edge-{ordinal:02d}",
                "source_node": endpoints[0],
                "target_node": endpoints[-1],
                "loop": endpoints[0] == endpoints[-1],
                "raw_sha256": sha256_text(raw),
            }
        )

    if labels == ["1", "2", "3", "4"]:
        require([(row["source_node"], row["target_node"]) for row in draw_rows] == [("A", "A"), ("A", "B"), ("A", "C"), ("B", "C")], f"{diagram_id}: four-vertex graph edge drift")
        kind = "directed_graph"
        relationships = ["1 to 1", "1 to 2", "1 to 3", "2 to 3"]
        isolated = ["4"]
    elif labels == ["1", "2", "3"]:
        require([(row["source_node"], row["target_node"]) for row in draw_rows] == [("A", "A"), ("A", "B"), ("A", "C"), ("B", "C")], f"{diagram_id}: three-vertex graph edge drift")
        kind = "directed_graph"
        relationships = ["1 to 1", "1 to 2", "1 to 3", "2 to 3"]
        isolated = []
    elif labels == ["r", "a", "c", "d", "e", "b"]:
        require(not draw_rows, f"{diagram_id}: tree unexpectedly contains draw commands")
        require(masked.count("child {") == 5, f"{diagram_id}: tree child count drift")
        kind = "rooted_tree"
        relationships = ["r to a", "r to b", "a to c", "a to d", "a to e"]
        isolated = []
    else:
        raise ProjectionError(f"{diagram_id}: unknown inline relation diagram labels {labels!r}")
    return {
        "source_tikz_sha256": sha256_text(text),
        "tikzpicture_options": picture_options,
        "semantic_kind": kind,
        "node_labels_in_source_order": labels,
        "node_count": len(labels),
        "edge_count": len(relationships),
        "relationships": relationships,
        "isolated_node_labels": isolated,
        "draw_edges": draw_rows,
        "parse_status": "PASS_INLINE_TIKZ_STRUCTURE_CLOSED",
    }


def plain_caption(value: str) -> str:
    value = re.sub(r"!!a\{([^{}]+)\}", r"an \1", value)
    value = re.sub(r"!!\{([^{}]+)\}", r"\1", value)
    return " ".join(value.split())


def plain_accessible_title(value: str | None) -> str:
    if not value:
        return ""
    result = value.replace(r"K\H{o}nig", "König")
    result = result.replace(r'Schr\"oder', "Schröder")
    result = re.sub(r"\\(?:emph|textbf|textit)\{([^{}]+)\}", r"\1", result)
    result = re.sub(r"\\[A-Za-z@]+", "", result)
    result = result.replace("{", "").replace("}", "")
    return " ".join(result.split())


def public_environment(row: Mapping[str, Any], oracle_row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "environment_id": oracle_row["environment_id"],
        "name": row["name"],
        "instance_id": row["instance_id"],
        "file": row["file"],
        "line": row["line"],
        "column": row["column"],
        "offset": row["offset"],
        "local_start": row["local_start"],
        "local_end": row["local_end"],
        "global_start": row["global_start"],
        "global_end": row["global_end"],
        "projection_role": row["projection_role"],
        "object_class": row["object_class"],
        "title_tex": row["title_tex"],
        "preamble": row["preamble"],
        "content_sha256": row["content_sha256"],
        "semantic_content_sha256": row["semantic_content_sha256"],
        "formerly_unsupported_by_nd_contract": row["formerly_unsupported_by_nd_contract"],
    }


def build(output_arg: Path) -> dict[str, Any]:
    output = safe_output(output_arg)
    oracle_manifest = verify_oracle()
    module = load_census_module()
    projection, _graph, _instances = build_candidate_projection(module)

    source_authority = read_json(ORACLE / "SOURCE_AUTHORITY.json")
    source_by_path = {row["path"]: row for row in source_authority["source_records"]}
    asset_by_path = {row["path"]: row for row in source_authority["asset_records"]}
    for path, record in {**source_by_path, **asset_by_path}.items():
        assert_file_hash(AUTHORITY_ROOT / path, record["sha256"], f"immutable authority record {path}")

    macro_rows, macro_counts, control_symbols = scan_macro_occurrences(projection.text, projection)
    inventory = read_tsv(ORACLE / "construct_inventory.tsv")
    expected_macro_counts = {
        row["name"]: int(row["projected_count"])
        for row in inventory
        if row["family_type"] == "macro" and int(row["projected_count"]) > 0
    }
    require(dict(sorted(macro_counts.items())) == dict(sorted(expected_macro_counts.items())), "projected macro inventory drift")
    require(set(macro_counts) == set(MACRO_CONTRACTS), "macro contract is not exact for this tranche")

    parsed_environments = scan_environments(projection.text, projection)
    oracle_environments = read_jsonl(ORACLE / "environments.jsonl")
    parsed_environments.sort(key=lambda row: int(row["global_start"]))
    reconcile_exact(
        parsed_environments,
        oracle_environments,
        ("name", "instance_id", "file", "line", "column", "offset"),
        "environment",
    )
    reconcile_exact(
        parsed_environments,
        [
            {**row, "global_start": row["stream_start"], "global_end": row["stream_end"]}
            for row in oracle_environments
        ],
        ("global_start", "global_end"),
        "environment coordinate",
    )
    environment_rows = [public_environment(row, oracle_row) for row, oracle_row in zip(parsed_environments, oracle_environments)]
    environment_by_id = {row["environment_id"]: row for row in environment_rows}

    parsed_formulas = scan_formulas(projection.text, projection, parsed_environments)
    oracle_formulas = read_jsonl(ORACLE / "formula_occurrences.jsonl")
    reconcile_exact(
        parsed_formulas,
        oracle_formulas,
        ("delimiter", "tex", "normalized_tex", "expression_id", "instance_id", "file", "line", "column", "offset"),
        "formula",
    )
    reconcile_exact(
        parsed_formulas,
        [
            {**row, "global_start": row["stream_start"], "global_end": row["stream_end"]}
            for row in oracle_formulas
        ],
        ("global_start", "global_end"),
        "formula coordinate",
    )
    require(len(parsed_formulas) == EXPECTED_COUNTS["formulas"], "formula count is not 1,082")

    shape_oracle = read_tsv(ORACLE / "formula_shapes.tsv")
    shape_counts = Counter(row["expression_id"] for row in parsed_formulas)
    shape_rows: list[dict[str, Any]] = []
    shape_ast_by_id: dict[str, str] = {}
    for row in shape_oracle:
        expression_id = row["expression_id"]
        normalized = row["normalized_tex"]
        require("expr-" + sha256_text(normalized)[:16] == expression_id, f"shape ID mismatch: {expression_id}")
        ast = parse_formula_ast(normalized)
        ast_sha = sha256_text(compact_json(ast))
        shape_ast_by_id[expression_id] = ast_sha
        shape_rows.append(
            {
                "expression_id": expression_id,
                "normalized_tex": normalized,
                "projected_occurrences": shape_counts[expression_id],
                "ast_sha256": ast_sha,
                "ast": ast,
                "parse_status": "PASS_CONTRACT_CLOSED",
            }
        )
    require(len(shape_rows) == EXPECTED_COUNTS["expression_shapes"], "expression shape count is not 398")
    require(set(shape_counts) == set(shape_ast_by_id), "formula/shape binding is not bijectively closed")

    formula_rows: list[dict[str, Any]] = []
    for parsed, oracle_row in zip(parsed_formulas, oracle_formulas):
        formula_rows.append(
            {
                "formula_id": oracle_row["formula_id"],
                "expression_id": parsed["expression_id"],
                "ast_sha256": shape_ast_by_id[parsed["expression_id"]],
                "delimiter": parsed["delimiter"],
                "tex": parsed["tex"],
                "normalized_tex": parsed["normalized_tex"],
                "instance_id": parsed["instance_id"],
                "file": parsed["file"],
                "line": parsed["line"],
                "column": parsed["column"],
                "offset": parsed["offset"],
                "local_start": parsed["local_start"],
                "local_end": parsed["local_end"],
                "global_start": parsed["global_start"],
                "global_end": parsed["global_end"],
                "parse_status": "PASS_CONTRACT_CLOSED",
                "speech_status": "SEPARATE_AUTHORING_REQUIRED",
            }
        )
    require_unique(formula_rows, "formula_id", "formula occurrence")

    # Speech/meaning is an explicit, separately maintained semantic authority;
    # MathML is emitted from the validated AST and checked as native XML.
    import size_of_sets_expression_semantics as semantics

    semantics.validate_authoring(set(shape_ast_by_id))
    semantics.validate_occurrence_overrides({row["formula_id"] for row in formula_rows})
    delimiters_by_shape: dict[str, set[str]] = {}
    for formula in formula_rows:
        delimiters_by_shape.setdefault(formula["expression_id"], set()).add(formula["delimiter"])
    expression_semantic_rows = [
        semantics.expression_record(row, delimiters_by_shape[row["expression_id"]]) for row in shape_rows
    ]
    require(len(expression_semantic_rows) == 398, "semantic expression record count is not 398")
    require_unique(expression_semantic_rows, "expression_id", "semantic expression")
    semantic_by_id = {row["expression_id"]: row for row in expression_semantic_rows}
    for formula in formula_rows:
        formula["speech_status"] = "AUTHORED_AND_MATHML_BOUND"

    formerly_unsupported_macro_rows = [row for row in inventory if row["family_type"] == "macro" and row["current_nd_pipeline_status"] == "UNSUPPORTED" and int(row["projected_count"]) > 0]
    formerly_unsupported_env_rows = [row for row in inventory if row["family_type"] == "environment" and row["current_nd_pipeline_status"] == "UNSUPPORTED" and int(row["projected_count"]) > 0]
    require({row["name"] for row in formerly_unsupported_macro_rows} == FORMERLY_UNSUPPORTED_MACROS, "50-family macro closure drift")
    require({row["name"] for row in formerly_unsupported_env_rows} == FORMERLY_UNSUPPORTED_ENVIRONMENTS, "3-family environment closure drift")
    require(len(formerly_unsupported_macro_rows) == 50, "formerly unsupported macro family count drift")
    require(sum(int(row["projected_count"]) for row in formerly_unsupported_macro_rows) == 1117, "formerly unsupported macro call count drift")
    require(len(formerly_unsupported_env_rows) == 3, "formerly unsupported environment family count drift")
    require(sum(int(row["projected_count"]) for row in formerly_unsupported_env_rows) == 18, "formerly unsupported environment instance count drift")

    source_labels = read_jsonl(ORACLE / "label_definitions.jsonl")
    source_references = read_jsonl(ORACLE / "references.jsonl")
    structures = read_jsonl(ORACLE / "structures.jsonl")
    require(len(source_labels) == EXPECTED_COUNTS["labels"] and len({row["full_key"] for row in source_labels}) == 33, "source duplicate-label ledger drift")
    require(len(source_references) == EXPECTED_COUNTS["references"], "source reference ledger count drift")
    source_reference_errors = [row for row in source_references if row["status"] != "resolved"]
    require(len(source_reference_errors) == 1 and source_reference_errors[0]["kind"] == "duplicate_label", "source reference error drift")

    sidecar = read_json(SIDECAR_ROOT / "PROJECTION_SIDECAR.json")
    interventions = {row["id"]: row for row in sidecar["interventions"]}
    reference_rules = {row["id"]: row for row in sidecar["reference_resolution"]}
    sar3 = interventions["SAR-003"]
    ref_rule = reference_rules["REFRULE-002"]
    require(sar3["anchor"]["file"] == "content/sets-functions-relations/size-of-sets/reduction-alt.tex", "SAR-003 anchor drift")
    require(sar3["applies_to_instances"] == ["inst-00040"], "SAR-003 instance drift")
    require(sar3["edit"]["expected_utf8"] == r"\label{sfr:siz:red:prob:nat-nat}", "SAR-003 source fragment drift")
    require(sar3["edit"]["replacement_utf8"] == r"\label{sfr:siz:red-alt:prob:nat-nat}", "SAR-003 replacement drift")
    require(ref_rule["action"] == "resolve_to_primary_id", "REFRULE-002 action drift")
    anchor_path = AUTHORITY_ROOT / sar3["anchor"]["file"]
    anchor_text = anchor_path.read_bytes().decode("utf-8")
    source_span = sar3["anchor"]["source_span"]
    source_fragment = anchor_text[int(source_span["char_start_zero"]):int(source_span["char_end_exclusive"])]
    require(source_fragment == sar3["edit"]["expected_utf8"], "SAR-003 anchored source fragment no longer matches")
    require(sha256_text(source_fragment) == source_span["sha256"], "SAR-003 source-fragment hash drift")

    labels: list[dict[str, Any]] = []
    corrected_source_label = sar3["identity_policy"]["canonical_source_label"]
    corrected_projection_id = sar3["identity_policy"]["alternate_projection_id"]
    for source_label in source_labels:
        row = dict(source_label)
        row["source_full_key"] = source_label["full_key"]
        row["projection_full_key"] = source_label["full_key"]
        row["sidecar_intervention_id"] = None
        if source_label["instance_id"] == "inst-00040" and source_label["full_key"] == corrected_source_label:
            row["full_key"] = corrected_projection_id
            row["projection_full_key"] = corrected_projection_id
            row["source_qualified_alias"] = sar3["identity_policy"]["source_qualified_alias"]
            row["preserve_original_as_data_attribute"] = True
            row["sidecar_intervention_id"] = "SAR-003"
            row["visible_disclosure"] = sar3["visible_disclosure"]
        labels.append(row)
    require(len(labels) == 34 and len({row["full_key"] for row in labels}) == 34, "SAR-003 did not produce 34 unique projected label IDs")
    require(sum(row["sidecar_intervention_id"] == "SAR-003" for row in labels) == 1, "SAR-003 projected-label application count drift")

    anchor_segments = [
        segment
        for segment in projection.segments
        if segment.instance_id == "inst-00040"
        and segment.file == sar3["anchor"]["file"]
        and segment.source_start <= int(source_span["char_start_zero"])
        and int(source_span["char_end_exclusive"]) <= segment.source_end
    ]
    require(len(anchor_segments) == 1, "SAR-003 source-map anchor is not unique")
    anchor_segment = anchor_segments[0]
    edit_local_start = anchor_segment.local_start + int(source_span["char_start_zero"]) - anchor_segment.source_start
    edit_local_end = edit_local_start + len(sar3["edit"]["expected_utf8"])
    require(projection.text[edit_local_start:edit_local_end] == sar3["edit"]["expected_utf8"], "SAR-003 projected-text anchor drift")
    corrected_projection_text = (
        projection.text[:edit_local_start]
        + sar3["edit"]["replacement_utf8"]
        + projection.text[edit_local_end:]
    )
    require(corrected_projection_text.count(sar3["edit"]["replacement_utf8"]) == 1, "SAR-003 replacement count drift")
    require(corrected_projection_text.count(sar3["edit"]["expected_utf8"]) == 1, "primary source label was not preserved exactly once")
    intervention_application = {
        "schema": "openlogic-size-of-sets-projection-interventions-v1",
        "result": "PASS_SAR_003_APPLIED_WITH_VISIBLE_DISCLOSURE_BOUND",
        "authority_commit": PINNED_COMMIT,
        "authority_mutated": False,
        "sidecar_sha256": EXPECTED_SIDECAR_SHA256,
        "applied_intervention_ids": ["SAR-003"],
        "applied_reference_rule_ids": ["REFRULE-002"],
        "source_error_preserved_in_oracle": True,
        "operation": {
            "instance_id": "inst-00040",
            "file": sar3["anchor"]["file"],
            "source_char_start_zero": source_span["char_start_zero"],
            "source_char_end_exclusive": source_span["char_end_exclusive"],
            "canonical_projection_local_start": edit_local_start,
            "canonical_projection_local_end": edit_local_end,
            "corrected_projection_delta_characters": len(sar3["edit"]["replacement_utf8"]) - len(sar3["edit"]["expected_utf8"]),
            "expected_utf8": sar3["edit"]["expected_utf8"],
            "replacement_utf8": sar3["edit"]["replacement_utf8"],
            "source_fragment_sha256": source_span["sha256"],
            "corrected_fragment_sha256": sar3["edit"]["projected_fragment_sha256"],
        },
        "identity_policy": sar3["identity_policy"],
        "reference_rule": ref_rule,
        "global_visible_disclosure_required": True,
        "local_visible_disclosure": sar3["visible_disclosure"],
        "canonical_profile_projection_sha256": sha256_text(projection.text),
        "corrected_projection_sha256": sha256_text(corrected_projection_text),
    }

    references: list[dict[str, Any]] = []
    for source_reference in source_references:
        if source_reference["status"] == "resolved":
            references.append({**source_reference, "effective_status": "resolved", "source_status": "resolved"})
            continue
        references.append(
            {
                **source_reference,
                "source_status": "ERROR",
                "effective_status": "resolved_by_explicit_projection_intervention",
                "projection_correction_id": "SAR-003",
                "projection_full_key": corrected_projection_id,
                "source_full_key": corrected_source_label,
                "source_qualified_alias": sar3["identity_policy"]["source_qualified_alias"],
            }
        )
    require(len(references) == 42 and sum(row["effective_status"].startswith("resolved") for row in references) == 42, "effective reference closure drift")
    sets_dependency_ids = {f"inst-{number:05d}" for number in range(4, 11)}
    require(
        all(
            row["kind"] in {"citation", "duplicate_label"}
            or row.get("target_instance_id") in set(EXPECTED_SOURCE_INSTANCES) | sets_dependency_ids
            for row in references
        ),
        "reference escapes Size of Sets, Sets, and bibliography boundaries",
    )

    asset_references = read_jsonl(ORACLE / "asset_references.jsonl")
    require(not asset_references and not asset_by_path, "Size of Sets unexpectedly has external diagram assets")
    formal_oracle = read_jsonl(ORACLE / "formal_objects.jsonl")
    formal_oracle_by_environment = {
        row["environment_id"]: row
        for row in formal_oracle
        if row["source_record_kind"] == "environment"
    }
    diagram_environments = [row for row in environment_rows if row["object_class"] == "diagram_tikz"]
    require(not diagram_environments, "Size of Sets unexpectedly contains a TikZ diagram")
    diagram_rows: list[dict[str, Any]] = []
    require(len(diagram_rows) == EXPECTED_COUNTS["diagrams"], "TikZ diagram closure count drift")

    diagram_by_environment = {row["environment_id"]: row for row in diagram_rows}
    formal_rows: list[dict[str, Any]] = []
    role_map = {
        "definition": "definition",
        "corollary": "theorem",
        "example": "example",
        "exercise": "exercise",
        "proposition": "theorem",
        "theorem": "theorem",
        "display_math": "math",
    }
    for oracle_row in formal_oracle:
        if oracle_row["source_record_kind"] == "environment":
            env = environment_by_id[oracle_row["environment_id"]]
            formulas = [
                row["formula_id"]
                for row in formula_rows
                if int(env["global_start"]) <= int(row["global_start"])
                and int(row["global_end"]) <= int(env["global_end"])
            ]
            contained_labels = [
                row["full_key"]
                for row in labels
                if int(env["global_start"]) <= int(row["stream_start"]) < int(env["global_end"])
            ]
            contained_source_labels = [
                row["source_full_key"]
                for row in labels
                if int(env["global_start"]) <= int(row["stream_start"]) < int(env["global_end"])
            ]
            structure = max(
                (row for row in structures if int(row["stream_start"]) <= int(env["global_start"])),
                key=lambda row: int(row["stream_start"]),
            )
            record = {
                    "formal_object_id": oracle_row["tranche_formal_object_id"],
                    "source_record_kind": "environment",
                    "source_record_id": oracle_row["source_record_id"],
                    "environment_id": env["environment_id"],
                    "object_class": oracle_row["object_class"],
                    "accessible_role": role_map[oracle_row["object_class"]],
                    "instance_id": env["instance_id"],
                    "file": env["file"],
                    "line": env["line"],
                    "global_start": env["global_start"],
                    "global_end": env["global_end"],
                    "content_sha256": env["semantic_content_sha256"],
                    "title_tex": env["title_tex"],
                    "formula_ids": formulas,
                    "label_keys": contained_labels,
                    "source_label_keys": contained_source_labels,
                    "structure_id": structure["structure_id"],
                    "projection_status": "PASS_FORMAL_OBJECT_BOUND",
                }
            if corrected_projection_id in contained_labels:
                record.update(
                    {
                        "editorial_projection_intervention_id": "SAR-003",
                        "editorial_projection_note": sar3["visible_disclosure"]["visible_text"],
                        "editorial_projection_note_placement": sar3["visible_disclosure"]["placement"],
                        "source_qualified_label_alias": sar3["identity_policy"]["source_qualified_alias"],
                    }
                )
            formal_rows.append(record)
        else:
            raise ProjectionError("Size-of-Sets formal-object oracle unexpectedly contains an external object")
    require(len(formal_rows) == EXPECTED_COUNTS["formal_objects"], "formal object count is not 73")
    require_unique(formal_rows, "formal_object_id", "formal object")
    require(
        sum(row.get("editorial_projection_intervention_id") == "SAR-003" for row in formal_rows) == 1,
        "SAR-003 local visible-note binding count drift",
    )
    formula_ids = {row["formula_id"] for row in formula_rows}
    require(all(set(row["formula_ids"]).issubset(formula_ids) for row in formal_rows), "formal object has an unknown formula binding")

    # Parent bindings are computed only between environment-backed formal
    # objects.  Display-math objects nested in examples/definitions retain the
    # nearest semantic container without collapsing either object.
    span_formals = [row for row in formal_rows if row["source_record_kind"] == "environment"]
    for row in span_formals:
        containers = [
            candidate
            for candidate in span_formals
            if candidate is not row
            and int(candidate["global_start"]) <= int(row["global_start"])
            and int(row["global_end"]) <= int(candidate["global_end"])
        ]
        row["parent_formal_object_id"] = (
            min(containers, key=lambda item: int(item["global_end"]) - int(item["global_start"]))[
                "formal_object_id"
            ]
            if containers
            else None
        )

    formal_ids_by_formula: dict[str, list[str]] = {formula_id: [] for formula_id in formula_ids}
    formal_by_id = {row["formal_object_id"]: row for row in formal_rows}
    for formal in formal_rows:
        for formula_id in formal["formula_ids"]:
            formal_ids_by_formula[formula_id].append(formal["formal_object_id"])

    semantic_occurrence_rows: list[dict[str, Any]] = []
    shape_by_id = {row["expression_id"]: row for row in shape_rows}
    for ordinal, formula in enumerate(formula_rows, 1):
        expression = semantic_by_id[formula["expression_id"]]
        display_mode = "inline" if formula["delimiter"] in {"$", r"\(...\)"} else "block"
        structure = max(
            (row for row in structures if int(row["stream_start"]) <= int(formula["global_start"])),
            key=lambda row: int(row["stream_start"]),
        )
        occurrence_override = semantics.OCCURRENCE_OVERRIDES.get(formula["formula_id"])
        occurrence_semantics = occurrence_override or expression
        occurrence_formal_ids = formal_ids_by_formula[formula["formula_id"]]
        occurrence_context_classes = [formal_by_id[formal_id]["object_class"] for formal_id in occurrence_formal_ids]
        context_label = occurrence_context_classes[-1] if occurrence_context_classes else "chapter prose"
        if occurrence_override:
            mathml = semantics.native_mathml(
                shape_by_id[formula["expression_id"]]["ast"],
                formula["expression_id"],
                occurrence_semantics["speech"],
                display=display_mode,
            )
        else:
            mathml = expression["mathml_inline"] if display_mode == "inline" else expression["mathml_block"]
        semantic_occurrence_rows.append(
            {
                "semantic_occurrence_id": f"size-of-sets-expression-occurrence-{ordinal:04d}",
                "formula_id": formula["formula_id"],
                "expression_id": formula["expression_id"],
                "instance_id": formula["instance_id"],
                "file": formula["file"],
                "line": formula["line"],
                "column": formula["column"],
                "offset": formula["offset"],
                "local_start": formula["local_start"],
                "local_end": formula["local_end"],
                "global_start": formula["global_start"],
                "global_end": formula["global_end"],
                "delimiter": formula["delimiter"],
                "display_mode": display_mode,
                "tex": formula["tex"],
                "normalized_tex": formula["normalized_tex"],
                "ast_sha256": formula["ast_sha256"],
                "structure_id": structure["structure_id"],
                "chapter_key": CHAPTER_KEY,
                "part_key": "sfr",
                "profile": "open-logic-complete",
                "scope": "projected",
                "formal_object_ids": occurrence_formal_ids,
                "formal_object_context_classes": occurrence_context_classes,
                "effective_context": context_label,
                "speech": occurrence_semantics["speech"],
                "meaning": occurrence_semantics["meaning"],
                "effective_occurrence_reading": occurrence_semantics["speech"],
                "contextual_meaning": f"In this {context_label} context, {occurrence_semantics['meaning'][0].lower() + occurrence_semantics['meaning'][1:]}",
                "semantic_provenance": (
                    "explicit_occurrence_context_override"
                    if occurrence_override
                    else "expression_shape_semantic_authority"
                ),
                "occurrence_context_override_applied": bool(occurrence_override),
                "mathml": mathml,
                "mathml_sha256": sha256_text(mathml),
                "semantic_status": "AUTHORED_NATIVE_MATHML_BOUND",
            }
        )
    require(len(semantic_occurrence_rows) == 1082, "semantic occurrence ledger count is not 1,082")
    require_unique(semantic_occurrence_rows, "semantic_occurrence_id", "semantic occurrence")
    require_unique(semantic_occurrence_rows, "formula_id", "semantic occurrence formula binding")
    occurrence_by_formula = {row["formula_id"]: row for row in semantic_occurrence_rows}

    formal_object_semantic_rows: list[dict[str, Any]] = []
    for formal in formal_rows:
        occurrences = [occurrence_by_formula[formula_id] for formula_id in formal["formula_ids"]]
        role_label = {
            "corollary": "Corollary",
            "definition": "Definition",
            "example": "Example",
            "exercise": "Exercise",
            "proposition": "Proposition",
            "theorem": "Theorem",
            "display_math": "Displayed mathematics",
        }[formal["object_class"]]
        title = plain_accessible_title(formal.get("title_tex"))
        accessible_name = formal.get("accessible_name") or (f"{role_label}: {title}" if title else role_label)
        spoken_sequence = [row["speech"] for row in occurrences]
        if spoken_sequence:
            accessible_description = (
                f"{role_label} block with {len(spoken_sequence)} mathematical expression"
                f"{'s' if len(spoken_sequence) != 1 else ''}. Its prose remains in source order; "
                "the spoken mathematics is listed explicitly for continuous reading."
            )
            spoken_linearization = " Then: ".join(spoken_sequence)
        else:
            accessible_description = (
                f"{role_label} block with no standalone mathematical expression. "
                "Its complete prose remains in the projected source stream."
            )
            spoken_linearization = "No standalone mathematical expression."
        if formal.get("editorial_projection_note"):
            accessible_description += " " + formal["editorial_projection_note"]
            spoken_linearization += " " + formal["editorial_projection_note"]
        formal_object_semantic_rows.append(
            {
                **formal,
                "semantic_occurrence_ids": [row["semantic_occurrence_id"] for row in occurrences],
                "expression_ids": [row["expression_id"] for row in occurrences],
                "formula_occurrence_count": len(occurrences),
                "unique_expression_count": len({row["expression_id"] for row in occurrences}),
                "accessible_name": accessible_name,
                "accessible_description": accessible_description,
                "spoken_formula_sequence": spoken_sequence,
                "spoken_linearization": spoken_linearization,
                "formal_semantic_provenance": "explicit_role_contract_and_authored_expression_sequence",
                "semantic_binding_status": "PASS_ALL_AUTHORED_NATIVE_MATHML",
            }
        )
    require(len(formal_object_semantic_rows) == 73, "formal-object semantic binding count is not 73")
    require_unique(formal_object_semantic_rows, "formal_object_id", "formal-object semantic binding")
    require(
        all(row["semantic_binding_status"] == "PASS_ALL_AUTHORED_NATIVE_MATHML" for row in formal_object_semantic_rows),
        "formal-object semantic binding is incomplete",
    )
    bad_formal_accessibility = [
        (row["formal_object_id"], row["accessible_name"])
        for row in formal_object_semantic_rows
        if not row["accessible_name"].strip()
        or not row["accessible_description"].strip()
        or "\\" in row["accessible_name"]
        or "$" in row["accessible_name"]
    ]
    require(not bad_formal_accessibility, f"formal-object accessible semantics are incomplete or contain TeX: {bad_formal_accessibility[:5]}")

    segment_rows = [
        {
            "segment_id": segment.segment_id,
            "instance_id": segment.instance_id,
            "file": segment.file,
            "source_start": segment.source_start,
            "source_end": segment.source_end,
            "global_start": segment.global_start,
            "global_end": segment.global_end,
            "local_start": segment.local_start,
            "local_end": segment.local_end,
            "text_sha256": sha256_text(segment.text),
            "source_file_sha256": source_by_path[segment.file]["sha256"],
        }
        for segment in projection.segments
    ]

    contracts = {
        "schema": "openlogic-generalized-parser-contracts-v1",
        "tranche_id": TRANCHE_ID,
        "authority_commit": PINNED_COMMIT,
        "macro_contracts": MACRO_CONTRACTS,
        "environment_contracts": ENVIRONMENT_CONTRACTS,
        "source_stage_only_constructs": sorted(SOURCE_STAGE_ONLY_CONSTRUCTS),
        "closure": {
            "formerly_unsupported_projected_macro_families": len(FORMERLY_UNSUPPORTED_MACROS),
            "formerly_unsupported_projected_macro_calls": sum(macro_counts[name] for name in FORMERLY_UNSUPPORTED_MACROS),
            "formerly_unsupported_projected_environment_families": len(FORMERLY_UNSUPPORTED_ENVIRONMENTS),
            "formerly_unsupported_projected_environment_instances": sum(
                1 for row in environment_rows if row["name"] in FORMERLY_UNSUPPORTED_ENVIRONMENTS
            ),
            "uncontracted_projected_named_macros": [],
            "uncontracted_projected_environments": [],
        },
    }

    document = {
        "schema": "openlogic-size-of-sets-projected-document-v1",
        "result": "PASS_PARSED_PROJECTION_CLOSED",
        "tranche_id": TRANCHE_ID,
        "chapter_key": CHAPTER_KEY,
        "authority_commit": PINNED_COMMIT,
        "source_instance_ids": list(EXPECTED_SOURCE_INSTANCES),
        "projected_text": {
            "path": "projected_size_of_sets.tex",
            "characters": len(corrected_projection_text),
            "bytes": len(corrected_projection_text.encode("utf-8")),
            "sha256": sha256_text(corrected_projection_text),
            "sidecar_intervention_ids": ["SAR-003"],
            "canonical_profile_projection_path": "authority_profile_projection.tex",
            "canonical_profile_projection_sha256": sha256_text(projection.text),
            "source_map_path": "projection_segments.jsonl",
            "source_map_coordinate_space": "canonical profile projection before the recorded four-character SAR-003 ID delta",
            "projection_edit_map_path": "PROJECTION_INTERVENTIONS.json",
        },
        "structure_ids": [row["structure_id"] for row in structures],
        "environment_ids": [row["environment_id"] for row in environment_rows],
        "formula_ids": [row["formula_id"] for row in formula_rows],
        "semantic_expression_ids": [row["expression_id"] for row in expression_semantic_rows],
        "semantic_occurrence_ids": [row["semantic_occurrence_id"] for row in semantic_occurrence_rows],
        "formal_object_ids": [row["formal_object_id"] for row in formal_rows],
        "diagram_ids": [row["diagram_id"] for row in diagram_rows],
        "reference_ids": [row.get("reference_id") or row["label_definition_id"] for row in references],
        "source_closed": True,
        "semantic_layer_status": "FROZEN_FOR_INDEPENDENT_SEMANTIC_AUDIT",
        "canonical_authority_mutated": False,
        "reader_rendering_performed": False,
        "reader_rendering_gate": "HELD_UNTIL_SETS_FINAL_FREEZE",
    }

    reference_closure = {
        "schema": "openlogic-size-of-sets-reference-closure-v1",
        "result": "PASS_EFFECTIVE_CLOSED_WITH_EXPLICIT_SOURCE_CORRECTION",
        "reference_count": len(references),
        "label_count": len(labels),
        "source_census_resolved_count": 41,
        "source_census_error_count": 1,
        "all_source_census_rows_resolved": False,
        "all_effective_projection_rows_resolved": True,
        "source_error_kind": "duplicate_label",
        "correction_intervention_id": "SAR-003",
        "forward_reference_rule_id": "REFRULE-002",
        "all_targets_inside_tranche": False,
        "all_targets_inside_tranche_or_declared_dependencies": True,
        "labels": labels,
        "references": references,
    }
    speech_boundary = {
        "schema": "openlogic-expression-speech-boundary-v2",
        "tranche_id": TRANCHE_ID,
        "parser_projection_status": "PASS",
        "formula_occurrences_bound": len(formula_rows),
        "expression_shapes_parsed": len(shape_rows),
        "speech_authoring_status": "COMPLETE_FROZEN_FOR_INDEPENDENT_AUDIT",
        "authored_speech_shapes": len(expression_semantic_rows),
        "pending_speech_shapes": 0,
        "shape_bindings": [
            {
                "expression_id": row["expression_id"],
                "speech_sha256": sha256_text(row["speech"]),
                "meaning_sha256": sha256_text(row["meaning"]),
                "mathml_inline_sha256": row["mathml_inline_sha256"],
                "mathml_block_sha256": row["mathml_block_sha256"],
            }
            for row in expression_semantic_rows
        ],
    }
    semantic_summary = {
        "schema": "openlogic-size-of-sets-expression-semantic-summary-v1",
        "result": "PASS_FROZEN_FOR_INDEPENDENT_SEMANTIC_AUDIT",
        "tranche_id": TRANCHE_ID,
        "authority_commit": PINNED_COMMIT,
        "expression_records": len(expression_semantic_rows),
        "speech_records_authored": len(expression_semantic_rows),
        "meaning_records_authored": len(expression_semantic_rows),
        "native_mathml_inline_records": len(expression_semantic_rows),
        "native_mathml_block_records": len(expression_semantic_rows),
        "occurrence_ledger_records": len(semantic_occurrence_rows),
        "formal_object_binding_records": len(formal_object_semantic_rows),
        "occurrence_context_override_records": sum(
            row["occurrence_context_override_applied"] for row in semantic_occurrence_rows
        ),
        "diagram_accessible_semantic_records": len(diagram_rows),
        "source_profile_coordinates_preserved": True,
        "all_occurrences_mathml_bound": True,
        "all_occurrences_speech_bound": True,
        "all_occurrences_meaning_bound": True,
        "renderer_integration_performed": False,
        "reader_rendering_blocked_by_sets_final_freeze": True,
        "independent_semantic_audit_status": "READY_NOT_YET_PERFORMED",
    }
    dependency_boundary = {
        "schema": "openlogic-size-of-sets-parser-dependency-boundary-v1",
        "hard_dependency_ids": ["OLAB-TR-000", "OLAB-TR-002"],
        "hard_dependency_production_status": "TR-000 infrastructure and TR-002 source/semantic/static inputs are available; TR-002 final freeze is explicitly HELD",
        "dependency_use": "frozen source/support definitions, profile replay, and resolved backward reference targets",
        "frontmatter_dependency_ids": [],
        "source_oracle_manifest": {
            "path": "../tranche_005_size_of_sets_oracle/EVIDENCE_MANIFEST.json",
            "sha256": EXPECTED_ORACLE_MANIFEST_SHA256,
            "result": oracle_manifest["result"],
        },
        "complete_census_builder": {
            "path": "work/complete_census/build_complete_census.py",
            "sha256": EXPECTED_CENSUS_BUILDER_SHA256,
        },
        "derived_projection_sidecar": {
            "path": "../source_anomaly_resolution/PROJECTION_SIDECAR.json",
            "sha256": EXPECTED_SIDECAR_SHA256,
            "applied_intervention_ids": ["SAR-003"],
            "applied_reference_rule_ids": ["REFRULE-002"],
            "application_receipt": "PROJECTION_INTERVENTIONS.json",
        },
        "sets_reader_gate": {
            "status": "HELD",
            "finding_id": "SETS-FINAL-UX-001",
            "hold_receipt_path": "../independent_tranche_002_sets_final_qa/SUPERSEDING_UX_FINDING.json",
            "hold_receipt_sha256": EXPECTED_SETS_FINAL_HOLD_SHA256,
            "static_qa_receipt_path": "../independent_tranche_002_sets_final_qa/STATIC_QA_RECEIPT.json",
            "static_qa_receipt_sha256": EXPECTED_SETS_STATIC_QA_SHA256,
            "reader_rendering_permitted": False,
            "future_integration_rule": "After Sets final freeze only, rebuild through the cumulative shell contract containing Sets; do not create a Size-of-Sets island.",
        },
        "authority_mutated": False,
    }

    output.mkdir(parents=True, exist_ok=True)
    write_text(output / "authority_profile_projection.tex", projection.text)
    write_text(output / "projected_size_of_sets.tex", corrected_projection_text)
    write_jsonl(output / "projection_segments.jsonl", segment_rows)
    write_json(output / "CONSTRUCT_CONTRACTS.json", contracts)
    write_jsonl(output / "macro_occurrences.jsonl", macro_rows)
    write_jsonl(output / "environment_nodes.jsonl", environment_rows)
    write_jsonl(output / "expression_shapes.jsonl", shape_rows)
    write_jsonl(output / "expression_semantics.jsonl", expression_semantic_rows)
    write_jsonl(output / "formula_bindings.jsonl", formula_rows)
    write_jsonl(output / "semantic_occurrences.jsonl", semantic_occurrence_rows)
    write_jsonl(output / "formal_object_nodes.jsonl", formal_rows)
    write_jsonl(output / "formal_object_semantic_bindings.jsonl", formal_object_semantic_rows)
    write_jsonl(output / "diagram_nodes.jsonl", diagram_rows)
    write_json(output / "PROJECTED_DOCUMENT.json", document)
    write_json(output / "REFERENCE_CLOSURE.json", reference_closure)
    write_json(output / "EXPRESSION_SPEECH_BOUNDARY.json", speech_boundary)
    write_json(output / "SEMANTIC_SUMMARY.json", semantic_summary)
    write_json(output / "DEPENDENCY_BOUNDARY.json", dependency_boundary)
    write_json(output / "PROJECTION_INTERVENTIONS.json", intervention_application)

    summary = {
        "schema": "openlogic-size-of-sets-parser-projection-summary-v1",
        "result": "PASS_PARSED_PROJECTION_CLOSED",
        "tranche_id": TRANCHE_ID,
        "chapter_key": CHAPTER_KEY,
        "authority_commit": PINNED_COMMIT,
        "counts": {
            **EXPECTED_COUNTS,
            "projection_segments": len(segment_rows),
            "projected_named_macro_calls": sum(macro_counts.values()),
            "projected_control_symbol_calls": sum(control_symbols.values()),
            "formal_objects_with_formula_bindings": sum(bool(row["formula_ids"]) for row in formal_rows),
            "semantic_expression_records": len(expression_semantic_rows),
            "semantic_occurrence_records": len(semantic_occurrence_rows),
            "formal_object_semantic_bindings": len(formal_object_semantic_rows),
        },
        "closure": contracts["closure"],
        "source_closed": True,
        "profile_closed": True,
        "formula_parse_closed": True,
        "formal_object_bindings_closed": True,
        "nonprose_object_parse_closed": True,
        "reference_closed": True,
        "expression_speech_separable": True,
        "expression_speech_authored": True,
        "expression_meaning_authored": True,
        "native_mathml_closed": True,
        "semantic_layer_status": "FROZEN_FOR_INDEPENDENT_SEMANTIC_AUDIT",
        "ready_for_translation_and_accessibility_authoring": True,
        "ready_for_final_accessible_rendering": False,
        "remaining_blockers": [
            "Sets final freeze is held by SETS-FINAL-UX-001",
            "final renderer integration is prohibited until Sets closes and must then use the cumulative shell",
            "the frozen semantic layer still requires an independent semantic audit before renderer integration",
        ],
    }
    write_json(output / "SUMMARY.json", summary)

    report = f"""# OLAB-TR-005 The Size of Sets parsed semantic projection

Result: **PASS_PARSED_PROJECTION_CLOSED**.

The frozen fourteen-file Size-of-Sets profile replays source-exhaustively and the SAR-003-corrected derived projection hashes to `{document['projected_text']['sha256']}`. The generalized parser has explicit contracts for all 68 projected named macro families and all 14 environment families. It closes the prior renderer gap of **50 macro families / 1,117 calls** and **3 environment families / 18 instances** without changing canonical authority.

The deterministic projection binds **1,082 formula occurrences / 398 expression shapes**, **137 environments**, **73 formal objects**, **39 exercises**, and all **42** census reference-ledger rows. All 398 expression records have contract-authored speech and meaning plus validated inline and block native MathML. The exact 1,082-record semantic occurrence ledger preserves source/profile coordinates and records an effective context reading; the 73-record formal-object semantic ledger gives every object a role, accessible name, description, and spoken formula sequence.

The source duplicate label remains visible in the immutable oracle as an error. In the derived projection, SAR-003 changes only the alternate exercise label to `sfr:siz:red-alt:prob:nat-nat`, preserves the original source label and qualified alias, binds the required local editorial note to that exercise, and records REFRULE-002 for future cumulative reference resolution. The raw profile projection and the corrected derived projection are both frozen with an explicit edit map.

The semantic layer is **FROZEN_FOR_INDEPENDENT_SEMANTIC_AUDIT**. This local preaudit may repair producer defects but does not claim independent PASS. Sets final freeze is currently **HELD** by `SETS-FINAL-UX-001`, so no Size-of-Sets reader was rendered. Once that hold closes, reader work must extend the cumulative Sets shell rather than create a separate island.
"""
    write_text(output / "REPORT.md", report)

    artifact_names = [
        "CONSTRUCT_CONTRACTS.json",
        "DEPENDENCY_BOUNDARY.json",
        "EXPRESSION_SPEECH_BOUNDARY.json",
        "PROJECTION_INTERVENTIONS.json",
        "PROJECTED_DOCUMENT.json",
        "REFERENCE_CLOSURE.json",
        "REPORT.md",
        "SEMANTIC_SUMMARY.json",
        "SUMMARY.json",
        "diagram_nodes.jsonl",
        "environment_nodes.jsonl",
        "expression_semantics.jsonl",
        "expression_shapes.jsonl",
        "formal_object_semantic_bindings.jsonl",
        "formal_object_nodes.jsonl",
        "formula_bindings.jsonl",
        "macro_occurrences.jsonl",
        "authority_profile_projection.tex",
        "projected_size_of_sets.tex",
        "projection_segments.jsonl",
        "semantic_occurrences.jsonl",
    ]
    artifact_manifest = {
        "schema": "openlogic-size-of-sets-parser-artifact-manifest-v1",
        "result": "PASS",
        "tranche_id": TRANCHE_ID,
        "authority_commit": PINNED_COMMIT,
        "builder_artifact_count": len(artifact_names),
        "builder_artifacts": [
            {
                "path": name,
                "bytes": (output / name).stat().st_size,
                "sha256": sha256_file(output / name),
            }
            for name in artifact_names
        ],
    }
    write_json(output / "ARTIFACT_MANIFEST.json", artifact_manifest)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    summary = build(args.output)
    print(
        f"{summary['result']}: {summary['counts']['formulas']} formulas, "
        f"{summary['counts']['formal_objects']} formal objects, {summary['counts']['diagrams']} diagrams"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
