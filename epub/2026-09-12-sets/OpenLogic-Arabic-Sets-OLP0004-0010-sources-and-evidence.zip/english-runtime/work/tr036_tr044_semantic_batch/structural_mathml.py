"""Fail-closed structural MathML shared by the frozen TR036–TR044 batch.

Structural grammar is reused from TR035; successful parsing makes no claim
about a formula's separately authored semantic reading.
"""
from pathlib import Path
from contextvars import ContextVar
import hashlib
import html
import importlib.util
import json
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE_PATH = HERE.parent / "tranche_035_semantic_production" / "structural_mathml.py"
BASE_SHA256 = "ab0338a69462eb84ba035ac65b12f6c65038771cc45466124970be6bdcac2b64"
if hashlib.sha256(BASE_PATH.read_bytes()).hexdigest() != BASE_SHA256:
    raise RuntimeError("TR035 structural foundation identity mismatch")
spec = importlib.util.spec_from_file_location("tr036_tr044_tr035_structural_base", BASE_PATH)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
core = base.core
grammar = base.base
renderer = grammar.base.base.base
render_nodes = grammar._render_nodes
previous_node = base.mathml_node
SOURCE_ROOT = Path("upstream-source")
CONFIG = SOURCE_ROOT / "open-logic-config.sty"
CONFIG_SHA256 = "ab19be71b50b415738603290317b504d9fa6b82850fe640d585c62db1540ced3"
if hashlib.sha256(CONFIG.read_bytes()).hexdigest() != CONFIG_SHA256:
    raise RuntimeError("immutable macro configuration identity mismatch")
CONTEXT = ContextVar("batch_mathml_source_context", default=None)

# Every addition is explicit: unknown control sequences still fail in the
# inherited parser. The source xparse mandatory arguments also accept tokens.
def contract(required=0, optional=0):
    return grammar.contract(required, optional, True)


GREEK = {"alpha": "α", "beta": "β", "eta": "η", "lambda": "λ",
         "Lambda": "Λ", "Sigma": "Σ", "Pi": "Π", "aleph": "ℵ"}
OPERATORS = {"downarrow": "↓", "uparrow": "↑", "ni": "∋", "ne": "≠",
             "ltrue": "⊤", "eqs": "≡", "dagger": "†", "vdash": "⊢", "nvdash": "⊬"}
FUNCTIONS = {"max": "max", "min": "min", "lcm": "lcm"}
for name in GREEK | OPERATORS | FUNCTIONS:
    core.MACRO_CONTRACTS[name] = contract()
for name in ("num", "bar", "overline", "hat", "underline", "Complement", "Pow", "FV", "Id", "ran", "bcd", "becd"):
    core.MACRO_CONTRACTS[name] = contract(1)
for name in ("cardle", "cardless", "cardeq", "frac", "bexists", "bforall", "bmin", "umin"):
    core.MACRO_CONTRACTS[name] = contract(2)
for name in ("Char", "Th", "Setabs", "Subst", "Atom", "Domain", "Struct", "Lang", "Assign", "Obj"):
    core.MACRO_CONTRACTS[name]["allow_unbraced_arguments"] = True
for name in ("Prov", "OProv", "Refut", "ORefut", "ORProv", "Sent", "TrmSOL", "FrmSOL", "red", "redone", "redpar", "equal", "Proves", "NotProves"):
    core.MACRO_CONTRACTS[name] = contract(0, 1)
for name in ("aconvone", "bredone", "eredone", "beredone", "xredone", "aconv", "bred", "ered", "bered", "xred", "aeq", "bredpar", "beredpar", "indfrm", "indfrmp", "indcomplex"):
    core.MACRO_CONTRACTS[name] = contract()
for name, required in {"Sat": 2, "Notsat": 2, "Value": 2, "varAssign": 3, "rep": 1}.items():
    core.MACRO_CONTRACTS[name] = contract(required)
core.MACRO_CONTRACTS["xrightarrow"] = contract(1, 1)
core.MACRO_CONTRACTS["olref"] = contract(1, 3)
core.MACRO_CONTRACTS["ext"] = contract()

# Source-defined postfix optional arguments must bind even when deeply nested.
# This modifies only the imported in-memory grammar, never the foundation file.
_parse_invocation = core.parse_macro_invocation
POSTFIX_OPTIONS = {"Sat", "Notsat", "Value", "varAssign", "rep"}


def parse_macro_invocation(text, offset):
    invocation = _parse_invocation(text, offset)
    if invocation["name"] in POSTFIX_OPTIONS:
        probe = core.skip_space(text, invocation["end"])
        if text[probe:probe + 1] == "[":
            _, _, end, option = core.parse_balanced(text, probe, "[")
            invocation["options"] = [option]
            invocation["end"] = end
    return invocation


core.parse_macro_invocation = parse_macro_invocation


def _first_style(nodes, variant):
    """Apply the configured style to the first TeX token, not its scripts."""
    if not nodes:
        return '<mrow/>'
    copied = list(nodes)
    first = dict(copied[0])
    if first["type"] == "text":
        value = first["value"].lstrip()
        if not value:
            return _first_style(copied[1:], variant)
        first["value"] = value[0]
        copied = [first] + ([{"type": "text", "value": value[1:]}] if value[1:] else []) + copied[1:]
    first = copied.pop(0)
    # A local explicit AST node lets the inherited script binder attach any
    # following script to the styled base without styling its argument.
    styled = {"type": "batch_styled", "variant": variant, "children": [first]}
    return render_nodes([styled] + copied)


def _struct(nodes):
    return _first_style(nodes, "fraktur")


def _named_style(nodes, variant):
    """Group explicit textual names before scripts bind to their bases.

Unlike ordinary math adjacency, the source fn, Th and Log macros explicitly
declare a named function, predicate, theory or logic. Their letter runs are
one identifier; punctuation, subscripts and superscripts remain structural.
"""
    def named_nodes(items):
        result = []
        for node in items:
            kind = node["type"]
            if kind == "text":
                for value in re.findall(r"[A-Za-z]+|[^A-Za-z]+", node["value"]):
                    result.append({"type": "batch_named_identifier", "value": value, "variant": variant}
                                  if re.fullmatch(r"[A-Za-z]+", value)
                                  else {"type": "text", "value": value})
            elif kind == "group":
                result.append({**node, "children": named_nodes(node["children"])})
            elif kind == "script":
                result.append({**node, "argument": {"type": "group", "children": named_nodes([node["argument"]])}})
            else:
                result.append(node)
        return result
    return f'<mstyle mathvariant="{variant}">{render_nodes(named_nodes(nodes))}</mstyle>'


def _call(label, argument):
    return f'<mrow><mi mathvariant="normal">{label}</mi><mo>(</mo>{argument}<mo>)</mo></mrow>'


def _mixed_text(nodes):
    """Preserve complete math AST spans between dollar delimiters in prose."""
    output, prose, mathematics = [], [], []
    in_math = False

    def flush_prose():
        if prose:
            value = ''.join(prose).replace('~', ' ').replace('!!', '').replace('``', '“').replace("''", '”')
            output.append('<mtext>' + html.escape(re.sub(r'\s+', ' ', value)) + '</mtext>')
            prose.clear()

    def flush_math():
        if mathematics:
            output.append(render_nodes(mathematics))
            mathematics.clear()

    for node in nodes:
        if node["type"] == "text":
            parts = node["value"].split('$')
            for index, part in enumerate(parts):
                if part:
                    if in_math:
                        mathematics.append({"type": "text", "value": part})
                    else:
                        prose.append(part)
                if index < len(parts) - 1:
                    if in_math:
                        flush_math()
                    else:
                        flush_prose()
                    in_math = not in_math
        elif in_math:
            mathematics.append(node)
        elif node["type"] == "group":
            prose.append(renderer.literal_text(node["children"]))
        else:
            flush_prose()
            output.append(mathml_node(node))
    if in_math:
        raise ValueError("unclosed inline mathematics in a text argument")
    flush_prose()
    return '<mrow>' + ''.join(output) + '</mrow>'


def _source_text(context):
    file = context.get("file")
    if not file or not file.startswith("content/") or ".." in Path(file).parts:
        raise ValueError("source_context.file must name frozen content")
    expected = context.get("source_sha256")
    if expected is not None and re.fullmatch(r"[0-9a-f]{64}", expected) is None:
        raise ValueError("source_context.source_sha256 must be a complete source hash")
    if expected is None:
        # Compatibility for standalone probes; production passes the exact
        # source hash verified by its configured, pinned oracle contract.
        oracle = HERE.parent / "tr036_tr044_oracle_batch" / "canonical"
        for authority in oracle.glob("OLAB-TR-*/SOURCE_AUTHORITY.json"):
            for record in json.loads(authority.read_text(encoding="utf-8"))["source_records"]:
                if record["path"] == file:
                    expected = record["sha256"]
                    break
            if expected:
                break
    data = (SOURCE_ROOT / file).read_bytes()
    if expected is None or hashlib.sha256(data).hexdigest() != expected:
        raise ValueError("source context identity mismatch")
    return data.decode("utf-8")


def _inductive_tex(name):
    context = CONTEXT.get()
    if not context:
        raise ValueError(f"\\{name} requires source_context for its enclosing indcase")
    source = _source_text(context)
    target = context.get("offset")
    if target is None:
        target = sum(len(line) for line in source.splitlines(keepends=True)[:context["line"] - 1])
    for match in re.finditer(r"\\indcase(?![A-Za-z])[*!]?[ \t\r\n]*", source):
        cursor = match.end()
        arguments = []
        for _ in range(3):
            cursor = core.skip_space(source, cursor)
            _, _, cursor, value = core.parse_balanced(source, cursor, "{")
            arguments.append(value)
        if match.start() <= target <= cursor:
            return arguments[1 if name == "indcomplex" else 0]
    raise ValueError(f"\\{name} has no enclosing source indcase at the supplied location")


def mathml_node(node):
    if node.get("type") == "batch_named_identifier":
        return f'<mi mathvariant="{node["variant"]}">{html.escape(node["value"])}</mi>'
    if node.get("type") == "batch_styled":
        return f'<mstyle mathvariant="{node["variant"]}">{render_nodes(node["children"])}</mstyle>'
    if node.get("type") != "macro":
        return previous_node(node)
    name = node["name"]
    if name in {"text", "mbox", "intertext"}:
        # Keep inline mathematics and bound cross-references as descendants;
        # serializing the entire argument as prose would expose TeX commands.
        return _mixed_text(node["arguments"][0])
    args = grammar._args(node)
    opts = grammar._options(node)
    if name in GREEK:
        return f'<mi>{GREEK[name]}</mi>'
    if name in OPERATORS:
        return f'<mo>{OPERATORS[name]}</mo>'
    if name in FUNCTIONS:
        return f'<mi mathvariant="normal">{FUNCTIONS[name]}</mi>'
    if name == "ext":
        return '<mi mathvariant="italic">ext</mi>'
    if name in {"bar", "overline", "num", "Complement", "hat", "underline"}:
        tag = "munder" if name == "underline" else "mover"
        attribute = "accentunder" if name == "underline" else "accent"
        accent = "^" if name == "hat" else "¯"
        return f'<{tag} {attribute}="true">{args[0]}<mo>{accent}</mo></{tag}>'
    if name == "frac":
        return f'<mfrac>{args[0]}{args[1]}</mfrac>'
    if name in {"fn", "Th", "Log"}:
        return _named_style(node["arguments"][0], "normal" if name == "fn" else "bold")
    if name in {"eq", "neq"}:
        # The inherited operator dictionary includes neq and would return
        # only its glyph before the optional-operand renderer can run.
        # Source eq/ is normalized to neq, so dispatch its arity here first.
        symbol = "=" if name == "eq" else "≠"
        if len(opts) == 2:
            return f'<mrow>{opts[0]}<mo>{symbol}</mo>{opts[1]}</mrow>'
        if len(opts) <= 1:
            # open-logic-config.sty:167–173 prints only the relation when
            # the second optional argument is absent.
            return f'<mo>{symbol}</mo>'
        raise ValueError("identity macro has more than two optional arguments")
    if name in {"Lang", "Struct"}:
        return _first_style(node["arguments"][0], "script" if name == "Lang" else "fraktur")
    if name == "Domain":
        return f'<mrow><mo>|</mo>{_struct(node["arguments"][0])}<mo>|</mo></mrow>'
    if name == "Assign":
        return f'<msup>{args[0]}{_struct(node["arguments"][1])}</msup>'
    if name == "Theory":
        return _call("Th", _struct(node["arguments"][0]))
    if name in {"Sat", "Notsat"}:
        assignment = '<mo>,</mo>' + opts[0] if opts else ''
        relation = "⊨" if name == "Sat" else "⊭"
        return f'<mrow>{_struct(node["arguments"][0])}{assignment}<mo>{relation}</mo>{args[1]}</mrow>'
    if name == "Value":
        head = '<mi mathvariant="normal">Val</mi>'
        model = _struct(node["arguments"][1])
        head = f'<msubsup>{head}{opts[0]}{model}</msubsup>' if opts else f'<msup>{head}{model}</msup>'
        return f'<mrow>{head}<mo>(</mo>{args[0]}<mo>)</mo></mrow>'
    if name == "varAssign":
        if not opts:
            return f'<mrow>{args[0]}<msub><mo>∼</mo>{args[2]}</msub>{args[1]}</mrow>'
        return f'<mrow>{args[0]}<mo>=</mo>{args[1]}<mo>[</mo><msup><mspace width="0em"/>{opts[0]}</msup><mo>/</mo>{args[2]}<mo>]</mo></mrow>'
    if name == "Setabs":
        return f'<mrow><mo>{{</mo>{args[0]}<mo>:</mo>{args[1]}<mo>}}</mo></mrow>'
    if name in {"cardle", "cardless", "cardeq"}:
        symbol = {"cardle": "≼", "cardless": "≺", "cardeq": "≈"}[name]
        return f'<mrow>{args[0]}<mo>{symbol}</mo>{args[1]}</mrow>'
    if name == "Pow":
        return f'<mrow><mi>℘</mi><mo>(</mo>{args[0]}<mo>)</mo></mrow>'
    if name in {"FV", "ran"}:
        return _call(name, args[0])
    if name == "Id":
        return f'<msub><mi mathvariant="normal">Id</mi>{args[0]}</msub>'
    if name in {"Prov", "OProv", "Refut", "ORefut", "ORProv"}:
        label = {"Prov": "Prov", "OProv": "Prov", "Refut": "Ref", "ORefut": "Ref", "ORProv": "RProv"}[name]
        head = f'<mi mathvariant="{"sans-serif" if name.startswith("O") else "normal"}">{label}</mi>'
        return f'<msub>{head}{opts[0]}</msub>' if opts else head
    if name in {"Sent", "TrmSOL", "FrmSOL"}:
        label = {"Sent": "Sent", "TrmSOL": "Trm", "FrmSOL": "Frm"}[name]
        head = f'<mi mathvariant="normal">{label}</mi>'
        if name != "Sent":
            head = f'<msup>{head}<mn>2</mn></msup>'
        if opts:
            language = _first_style(grammar.parse_ast(node["options"][0]), "script")
            head = f'<mrow>{head}<mo>(</mo>{language}<mo>)</mo></mrow>'
        return head
    if name == "lambd":
        body = '<mi>λ</mi>'
        if opts:
            body += opts[0]
        if len(opts) == 2:
            body += '<mo>.</mo><mspace width="0.1667em"/>' + opts[1]
        return '<mrow>' + body + '</mrow>'
    reductions = {"aconvone": ("→", "α"), "bredone": ("→", "β"), "eredone": ("→", "η"),
                  "beredone": ("→", "βη"), "xredone": ("→", "X"), "aconv": ("↠", "α"),
                  "bred": ("↠", "β"), "ered": ("↠", "η"), "bered": ("↠", "βη"),
                  "xred": ("↠", "X"), "aeq": ("=", "α"), "bredpar": ("⇒", "β"),
                  "beredpar": ("⇒", "βη")}
    if name in reductions:
        symbol, label = reductions[name]
        label = ''.join(f'<mi>{char}</mi>' for char in label)
        return f'<mover><mo>{symbol}</mo><mrow>{label}</mrow></mover>'
    if name in {"redone", "red", "redpar", "equal", "Proves", "NotProves"}:
        symbol = {"redone": "→", "red": "↠", "redpar": "⇒", "equal": "=", "Proves": "⊢", "NotProves": "⊬"}[name]
        operator = f'<mo>{symbol}</mo>'
        tag = 'msub' if name in {"Proves", "NotProves"} else 'mover'
        return f'<{tag}>{operator}{opts[0]}</{tag}>' if opts else operator
    if name == "xrightarrow":
        return f'<munderover><mo>→</mo>{opts[0]}{args[0]}</munderover>' if opts else f'<mover><mo>→</mo>{args[0]}</mover>'
    if name in {"bcd", "becd"}:
        label = '<mi>β</mi>' + ('<mi>η</mi>' if name == 'becd' else '')
        return f'<msup>{args[0]}<mrow><mo>*</mo>{label}</mrow></msup>'
    if name == "rep":
        head = f'<munder accentunder="true">{args[0]}<mo>¯</mo></munder>'
        return f'<msub>{head}{opts[0]}</msub>' if opts else head
    if name in {"indfrm", "indfrmp", "indcomplex"}:
        return render_nodes(grammar.parse_ast(_inductive_tex(name)))
    if name == "olref":
        key = grammar._tex_nodes(node["arguments"][0])
        context = CONTEXT.get() or {}
        bindings = context.get("reference_speech", {})
        # Full targets follow the OLP reference contract. The engine may also
        # supply unambiguous local-key bindings for the enclosing source.
        parts = list(node["options"])
        enclosing = [context.get("part_key"), context.get("chapter_key"), context.get("section_key")]
        if parts:
            if len(parts) == 1:
                candidates = [":".join(filter(None, [enclosing[1], parts[0], key])), parts[0] + ":" + key, key]
            elif len(parts) == 2:
                candidates = [":".join(parts + [key]), key]
            else:
                candidates = [":".join(parts + [key]), key]
        else:
            candidates = [key]
        words = next((bindings[candidate] for candidate in candidates if candidate in bindings), None)
        if not words:
            raise ValueError(f"embedded reference {key!r} requires source_context.reference_speech binding")
        return f'<mtext data-reference-target="{html.escape(key, quote=True)}">{html.escape(words)}</mtext>'
    return previous_node(node)


renderer.mathml_node = mathml_node

# TeX's ordinary letter tokens remain distinct atoms. In particular, lambda
# application MN is not a single identifier named MN. Named operators/macros
# above carry their explicit normal/sans-serif labels; no multiplication or
# application meaning is invented from adjacency.
renderer._tokens = lambda value: re.findall(r"![A-Z]|[A-Za-z]|[0-9]+|!=|<=|>=|[^\s]", value)


SOURCE_FRAGMENTS = {
    "projected-formula-0020053": {
        "file": "content/incompleteness/theories-computability/consis-with-q.tex",
        "tex": r"\Setabs{!A}{\text{", "kind": "nested_inline_math_census_prefix",
        "body": '<mrow><mo>{</mo><mi>A</mi><mo>:</mo></mrow>',
        "diagnostic": "Source fragment ends inside the set condition text.",
    },
    "projected-formula-0020054": {
        "file": "content/incompleteness/theories-computability/consis-with-q.tex",
        "tex": "is provable in first-order logic}}", "kind": "nested_inline_math_census_suffix",
        "body": '<mrow><mtext>is provable in first-order logic</mtext><mo>}</mo></mrow>',
        "diagnostic": "Source fragment continues the preceding set condition text.",
    },
    "projected-formula-0020669": {
        "file": "content/incompleteness/incompleteness-provability/tarski-thm.tex",
        "tex": r"T(\text{`", "kind": "nested_inline_math_census_prefix",
        "body": '<mrow><mi>T</mi><mo>(</mo><mtext>‘</mtext></mrow>',
        "diagnostic": "Source fragment ends at the opening quotation inside the truth predicate.",
    },
    "projected-formula-0020670": {
        "file": "content/incompleteness/incompleteness-provability/tarski-thm.tex",
        "tex": "'})", "kind": "nested_inline_math_census_suffix",
        "body": '<mrow><mtext>’</mtext><mo>)</mo></mrow>',
        "diagnostic": "Source fragment supplies the closing quotation and predicate parenthesis.",
    },
    "projected-formula-0021164": {
        "file": "content/second-order-logic/metatheory/undecidability-and-axiomatizability.tex",
        "tex": r"\Sat{M}{!P \lif !A", "kind": "source_closing_brace_after_math_delimiter",
        "body": '<mrow><mstyle mathvariant="fraktur"><mi>M</mi></mstyle><mo>⊨</mo><mrow><mi>P</mi><mo>→</mo><mi>A</mi></mrow></mrow>',
        "diagnostic": "The source closes the satisfaction argument after its math delimiter.",
    },
}


def _fragment_mathml(expression_id, tex, display, context):
    """Bounded, source-verified fragment topology, never an unknown-TeX fallback.

These five oracle fragments are not complete formulas. Their visible source
tokens are exposed as native children with a visible diagnostic and exact
annotation; no closing delimiter or missing operand is supplied. A separate
reader repair remains the author/producer's responsibility.
"""
    if not context:
        return None
    record = SOURCE_FRAGMENTS.get(context.get("formula_id"))
    if not record or re.sub(r"\s+", " ", tex).strip() != record["tex"]:
        return None
    if context.get("file") != record["file"]:
        raise ValueError("source fragment location mismatch")
    _source_text(context)  # verify all immutable source bytes before rendering
    if display not in {"inline", "block"}:
        raise ValueError("invalid display mode: " + display)
    annotation = html.escape(tex).replace("\r", "&#13;")
    diagnostic = html.escape(record["diagnostic"])
    return (f'<math xmlns="http://www.w3.org/1998/Math/MathML" display="{display}" '
            f'data-expression-id="{html.escape(expression_id, quote=True)}" '
            f'data-source-fragment="incomplete_source_fragment" data-fragment-kind="{record["kind"]}">'
            f'<semantics><mrow><merror><mtext>{diagnostic}</mtext></merror>{record["body"]}</mrow>'
            f'<annotation encoding="application/x-tex">{annotation}</annotation></semantics></math>')


def native_mathml(expression_id, tex, display="inline", source_context=None):
    r"""Render exact source with named identifiers separate from application.

    Regression: explicit normal/bold names remain single identifiers, even
    when the last named base is scripted within its source argument.

    >>> q = lambda name: '{http://www.w3.org/1998/Math/MathML}' + name
    >>> root = ET.fromstring(native_mathml('names', r'\fn{Subst}\fn{Pow}\fn{Codes}\fn{Cont}\fn{Aleph_1}\Th{PA^2}\Log{PA}'))
    >>> [(e.text, e.get('mathvariant')) for e in root.iter(q('mi'))]
    [('Subst', 'normal'), ('Pow', 'normal'), ('Codes', 'normal'), ('Cont', 'normal'), ('Aleph', 'normal'), ('PA', 'bold'), ('PA', 'bold')]

    Regression: unrelated bare lambda application keeps separate operands.

    >>> root = ET.fromstring(native_mathml('application', r'\lambd[x][MN]'))
    >>> [e.text for e in root.iter(q('mi'))]
    ['λ', 'x', 'M', 'N']

    Regression: slash-negated equality keeps both optional operands.

    >>> root = ET.fromstring(native_mathml('neq-operands', r'\lforall[x][\eq/[x\prime][\Obj{0}]]'))
    >>> ''.join(root.find(q('semantics'))[0].itertext())
    '∀xx′≠0'
    """
    token = CONTEXT.set(source_context)
    try:
        fragment = _fragment_mathml(expression_id, tex, display, source_context)
        if fragment is not None:
            return fragment
        # A standalone source prime names the successor symbol, not a missing
        # scripted operand. Embedded primes retain inherited script binding.
        surrogate = re.sub(r'\\"(?:\{([A-Za-z])\}|([A-Za-z]))',
                           lambda m: unicodedata.normalize("NFC", (m[1] or m[2]) + "\u0308"), tex)
        surrogate = re.sub(r"\\not\s*\\vdash\b", lambda m: r"\nvdash", surrogate)
        surrogate = re.sub(r"\\not\s*\\in\b", lambda m: r"\notin", surrogate)
        notation = (source_context or {}).get("mathml_notation", {})
        if notation:
            if notation.get("notation") != "de_bruijn" or set(notation) != {"notation", "index_applications"}:
                raise ValueError("unsupported authored MathML notation context")
            _source_text(source_context)
            for application in notation["index_applications"]:
                spelling, indices = application["source_tex"], application["indices"]
                if (not isinstance(indices, list) or len(indices) < 2 or
                        not all(isinstance(index, str) and re.fullmatch(r"[0-9]+", index) for index in indices)):
                    raise ValueError("invalid de Bruijn index-application grouping")
                visible = re.sub(r"\\[,;:]|\s+", "", spelling)
                if visible != "".join(indices) or surrogate.count(spelling) != 1:
                    raise ValueError("de Bruijn source index grouping does not replay exactly")
                # Explicit groups prevent the inherited numeral lexer and
                # thin-space normalization from treating separate indices as
                # one decimal integer. The exact source annotation is restored
                # below; this is authored source-context interpretation.
                surrogate = surrogate.replace(spelling, "".join("{" + index + "}" for index in indices), 1)
        if surrogate.strip() == "'":
            value = base.native_mathml(expression_id, r"\prime", display)
        else:
            value = base.native_mathml(expression_id, surrogate, display)
        # XML 1.0 normalizes literal CRs; numeric references preserve the exact
        # raw source annotation across a native XML parse/serialize roundtrip.
        annotation = html.escape(tex).replace("\r", "&#13;")
        value = re.sub(r'(<annotation encoding="application/x-tex">).*?(</annotation>)',
                       lambda m: m[1] + annotation + m[2], value, flags=re.S)
        ET.fromstring(value)
        return value
    finally:
        CONTEXT.reset(token)
