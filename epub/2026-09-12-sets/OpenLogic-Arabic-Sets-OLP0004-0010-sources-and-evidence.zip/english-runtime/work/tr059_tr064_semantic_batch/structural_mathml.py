"""Execute the exact sealed TR045 native-MathML grammar in this batch root.

The source bytes are hash pinned.  Because execution uses this module's global
namespace, the sealed grammar observes this wrapper's local ``__file__`` and
therefore discovers only this batch's frozen chapter configs.
"""
from pathlib import Path
import hashlib
import sys

sys.dont_write_bytecode = True
LOCAL_FILE = Path(__file__).resolve()
PROJECT = LOCAL_FILE.parents[2]
TARGET = PROJECT / "work/tr045_tr049_semantic_batch/structural_mathml.py"
EXPECTED = "bdb5115c414d9b025b491aab90cfc5df846308af61bdcc321dee3c5c810853e0"
SOURCE = TARGET.read_bytes()
if hashlib.sha256(SOURCE).hexdigest() != EXPECTED:
    raise ValueError("sealed shared native-MathML grammar drift")
exec(compile(SOURCE, str(TARGET), "exec"), globals())
if Path(__file__).resolve() != LOCAL_FILE:
    raise ValueError("sealed MathML grammar replaced batch-local source authority")


# The inherited grammar pins open-logic-config.sty.  TR059--TR064 use the
# additional source-defined notations below; the formula-letter switch is the
# only definition outside that file and is pinned separately.  Latin formula
# mode makes ``\formula{A}`` a transparent wrapper.
_TR059_FORMULA_SWITCH_PIN = {
    "path": "sty/open-logic-formulas.sty",
    "sha256": "6c1fe7695cab63cdf9e6ace0327aeedfcab824688cd762fc35281a3b25679369",
    "rules": "Latin formula mode makes formula-letter wrappers transparent",
}
if hashlib.sha256((SOURCE_ROOT / _TR059_FORMULA_SWITCH_PIN["path"]).read_bytes()).hexdigest() != _TR059_FORMULA_SWITCH_PIN["sha256"]:
    raise RuntimeError("immutable formula-letter definition identity mismatch")
SOURCE_DEFINITION_PINS = (*SOURCE_DEFINITION_PINS, _TR059_FORMULA_SWITCH_PIN)

for _tr059_nullary_macro in (
        "FalseCl", "FalseInt", "PAx", "PosInt", "strictif", "cif",
        "boxright", "bot", "subset", "subsetneq", "supseteq", "supsetneq"):
    core.MACRO_CONTRACTS[_tr059_nullary_macro] = base.contract()
for _tr059_unary_macro in ("Top", "Interior", "formula", "bigl", "bigr", "emph"):
    core.MACRO_CONTRACTS[_tr059_unary_macro] = base.contract(1)
for _tr059_binary_macro in ("comp", "Prop"):
    core.MACRO_CONTRACTS[_tr059_binary_macro] = base.contract(2)
for _tr059_optional_binary_macro in ("sFmla", "TRule"):
    core.MACRO_CONTRACTS[_tr059_optional_binary_macro] = base.contract(2, 1)
core.MACRO_CONTRACTS["pFmla"] = base.contract(3)


# xparse places these two optional arguments after their mandatory arguments.
_tr059_previous_parse_macro_invocation = core.parse_macro_invocation


def _tr059_parse_macro_invocation(text, offset):
    invocation = _tr059_previous_parse_macro_invocation(text, offset)
    if invocation["name"] in {"sFmla", "TRule"}:
        cursor = core.skip_space(text, invocation["end"])
        if text[cursor:cursor + 1] == "[":
            _, _, cursor, option = core.parse_balanced(text, cursor, "[")
            invocation["options"] = [option]
            invocation["end"] = cursor
    return invocation


core.parse_macro_invocation = _tr059_parse_macro_invocation
_tr059_previous_mathml_node = base.renderer.mathml_node


def _tr059_mathml_node(node):
    if node.get("type") != "macro":
        return _tr059_previous_mathml_node(node)
    name = node.get("name")
    if name == "FalseCl":
        return '<msub><mo>⊥</mo><mi>C</mi></msub>'
    if name == "FalseInt":
        return '<msub><mo>⊥</mo><mi>I</mi></msub>'
    if name == "PAx":
        return '<msub><mi mathvariant="normal">Ax</mi><mn>0</mn></msub>'
    if name == "PosInt":
        return '<msup><mi mathvariant="double-struck">Z</mi><mo>+</mo></msup>'
    if name == "strictif":
        return '<mo>⥽</mo>'
    if name in {"cif", "boxright"}:
        # The source font provides Lewis's single box-right operator.  MathML
        # has no dedicated scalar, so retain its two glyph components in one
        # operator node rather than inventing two mathematical operands.
        return '<mo>□→</mo>'
    symbols = {
        "bot": "⊥", "subset": "⊂", "subsetneq": "⊊",
        "supseteq": "⊇", "supsetneq": "⊋",
    }
    if name in symbols:
        return "<mo>" + symbols[name] + "</mo>"
    arguments, options = grammar._args(node), grammar._options(node)
    if name in {"formula", "bigl", "bigr"}:
        return arguments[0]
    if name == "emph":
        return '<mstyle mathvariant="italic">' + arguments[0] + '</mstyle>'
    if name == "Top":
        return '<mstyle mathvariant="script">' + arguments[0] + '</mstyle>'
    if name == "Interior":
        return '<mrow><mi mathvariant="normal">Int</mi><mo>(</mo>' + arguments[0] + '<mo>)</mo></mrow>'
    if name == "Prop":
        model = base._first_style(node["arguments"][0], "fraktur")
        return '<msub><mrow><mo>⟦</mo>' + arguments[1] + '<mo>⟧</mo></mrow>' + model + '</msub>'
    if name == "comp":
        return '<mrow>' + arguments[1] + '<mo>∘</mo>' + arguments[0] + '</mrow>'
    if name == "sFmla":
        prefix = options[0] + '<mspace width="0.1667em"/>' if options else ''
        return '<mrow>' + prefix + arguments[0] + '<mspace width="0.4em"/>' + arguments[1] + '</mrow>'
    if name == "pFmla":
        return '<mrow>' + arguments[2] + '<mspace width="0.1667em"/>' + arguments[0] + '<mspace width="0.4em"/>' + arguments[1] + '</mrow>'
    if name == "TRule":
        suffix = '<mspace width="0.1667em"/>' + options[0] if options else ''
        return '<mrow>' + arguments[1] + arguments[0] + suffix + '</mrow>'
    return _tr059_previous_mathml_node(node)


base.renderer.mathml_node = _tr059_mathml_node
base.mathml_node = _tr059_mathml_node
