#!/usr/bin/env python3
"""Fail-closed structural math and words-only speech for OLAB-TR-030.

This is the reusable grammar layer.  Tranche-local expression and occurrence
meaning remains separately authored and audited; a successful parse is never
treated as semantic authority.
"""

from __future__ import annotations

import hashlib
import html
import importlib.util
import re
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
BASE_PATH = PROJECT / "work" / "tranche_027_models_of_arithmetic_projection" / "tr027_semantics.py"
PINNED_BASE_SHA256 = "c1a0ad8c7795fc0fe9b0b896a73560d627d382023f3db7efcb713f40f6ce5dd2"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if sha256_file(BASE_PATH) != PINNED_BASE_SHA256:
    raise RuntimeError("TR-030 structural base identity mismatch")
spec = importlib.util.spec_from_file_location("tr030_bound_tr027_semantics", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError("cannot load hash-bound TR-027 semantics")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
core = base.core


def contract(required: int = 0, optional: int = 0, unbraced: bool = False) -> dict[str, Any]:
    return {
        "required_arguments": required,
        "maximum_optional_arguments": optional,
        "allow_unbraced_arguments": unbraced,
        "projection_role": "tr030_recursive_functions_semantic_token",
        "formerly_unsupported_by_nd_contract": True,
    }


# The complete named vocabulary added by the 471 frozen TR-030 shapes.  Core
# contracts already cover common logic and arithmetic operators; re-declaring
# them here pins the argument topology actually used in this tranche.
core.MACRO_CONTRACTS.update({
    "abs": contract(1),
    "Add": contract(),
    "Char": contract(1),
    "Mult": contract(),
    "Proj": contract(2),
    "Succ": contract(),
    "Zero": contract(),
    "bexists": contract(2),
    "bforall": contract(2),
    "bigg": contract(),
    "bmin": contract(2),
    "bigcup": contract(),
    "cdot": contract(),
    "cfind": contract(1, 1),
    "concat": contract(),
    "defiff": contract(),
    "defis": contract(),
    "dots": contract(),
    "emptyseq": contract(),
    "equiv": contract(),
    "fact": contract(1),
    "fdefined": contract(),
    "fn": contract(1),
    "fundefined": contract(),
    "ge": contract(),
    "geq": contract(),
    "hash": contract(),
    "iddots": contract(),
    "intertext": contract(1),
    "in": contract(),
    "land": contract(),
    "langle": contract(),
    "le": contract(),
    "leq": contract(),
    "len": contract(1),
    "lfloor": contract(),
    "lif": contract(),
    "liff": contract(),
    "lnot": contract(),
    "lor": contract(),
    "left": contract(),
    "mbox": contract(1),
    "mid": contract(),
    "mod": contract(),
    "mu": contract(),
    "nmid": contract(),
    "neq": contract(0, 2),
    "Nat": contract(),
    "prod": contract(),
    "raisebox": contract(2, 2),
    "rbrace": contract(),
    "rfloor": contract(),
    "right": contract(),
    "rangle": contract(),
    "simeq": contract(),
    "sum": contract(),
    "text": contract(1),
    "times": contract(),
    "to": contract(),
    "tsub": contract(),
    "umin": contract(2),
    "vdots": contract(),
    "vec": contract(1, 0, True),
})

core.ENVIRONMENT_CONTRACTS.update({
    "array": core.environment_contract(
        "math_table", "other", formerly_unsupported=True, nested_math=True,
        required_preamble_arguments=1,
    ),
    "cases": core.environment_contract(
        "piecewise_cases", "other", formerly_unsupported=True, nested_math=True,
    ),
})


# TR-027 rewrites cases to literal marker text for its own finite set of
# special tables.  TR-030 keeps environments in the AST so its producer can
# build structural tables for every aligned or piecewise display.
_structural_reader_tex = base.base.reader_tex


def reader_tex(normalized_tex: str) -> str:
    value = normalized_tex.replace(r"\#", r"\hash")
    value = re.sub(r"\\left\|([^|]+?)\\right\|", r"\\abs{\1}", value)
    value = value.replace(r"\Proves/", r"\NotProves")
    value = value.replace(r"\not<", r"\nless")
    return _structural_reader_tex(value)


def parse_ast(normalized_tex: str) -> list[dict[str, Any]]:
    return core.parse_formula_ast(reader_tex(normalized_tex))


_render_nodes = base.base.base.mathml_nodes
_base_mathml_node = base.mathml_node


def _args(node: dict[str, Any]) -> list[str]:
    return [_render_nodes(argument) for argument in node["arguments"]]


def _options(node: dict[str, Any]) -> list[str]:
    return [_render_nodes(core.parse_formula_ast(reader_tex(option))) for option in node["options"]]


def _table_rows(children: list[dict[str, Any]]) -> list[list[list[dict[str, Any]]]]:
    rows: list[list[list[dict[str, Any]]]] = [[[]]]
    for child in children:
        if child["type"] == "row_break":
            rows.append([[]])
        elif child["type"] == "alignment_separator":
            rows[-1].append([])
        else:
            rows[-1][-1].append(child)
    return [row for row in rows if any(cell for cell in row)]


def _mathml_table(children: list[dict[str, Any]], *, cases: bool) -> str:
    rendered_rows = []
    for row in _table_rows(children):
        rendered_rows.append(
            "<mtr>" + "".join(f"<mtd>{_render_nodes(cell)}</mtd>" for cell in row) + "</mtr>"
        )
    table = "<mtable>" + "".join(rendered_rows) + "</mtable>"
    return f"<mrow><mo>{{</mo>{table}</mrow>" if cases else table


def _mixed_text_math(value: str) -> str:
    parts = re.split(r"(\$[^$]*\$)", value)
    rendered: list[str] = []
    for part in parts:
        if not part:
            continue
        if part.startswith("$") and part.endswith("$"):
            rendered.append(_render_nodes(parse_ast(part[1:-1])))
        else:
            rendered.append(f"<mtext>{html.escape(part)}</mtext>")
    return "<mrow>" + "".join(rendered) + "</mrow>"


def _tex_nodes(nodes: list[dict[str, Any]]) -> str:
    rendered: list[str] = []
    for node in nodes:
        kind = node["type"]
        if kind == "text":
            rendered.append(node["value"])
        elif kind == "group":
            rendered.append("{" + _tex_nodes(node["children"]) + "}")
        elif kind == "script":
            marker = "_" if node["kind"] == "subscript" else "^"
            rendered.append(marker + "{" + _tex_nodes([node["argument"]]) + "}")
        elif kind == "control_symbol":
            rendered.append("\\" + node["value"])
        elif kind == "row_break":
            rendered.append("\\\\")
        elif kind == "alignment_separator":
            rendered.append("&")
        elif kind == "macro":
            rendered.append("\\" + node["name"])
            rendered.extend("[" + option + "]" for option in node["options"])
            rendered.extend("{" + _tex_nodes(argument) + "}" for argument in node["arguments"])
        elif kind == "environment":
            rendered.append("\\begin{" + node["name"] + "}")
            rendered.append(_tex_nodes(node["children"]))
            rendered.append("\\end{" + node["name"] + "}")
        else:
            raise ValueError(f"cannot serialize AST node: {kind}")
    return "".join(rendered)


def mathml_node(node: dict[str, Any]) -> str:
    if node.get("type") == "group" and not node.get("children"):
        return '<mspace width="0em"></mspace>'
    if node.get("type") == "environment":
        return _mathml_table(node["children"], cases=node["name"] == "cases")
    if node.get("type") != "macro":
        return _base_mathml_node(node)
    name = node["name"]
    args = _args(node)
    options = _options(node)

    operators = {
        "cdot": "·", "concat": "⌢", "defiff": "⇔", "defis": "=", "equiv": "≡",
        "fdefined": "↓", "fundefined": "↑", "iddots": "⋰", "lfloor": "⌊",
        "geq": "≥", "leq": "≤", "mid": "∣", "mod": "mod", "mu": "μ", "nmid": "∤", "prod": "∏",
        "rbrace": "}", "rfloor": "⌋", "sum": "∑", "tsub": "∸", "vdots": "⋮",
    }
    if name in operators:
        return f"<mo>{html.escape(operators[name])}</mo>"
    identifiers = {
        "Add": "add", "Mult": "mult", "Succ": "succ", "Zero": "zero",
    }
    if name in identifiers:
        return f'<mi mathvariant="normal">{identifiers[name]}</mi>'
    if name == "fn":
        return f'<mstyle mathvariant="normal">{args[0]}</mstyle>'
    if name == "Proj":
        return f"<msubsup><mi>P</mi>{args[1]}{args[0]}</msubsup>"
    if name == "Char":
        return f"<msub><mi>χ</mi>{args[0]}</msub>"
    if name == "vec":
        return f"<mover>{args[0]}<mo>→</mo></mover>"
    if name == "len":
        return f'<mrow><mi mathvariant="normal">len</mi><mo>(</mo>{args[0]}<mo>)</mo></mrow>'
    if name == "cfind":
        head = f"<msub><mi>φ</mi>{args[0]}</msub>"
        return f"<msup>{head}{options[0]}</msup>" if options else head
    if name in {"bforall", "bexists"}:
        symbol = "∀" if name == "bforall" else "∃"
        return f"<mrow><mo>(</mo><mo>{symbol}</mo>{args[0]}<mo>)</mo>{args[1]}</mrow>"
    if name == "bmin":
        return f'<mrow><mo>(</mo><msub><mi mathvariant="normal">min</mi>{args[0]}</msub><mo>)</mo>{args[1]}</mrow>'
    if name == "umin":
        return f"<mrow><mo>μ</mo>{args[0]}{args[1]}</mrow>"
    if name == "fact":
        return f"<mrow>{args[0]}<mo>!</mo></mrow>"
    if name == "abs":
        return f"<mrow><mo>|</mo>{args[0]}<mo>|</mo></mrow>"
    if name == "emptyseq":
        return "<mi>Λ</mi>"
    if name == "hash":
        return '<mo form="prefix">#</mo>'
    if name == "raisebox":
        return args[1]
    if name in {"left", "right", "bigg", "qquad", "quad"}:
        return '<mspace width="0em"></mspace>'
    if name == "begin":
        return f'<mtext>{html.escape("begin " + base.base.base.literal_text(node["arguments"][0]))}</mtext>'
    if name == "end":
        return f'<mtext>{html.escape("end " + base.base.base.literal_text(node["arguments"][0]))}</mtext>'
    if name in {"text", "mbox", "intertext"}:
        return _mixed_text_math(_tex_nodes(node["arguments"][0]))
    return _base_mathml_node(node)


# The low-level renderer used by the bound stack performs dynamic dispatch
# through this module variable.
base.base.base.mathml_node = mathml_node


def _native_body(normalized_tex: str) -> str:
    body = _render_nodes(parse_ast(normalized_tex))
    if not body:
        raise ValueError("empty MathML body")
    return body


def native_mathml(expression_id: str, normalized_tex: str, display: str) -> str:
    if display not in {"inline", "block"}:
        raise ValueError(f"invalid display mode: {display}")
    body = _native_body(normalized_tex)
    annotation = html.escape(normalized_tex)
    return (
        f'<math xmlns="http://www.w3.org/1998/Math/MathML" display="{display}" '
        f'data-expression-id="{expression_id}"><semantics>{body}'
        f'<annotation encoding="application/x-tex">{annotation}</annotation>'
        f'</semantics></math>'
    )


_base_spoken_macro = base.spoken_macro


def spoken_nodes(nodes: list[dict[str, Any]]) -> str:
    pieces: list[str] = []
    for node in nodes:
        kind = node["type"]
        if kind == "text":
            pieces.append(base.base._plain(node["value"]))
        elif kind == "group":
            pieces.append(spoken_nodes(node["children"]))
        elif kind == "script":
            word = "sub" if node["kind"] == "subscript" else "superscript"
            pieces.append(f"{word} {spoken_nodes([node['argument']])}")
        elif kind == "control_symbol":
            if node["value"] not in {"{", "}", "\\", "&"}:
                pieces.append(base.base._plain(node["value"]))
        elif kind == "row_break":
            pieces.append("next row")
        elif kind == "alignment_separator":
            pieces.append("then")
        elif kind == "environment":
            rows = _table_rows(node["children"])
            label = "cases" if node["name"] == "cases" else "table"
            row_speech = []
            for index, row in enumerate(rows, start=1):
                cells = [spoken_nodes(cell) for cell in row]
                row_speech.append(f"row {base.number_word(index)}: " + ", ".join(cell for cell in cells if cell))
            pieces.append(f"{label} begin; " + "; ".join(row_speech) + f"; {label} end")
        elif kind == "macro":
            pieces.append(spoken_macro(node))
        else:
            raise ValueError(f"unhandled speech AST node: {kind}")
    return re.sub(r"\s+", " ", " ".join(piece for piece in pieces if piece)).strip(" ,")


def _spoken_args(node: dict[str, Any]) -> list[str]:
    return [spoken_nodes(argument) for argument in node["arguments"]]


def _spoken_options(node: dict[str, Any]) -> list[str]:
    return [spoken_nodes(core.parse_formula_ast(reader_tex(option))) for option in node["options"]]


def _function_name(value: str) -> str:
    exact = {
        "comp": "composition",
        "concat": "concatenate",
        "cond": "conditional",
        "const": "constant",
        "exp": "exponentiation",
        "fac": "factorial",
        "hconcat": "helper concatenate",
        "hsubtreeseq": "height subtree sequence",
        "id": "identity",
        "isubtrees": "immediate subtrees",
        "iszero": "zero test",
        "max": "maximum",
        "min": "minimum",
        "nextprime": "next prime",
        "pred": "predecessor",
        "prime": "prime predicate",
        "rec": "recursion",
        "sconcat": "sequence concatenate",
        "sequencebound": "sequence bound",
        "subseq": "subsequence",
        "subtreeseq": "subtree sequence",
        "tail": "tail",
    }
    if value.casefold() in exact:
        return exact[value.casefold()]
    replacements = {
        "IsZero": "is zero", "Comp": "composition", "Rec": "recursion",
        "SubtreeSeq": "subtree sequence", "ISubtrees": "immediate subtrees",
        "hSubtreeSeq": "height subtree sequence", "nextPrime": "next prime",
        "sequenceBound": "sequence bound", "sconcat": "sequence concatenate",
        "hconcat": "helper concatenate",
    }
    for source, target in replacements.items():
        value = value.replace(source, target)
    return value


def _mixed_spoken_text(value: str) -> str:
    parts = re.split(r"(\$[^$]*\$)", value)
    spoken: list[str] = []
    for part in parts:
        if not part:
            continue
        if part.startswith("$") and part.endswith("$"):
            spoken.append(spoken_nodes(parse_ast(part[1:-1])))
        else:
            spoken.append(base.base._plain(part))
    return re.sub(r"\s+", " ", " ".join(spoken)).strip(" ,")


def _bound_phrase(value: str) -> str:
    value = re.sub(r"^(.+?) is less than or equal to (.+)$", r"\1 less than or equal to \2", value)
    value = re.sub(r"^(.+?) is less than (.+)$", r"\1 less than \2", value)
    return value


def spoken_macro(node: dict[str, Any]) -> str:
    name = node["name"]
    args = _spoken_args(node)
    options = _spoken_options(node)
    fixed = {
        "Add": "the addition function", "Mult": "the multiplication function",
        "Succ": "the successor function", "Zero": "the constant zero function",
        "cdot": "times", "concat": "concatenated with", "defiff": "is defined exactly when",
        "defis": "is defined as", "emptyseq": "the empty sequence code",
        "equiv": "is congruent to", "fdefined": "is defined",
        "fundefined": "is undefined", "hash": "the code of", "iddots": "continuing upward diagonally",
        "geq": "is greater than or equal to", "leq": "is less than or equal to",
        "lfloor": "the floor of", "mid": "divides", "mod": "modulo",
        "mu": "the least", "nmid": "does not divide", "prod": "the product",
        "rbrace": "right brace", "rfloor": "end floor", "sum": "the sum",
        "times": "times", "tsub": "truncated minus", "vdots": "and so on vertically",
    }
    if name in fixed:
        return fixed[name]
    if name == "fn":
        return f"the function {_function_name(args[0])}"
    if name == "Proj":
        return f"the {args[0]} place projection with index {args[1]}"
    if name == "Char":
        return f"the characteristic function of {args[0]}"
    if name == "vec":
        return f"vector {args[0]}"
    if name == "len":
        return f"the length of {args[0]}"
    if name == "cfind":
        suffix = f" superscript {options[0]}" if options else ""
        return f"partial recursive function phi sub {args[0]}{suffix}"
    if name == "bforall":
        return f"for every {_bound_phrase(args[0])}, {args[1]}"
    if name == "bexists":
        return f"there exists {_bound_phrase(args[0])} such that {args[1]}"
    if name == "bmin":
        return f"the least {_bound_phrase(args[0])} such that {args[1]}"
    if name == "umin":
        return f"the least {args[0]} such that {args[1]}"
    if name == "fact":
        return f"{args[0]} factorial"
    if name == "abs":
        return f"the absolute value of {args[0]}"
    if name == "raisebox":
        return args[1]
    if name in {"left", "right", "bigg", "qquad", "quad"}:
        return ""
    if name == "begin":
        return f"{_function_name(args[0])} begins"
    if name == "end":
        return f"{_function_name(args[0])} ends"
    if name in {"text", "mbox", "intertext"}:
        return _mixed_spoken_text(_tex_nodes(node["arguments"][0]))
    if name == "colon":
        return "from"
    if name == "simeq":
        return "has the same definedness and value as"
    return _base_spoken_macro(node)


base.base.spoken_macro = spoken_macro


def spoken_math(normalized_tex: str) -> str:
    speech = spoken_nodes(parse_ast(normalized_tex))
    speech = speech.replace("$", " ").replace("'", " prime ").replace("!", "")
    speech = re.sub(r"\bnextPrime\b", "next prime", speech)
    speech = re.sub(r"\bsequenceBound\b", "sequence bound", speech)
    speech = re.sub(r"(?<=\d)(?=[A-Za-z])", " times ", speech)
    speech = speech.replace("cross", "times")
    speech = re.sub(r"\bthe least ([A-Za-z](?: sub [A-Za-z]+)?) semicolon\b", r"the least \1 such that", speech)
    speech = speech.replace("then equals then", "equals")
    speech = re.sub(r"\bthen equals\b", "equals", speech)
    speech = re.sub(r"^then\s+", "", speech)
    speech = re.sub(r"\bnext row then (?=and so on)", "next row ", speech)
    speech = speech.replace("two minus place", "two-place")
    speech = speech.replace("we have such that", "we have")
    speech = speech.replace("x/y", "x divided by y")
    speech = re.sub(r"\s+comma$", "", speech)
    speech = re.sub(r"\b([A-Za-z])([A-Za-z])\b", lambda match: match.group(0), speech)
    speech = re.sub(r"\d+", lambda match: base.number_word(int(match.group())), speech)
    speech = re.sub(r"\s+", " ", speech).strip(" ,")
    if not speech or re.search(r"[\\{}$\d]", speech):
        raise ValueError(f"speech residue or empty output for {normalized_tex!r}: {speech!r}")
    return speech


def macro_names(nodes: list[dict[str, Any]]) -> set[str]:
    return base.base.base.macro_names(nodes)


def semantic_class(normalized_tex: str) -> str:
    if any(token in normalized_tex for token in (r"\fdefined", r"\fundefined", r"\simeq", r"\mu", r"\umin", r"\cfind")):
        return "partial_recursive_function_or_computation"
    if any(token in normalized_tex for token in (r"\Char", r"\bforall", r"\bexists", r"\defiff", r"\lnot", r"\land", r"\lor", r"\lif", r"\liff")):
        return "primitive_recursive_relation_or_bounded_quantifier"
    if any(token in normalized_tex for token in (r"\tuple", r"\len", r"\concat", r"\emptyseq", r"\fn{append}", r"\fn{element}")):
        return "sequence_or_tree_coding"
    if any(token in normalized_tex for token in (r"\Proj", r"\Zero", r"\Succ", r"\Add", r"\Mult", r"\fn{Comp}", r"\fn{Rec}")):
        return "primitive_recursive_definition_or_operator"
    if r"\#" in normalized_tex:
        return "notation_code"
    if any(token in normalized_tex for token in ("=", "<", ">", r"\le", r"\ge", r"\mid", r"\nmid", r"\in")):
        return "recursive_function_relation_or_equation"
    return "recursive_function_notation_or_term"


SOURCE_CORRECTIONS: dict[str, dict[str, Any]] = {}
