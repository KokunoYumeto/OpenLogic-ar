# Reproduce the accepted Sets EPUB bytes

Extract this archive into a fresh directory and run all commands from its root.
Python 3.11+ and lxml are required; the packaging replay used the version listed
in requirements-reproduce.txt. No TeX engine, PDF extraction, network or English
full-book corpus is needed for EPUB production. In PowerShell:

```powershell
$env:OPENLOGIC_ENGLISH_READER_ROOT = (Resolve-Path 'english-runtime').Path
python -B -X utf8 -m unittest discover -s build/epub/tests -v
python -B -X utf8 build/epub/build_arabic_epub.py build --freeze tmp/epub/sets-20260910/SOURCE_FREEZE.json --output reproduced
```

The expected EPUB hashes are in the original LOCAL_ACCEPTANCE.json under
tmp/epub/sets-20260910/candidate-v4. The companion public EPUBs are separate
downloads; the ZIP does not duplicate them. The rebuilt EPUBs must have the
same hashes. Build receipts will correctly record relocated public code hashes.

Public copies replace machine-specific roots with `upstream-source`,
`english-runtime`, or `.`. Copied runtime dependency pins are updated transitively
to bind those relocated copies; mathematical conversion logic and Arabic source
bytes are untouched. PACKAGING_PROVENANCE.json preserves every original source
hash, public-copy hash and exact replacement count. The copied historical QA
receipts retain their historical hashes/references and are not new assertions
that relocated code produced the original candidate. A separate packaging replay
confirms that the archive's relocated implementation reproduces its EPUB bytes.

The imported English grammar loads six chapter configuration records and their
source-authority manifests even though Sets formulas need none of those chapters.
Only those import-required JSON records and five source-definition files are
included; the unrelated chapter corpora and unneeded manifest-listed artifacts
are deliberately absent. The added eight upstream English chapter sources are
included solely to support the source identities of this Arabic chapter edition.
The full 722-unit control manifest is identified in SOURCE_FREEZE.json but is not
included or needed when building from the existing frozen eight-unit selection.

Existing EPUBCheck and runtime reports are included as historical acceptance
evidence. To repeat EPUBCheck, obtain EPUBCheck 5.3.0 separately from its official
distribution and run Java with `-Xmx512m`. To repeat the optional browser check,
inspect_epub_runtime.mjs expects epub.js 0.3.93, jszip and puppeteer in its documented
English-root tools locations. Those third-party installations and browser binaries
are not bundled. The included human-readable content review clearly distinguishes
historical candidate-v3 findings from their verified candidate-v4 resolution.

Licensing: the repository and upstream Open Logic LICENSE.md files are included
unaltered, together with the upstream README attribution. File-specific notices
remain in their source files; bussproofs-extra.sty specifies LPPL 1.3 or later.
No separate licence declaration was present at the supplied English runtime
project root, so this package does not invent a new licence grant for its code.
The external Python and browser dependencies retain their own distribution licences.
