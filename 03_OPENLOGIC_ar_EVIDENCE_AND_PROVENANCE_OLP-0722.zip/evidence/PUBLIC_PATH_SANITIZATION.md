# Public-path sanitization

All evidence text was copied from bounded final controls, receipts, and build records. Workspace and user-home prefixes were replaced with `<WORKSPACE_ROOT>` and `<USER_HOME>`. The obsolete OLP-0010 DOI literal and historical non-release wording were removed while retaining their roles textually. No credentials, temporary renders, caches, or stale build outputs are included.
